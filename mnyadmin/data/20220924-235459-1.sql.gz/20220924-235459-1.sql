-- -----------------------------
-- Yzncms MySQL Data Transfer 
-- 
-- Host     : 47.122.2.4
-- Port     : 3605
-- Database : agwlsxsc
-- 
-- Part : #1
-- Date : 2022-09-24 23:54:59
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `mny_address`
-- -----------------------------
DROP TABLE IF EXISTS `mny_address`;
CREATE TABLE `mny_address` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '表id',
  `name` varchar(20) CHARACTER SET gbk COLLATE gbk_chinese_ci NOT NULL COMMENT '地区名称',
  `status` int DEFAULT '1' COMMENT '0：禁用 1：启用',
  `listorder` int DEFAULT '0',
  `parentid` int DEFAULT NULL COMMENT '父id',
  `level` tinyint(1) DEFAULT NULL COMMENT '地区等级',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=3527 DEFAULT CHARSET=gbk ROW_FORMAT=DYNAMIC COMMENT='全国省市区表';

-- -----------------------------
-- Records of `mny_address`
-- -----------------------------
INSERT INTO `mny_address` VALUES ('1', '北京市', '1', '0', '0', '1');
INSERT INTO `mny_address` VALUES ('2', '天津市', '1', '0', '0', '1');
INSERT INTO `mny_address` VALUES ('3', '河北省', '1', '0', '0', '1');
INSERT INTO `mny_address` VALUES ('4', '山西省', '1', '0', '0', '1');
INSERT INTO `mny_address` VALUES ('5', '内蒙古自治区', '1', '0', '0', '1');
INSERT INTO `mny_address` VALUES ('6', '辽宁省', '1', '0', '0', '1');
INSERT INTO `mny_address` VALUES ('7', '吉林省', '1', '0', '0', '1');
INSERT INTO `mny_address` VALUES ('8', '黑龙江省', '1', '0', '0', '1');
INSERT INTO `mny_address` VALUES ('9', '上海市', '1', '0', '0', '1');
INSERT INTO `mny_address` VALUES ('10', '江苏省', '1', '0', '0', '1');
INSERT INTO `mny_address` VALUES ('11', '浙江省', '1', '0', '0', '1');
INSERT INTO `mny_address` VALUES ('12', '安徽省', '1', '0', '0', '1');
INSERT INTO `mny_address` VALUES ('13', '福建省', '1', '0', '0', '1');
INSERT INTO `mny_address` VALUES ('14', '江西省', '1', '0', '0', '1');
INSERT INTO `mny_address` VALUES ('15', '山东省', '1', '0', '0', '1');
INSERT INTO `mny_address` VALUES ('16', '河南省', '1', '0', '0', '1');
INSERT INTO `mny_address` VALUES ('17', '湖北省', '1', '0', '0', '1');
INSERT INTO `mny_address` VALUES ('18', '湖南省', '1', '0', '0', '1');
INSERT INTO `mny_address` VALUES ('19', '广东省', '1', '0', '0', '1');
INSERT INTO `mny_address` VALUES ('20', '广西壮族自治区', '1', '0', '0', '1');
INSERT INTO `mny_address` VALUES ('21', '海南省', '1', '0', '0', '1');
INSERT INTO `mny_address` VALUES ('22', '重庆市', '1', '0', '0', '1');
INSERT INTO `mny_address` VALUES ('23', '四川省', '1', '0', '0', '1');
INSERT INTO `mny_address` VALUES ('24', '贵州省', '1', '0', '0', '1');
INSERT INTO `mny_address` VALUES ('25', '云南省', '1', '0', '0', '1');
INSERT INTO `mny_address` VALUES ('26', '西藏自治区', '1', '0', '0', '1');
INSERT INTO `mny_address` VALUES ('27', '陕西省', '1', '0', '0', '1');
INSERT INTO `mny_address` VALUES ('28', '甘肃省', '1', '0', '0', '1');
INSERT INTO `mny_address` VALUES ('29', '青海省', '1', '0', '0', '1');
INSERT INTO `mny_address` VALUES ('30', '宁夏回族自治区', '1', '0', '0', '1');
INSERT INTO `mny_address` VALUES ('31', '新疆维吾尔自治区', '1', '0', '0', '1');
INSERT INTO `mny_address` VALUES ('32', '台湾省', '1', '0', '0', '1');
INSERT INTO `mny_address` VALUES ('33', '香港特别行政区', '1', '0', '0', '1');
INSERT INTO `mny_address` VALUES ('34', '澳门特别行政区', '1', '0', '0', '1');
INSERT INTO `mny_address` VALUES ('35', '市辖区', '1', '0', '1', '2');
INSERT INTO `mny_address` VALUES ('36', '县', '1', '0', '1', '2');
INSERT INTO `mny_address` VALUES ('37', '市辖区', '1', '0', '2', '2');
INSERT INTO `mny_address` VALUES ('38', '县', '1', '0', '2', '2');
INSERT INTO `mny_address` VALUES ('39', '石家庄市', '1', '0', '3', '2');
INSERT INTO `mny_address` VALUES ('40', '唐山市', '1', '0', '3', '2');
INSERT INTO `mny_address` VALUES ('41', '秦皇岛市', '1', '0', '3', '2');
INSERT INTO `mny_address` VALUES ('42', '邯郸市', '1', '0', '3', '2');
INSERT INTO `mny_address` VALUES ('43', '邢台市', '1', '0', '3', '2');
INSERT INTO `mny_address` VALUES ('44', '保定市', '1', '0', '3', '2');
INSERT INTO `mny_address` VALUES ('45', '张家口市', '1', '0', '3', '2');
INSERT INTO `mny_address` VALUES ('46', '承德市', '1', '0', '3', '2');
INSERT INTO `mny_address` VALUES ('47', '沧州市', '1', '0', '3', '2');
INSERT INTO `mny_address` VALUES ('48', '廊坊市', '1', '0', '3', '2');
INSERT INTO `mny_address` VALUES ('49', '衡水市', '1', '0', '3', '2');
INSERT INTO `mny_address` VALUES ('50', '太原市', '1', '0', '4', '2');
INSERT INTO `mny_address` VALUES ('51', '大同市', '1', '0', '4', '2');
INSERT INTO `mny_address` VALUES ('52', '阳泉市', '1', '0', '4', '2');
INSERT INTO `mny_address` VALUES ('53', '长治市', '1', '0', '4', '2');
INSERT INTO `mny_address` VALUES ('54', '晋城市', '1', '0', '4', '2');
INSERT INTO `mny_address` VALUES ('55', '朔州市', '1', '0', '4', '2');
INSERT INTO `mny_address` VALUES ('56', '晋中市', '1', '0', '4', '2');
INSERT INTO `mny_address` VALUES ('57', '运城市', '1', '0', '4', '2');
INSERT INTO `mny_address` VALUES ('58', '忻州市', '1', '0', '4', '2');
INSERT INTO `mny_address` VALUES ('59', '临汾市', '1', '0', '4', '2');
INSERT INTO `mny_address` VALUES ('60', '吕梁市', '1', '0', '4', '2');
INSERT INTO `mny_address` VALUES ('61', '呼和浩特市', '1', '0', '5', '2');
INSERT INTO `mny_address` VALUES ('62', '包头市', '1', '0', '5', '2');
INSERT INTO `mny_address` VALUES ('63', '乌海市', '1', '0', '5', '2');
INSERT INTO `mny_address` VALUES ('64', '赤峰市', '1', '0', '5', '2');
INSERT INTO `mny_address` VALUES ('65', '通辽市', '1', '0', '5', '2');
INSERT INTO `mny_address` VALUES ('66', '鄂尔多斯市', '1', '0', '5', '2');
INSERT INTO `mny_address` VALUES ('67', '呼伦贝尔市', '1', '0', '5', '2');
INSERT INTO `mny_address` VALUES ('68', '巴彦淖尔市', '1', '0', '5', '2');
INSERT INTO `mny_address` VALUES ('69', '乌兰察布市', '1', '0', '5', '2');
INSERT INTO `mny_address` VALUES ('70', '兴安盟', '1', '0', '5', '2');
INSERT INTO `mny_address` VALUES ('71', '锡林郭勒盟', '1', '0', '5', '2');
INSERT INTO `mny_address` VALUES ('72', '阿拉善盟', '1', '0', '5', '2');
INSERT INTO `mny_address` VALUES ('73', '沈阳市', '1', '0', '6', '2');
INSERT INTO `mny_address` VALUES ('74', '大连市', '1', '0', '6', '2');
INSERT INTO `mny_address` VALUES ('75', '鞍山市', '1', '0', '6', '2');
INSERT INTO `mny_address` VALUES ('76', '抚顺市', '1', '0', '6', '2');
INSERT INTO `mny_address` VALUES ('77', '本溪市', '1', '0', '6', '2');
INSERT INTO `mny_address` VALUES ('78', '丹东市', '1', '0', '6', '2');
INSERT INTO `mny_address` VALUES ('79', '锦州市', '1', '0', '6', '2');
INSERT INTO `mny_address` VALUES ('80', '营口市', '1', '0', '6', '2');
INSERT INTO `mny_address` VALUES ('81', '阜新市', '1', '0', '6', '2');
INSERT INTO `mny_address` VALUES ('82', '辽阳市', '1', '0', '6', '2');
INSERT INTO `mny_address` VALUES ('83', '盘锦市', '1', '0', '6', '2');
INSERT INTO `mny_address` VALUES ('84', '铁岭市', '1', '0', '6', '2');
INSERT INTO `mny_address` VALUES ('85', '朝阳市', '1', '0', '6', '2');
INSERT INTO `mny_address` VALUES ('86', '葫芦岛市', '1', '0', '6', '2');
INSERT INTO `mny_address` VALUES ('87', '长春市', '1', '0', '7', '2');
INSERT INTO `mny_address` VALUES ('88', '吉林市', '1', '0', '7', '2');
INSERT INTO `mny_address` VALUES ('89', '四平市', '1', '0', '7', '2');
INSERT INTO `mny_address` VALUES ('90', '辽源市', '1', '0', '7', '2');
INSERT INTO `mny_address` VALUES ('91', '通化市', '1', '0', '7', '2');
INSERT INTO `mny_address` VALUES ('92', '白山市', '1', '0', '7', '2');
INSERT INTO `mny_address` VALUES ('93', '松原市', '1', '0', '7', '2');
INSERT INTO `mny_address` VALUES ('94', '白城市', '1', '0', '7', '2');
INSERT INTO `mny_address` VALUES ('95', '延边朝鲜族自治州', '1', '0', '7', '2');
INSERT INTO `mny_address` VALUES ('96', '哈尔滨市', '1', '0', '8', '2');
INSERT INTO `mny_address` VALUES ('97', '齐齐哈尔市', '1', '0', '8', '2');
INSERT INTO `mny_address` VALUES ('98', '鸡西市', '1', '0', '8', '2');
INSERT INTO `mny_address` VALUES ('99', '鹤岗市', '1', '0', '8', '2');
INSERT INTO `mny_address` VALUES ('100', '双鸭山市', '1', '0', '8', '2');
INSERT INTO `mny_address` VALUES ('101', '大庆市', '1', '0', '8', '2');
INSERT INTO `mny_address` VALUES ('102', '伊春市', '1', '0', '8', '2');
INSERT INTO `mny_address` VALUES ('103', '佳木斯市', '1', '0', '8', '2');
INSERT INTO `mny_address` VALUES ('104', '七台河市', '1', '0', '8', '2');
INSERT INTO `mny_address` VALUES ('105', '牡丹江市', '1', '0', '8', '2');
INSERT INTO `mny_address` VALUES ('106', '黑河市', '1', '0', '8', '2');
INSERT INTO `mny_address` VALUES ('107', '绥化市', '1', '0', '8', '2');
INSERT INTO `mny_address` VALUES ('108', '大兴安岭地区', '1', '0', '8', '2');
INSERT INTO `mny_address` VALUES ('109', '市辖区', '1', '0', '9', '2');
INSERT INTO `mny_address` VALUES ('110', '县', '1', '0', '9', '2');
INSERT INTO `mny_address` VALUES ('111', '南京市', '1', '0', '10', '2');
INSERT INTO `mny_address` VALUES ('112', '无锡市', '1', '0', '10', '2');
INSERT INTO `mny_address` VALUES ('113', '徐州市', '1', '0', '10', '2');
INSERT INTO `mny_address` VALUES ('114', '常州市', '1', '0', '10', '2');
INSERT INTO `mny_address` VALUES ('115', '苏州市', '1', '0', '10', '2');
INSERT INTO `mny_address` VALUES ('116', '南通市', '1', '0', '10', '2');
INSERT INTO `mny_address` VALUES ('117', '连云港市', '1', '0', '10', '2');
INSERT INTO `mny_address` VALUES ('118', '淮安市', '1', '0', '10', '2');
INSERT INTO `mny_address` VALUES ('119', '盐城市', '1', '0', '10', '2');
INSERT INTO `mny_address` VALUES ('120', '扬州市', '1', '0', '10', '2');
INSERT INTO `mny_address` VALUES ('121', '镇江市', '1', '0', '10', '2');
INSERT INTO `mny_address` VALUES ('122', '泰州市', '1', '0', '10', '2');
INSERT INTO `mny_address` VALUES ('123', '宿迁市', '1', '0', '10', '2');
INSERT INTO `mny_address` VALUES ('124', '杭州市', '1', '0', '11', '2');
INSERT INTO `mny_address` VALUES ('125', '宁波市', '1', '0', '11', '2');
INSERT INTO `mny_address` VALUES ('126', '温州市', '1', '0', '11', '2');
INSERT INTO `mny_address` VALUES ('127', '嘉兴市', '1', '0', '11', '2');
INSERT INTO `mny_address` VALUES ('128', '湖州市', '1', '0', '11', '2');
INSERT INTO `mny_address` VALUES ('129', '绍兴市', '1', '0', '11', '2');
INSERT INTO `mny_address` VALUES ('130', '金华市', '1', '0', '11', '2');
INSERT INTO `mny_address` VALUES ('131', '衢州市', '1', '0', '11', '2');
INSERT INTO `mny_address` VALUES ('132', '舟山市', '1', '0', '11', '2');
INSERT INTO `mny_address` VALUES ('133', '台州市', '1', '0', '11', '2');
INSERT INTO `mny_address` VALUES ('134', '丽水市', '1', '0', '11', '2');
INSERT INTO `mny_address` VALUES ('135', '合肥市', '1', '0', '12', '2');
INSERT INTO `mny_address` VALUES ('136', '芜湖市', '1', '0', '12', '2');
INSERT INTO `mny_address` VALUES ('137', '蚌埠市', '1', '0', '12', '2');
INSERT INTO `mny_address` VALUES ('138', '淮南市', '1', '0', '12', '2');
INSERT INTO `mny_address` VALUES ('139', '马鞍山市', '1', '0', '12', '2');
INSERT INTO `mny_address` VALUES ('140', '淮北市', '1', '0', '12', '2');
INSERT INTO `mny_address` VALUES ('141', '铜陵市', '1', '0', '12', '2');
INSERT INTO `mny_address` VALUES ('142', '安庆市', '1', '0', '12', '2');
INSERT INTO `mny_address` VALUES ('143', '黄山市', '1', '0', '12', '2');
INSERT INTO `mny_address` VALUES ('144', '滁州市', '1', '0', '12', '2');
INSERT INTO `mny_address` VALUES ('145', '阜阳市', '1', '0', '12', '2');
INSERT INTO `mny_address` VALUES ('146', '宿州市', '1', '0', '12', '2');
INSERT INTO `mny_address` VALUES ('147', '巢湖市', '1', '0', '12', '2');
INSERT INTO `mny_address` VALUES ('148', '六安市', '1', '0', '12', '2');
INSERT INTO `mny_address` VALUES ('149', '亳州市', '1', '0', '12', '2');
INSERT INTO `mny_address` VALUES ('150', '池州市', '1', '0', '12', '2');
INSERT INTO `mny_address` VALUES ('151', '宣城市', '1', '0', '12', '2');
INSERT INTO `mny_address` VALUES ('152', '福州市', '1', '0', '13', '2');
INSERT INTO `mny_address` VALUES ('153', '厦门市', '1', '0', '13', '2');
INSERT INTO `mny_address` VALUES ('154', '莆田市', '1', '0', '13', '2');
INSERT INTO `mny_address` VALUES ('155', '三明市', '1', '0', '13', '2');
INSERT INTO `mny_address` VALUES ('156', '泉州市', '1', '0', '13', '2');
INSERT INTO `mny_address` VALUES ('157', '漳州市', '1', '0', '13', '2');
INSERT INTO `mny_address` VALUES ('158', '南平市', '1', '0', '13', '2');
INSERT INTO `mny_address` VALUES ('159', '龙岩市', '1', '0', '13', '2');
INSERT INTO `mny_address` VALUES ('160', '宁德市', '1', '0', '13', '2');
INSERT INTO `mny_address` VALUES ('161', '南昌市', '1', '0', '14', '2');
INSERT INTO `mny_address` VALUES ('162', '景德镇市', '1', '0', '14', '2');
INSERT INTO `mny_address` VALUES ('163', '萍乡市', '1', '0', '14', '2');
INSERT INTO `mny_address` VALUES ('164', '九江市', '1', '0', '14', '2');
INSERT INTO `mny_address` VALUES ('165', '新余市', '1', '0', '14', '2');
INSERT INTO `mny_address` VALUES ('166', '鹰潭市', '1', '0', '14', '2');
INSERT INTO `mny_address` VALUES ('167', '赣州市', '1', '0', '14', '2');
INSERT INTO `mny_address` VALUES ('168', '吉安市', '1', '0', '14', '2');
INSERT INTO `mny_address` VALUES ('169', '宜春市', '1', '0', '14', '2');
INSERT INTO `mny_address` VALUES ('170', '抚州市', '1', '0', '14', '2');
INSERT INTO `mny_address` VALUES ('171', '上饶市', '1', '0', '14', '2');
INSERT INTO `mny_address` VALUES ('172', '济南市', '1', '0', '15', '2');
INSERT INTO `mny_address` VALUES ('173', '青岛市', '1', '0', '15', '2');
INSERT INTO `mny_address` VALUES ('174', '淄博市', '1', '0', '15', '2');
INSERT INTO `mny_address` VALUES ('175', '枣庄市', '1', '0', '15', '2');
INSERT INTO `mny_address` VALUES ('176', '东营市', '1', '0', '15', '2');
INSERT INTO `mny_address` VALUES ('177', '烟台市', '1', '0', '15', '2');
INSERT INTO `mny_address` VALUES ('178', '潍坊市', '1', '0', '15', '2');
INSERT INTO `mny_address` VALUES ('179', '济宁市', '1', '0', '15', '2');
INSERT INTO `mny_address` VALUES ('180', '泰安市', '1', '0', '15', '2');
INSERT INTO `mny_address` VALUES ('181', '威海市', '1', '0', '15', '2');
INSERT INTO `mny_address` VALUES ('182', '日照市', '1', '0', '15', '2');
INSERT INTO `mny_address` VALUES ('183', '莱芜市', '1', '0', '15', '2');
INSERT INTO `mny_address` VALUES ('184', '临沂市', '1', '0', '15', '2');
INSERT INTO `mny_address` VALUES ('185', '德州市', '1', '0', '15', '2');
INSERT INTO `mny_address` VALUES ('186', '聊城市', '1', '0', '15', '2');
INSERT INTO `mny_address` VALUES ('187', '滨州市', '1', '0', '15', '2');
INSERT INTO `mny_address` VALUES ('188', '荷泽市', '1', '0', '15', '2');
INSERT INTO `mny_address` VALUES ('189', '郑州市', '1', '0', '16', '2');
INSERT INTO `mny_address` VALUES ('190', '开封市', '1', '0', '16', '2');
INSERT INTO `mny_address` VALUES ('191', '洛阳市', '1', '0', '16', '2');
INSERT INTO `mny_address` VALUES ('192', '平顶山市', '1', '0', '16', '2');
INSERT INTO `mny_address` VALUES ('193', '安阳市', '1', '0', '16', '2');
INSERT INTO `mny_address` VALUES ('194', '鹤壁市', '1', '0', '16', '2');
INSERT INTO `mny_address` VALUES ('195', '新乡市', '1', '0', '16', '2');
INSERT INTO `mny_address` VALUES ('196', '焦作市', '1', '0', '16', '2');
INSERT INTO `mny_address` VALUES ('197', '濮阳市', '1', '0', '16', '2');
INSERT INTO `mny_address` VALUES ('198', '许昌市', '1', '0', '16', '2');
INSERT INTO `mny_address` VALUES ('199', '漯河市', '1', '0', '16', '2');
INSERT INTO `mny_address` VALUES ('200', '三门峡市', '1', '0', '16', '2');
INSERT INTO `mny_address` VALUES ('201', '南阳市', '1', '0', '16', '2');
INSERT INTO `mny_address` VALUES ('202', '商丘市', '1', '0', '16', '2');
INSERT INTO `mny_address` VALUES ('203', '信阳市', '1', '0', '16', '2');
INSERT INTO `mny_address` VALUES ('204', '周口市', '1', '0', '16', '2');
INSERT INTO `mny_address` VALUES ('205', '驻马店市', '1', '0', '16', '2');
INSERT INTO `mny_address` VALUES ('206', '武汉市', '1', '0', '17', '2');
INSERT INTO `mny_address` VALUES ('207', '黄石市', '1', '0', '17', '2');
INSERT INTO `mny_address` VALUES ('208', '十堰市', '1', '0', '17', '2');
INSERT INTO `mny_address` VALUES ('209', '宜昌市', '1', '0', '17', '2');
INSERT INTO `mny_address` VALUES ('210', '襄樊市', '1', '0', '17', '2');
INSERT INTO `mny_address` VALUES ('211', '鄂州市', '1', '0', '17', '2');
INSERT INTO `mny_address` VALUES ('212', '荆门市', '1', '0', '17', '2');
INSERT INTO `mny_address` VALUES ('213', '孝感市', '1', '0', '17', '2');
INSERT INTO `mny_address` VALUES ('214', '荆州市', '1', '0', '17', '2');
INSERT INTO `mny_address` VALUES ('215', '黄冈市', '1', '0', '17', '2');
INSERT INTO `mny_address` VALUES ('216', '咸宁市', '1', '0', '17', '2');
INSERT INTO `mny_address` VALUES ('217', '随州市', '1', '0', '17', '2');
INSERT INTO `mny_address` VALUES ('218', '恩施土家族苗族自治州', '1', '0', '17', '2');
INSERT INTO `mny_address` VALUES ('219', '省直辖行政单位', '1', '0', '17', '2');
INSERT INTO `mny_address` VALUES ('220', '长沙市', '1', '0', '18', '2');
INSERT INTO `mny_address` VALUES ('221', '株洲市', '1', '0', '18', '2');
INSERT INTO `mny_address` VALUES ('222', '湘潭市', '1', '0', '18', '2');
INSERT INTO `mny_address` VALUES ('223', '衡阳市', '1', '0', '18', '2');
INSERT INTO `mny_address` VALUES ('224', '邵阳市', '1', '0', '18', '2');
INSERT INTO `mny_address` VALUES ('225', '岳阳市', '1', '0', '18', '2');
INSERT INTO `mny_address` VALUES ('226', '常德市', '1', '0', '18', '2');
INSERT INTO `mny_address` VALUES ('227', '张家界市', '1', '0', '18', '2');
INSERT INTO `mny_address` VALUES ('228', '益阳市', '1', '0', '18', '2');
INSERT INTO `mny_address` VALUES ('229', '郴州市', '1', '0', '18', '2');
INSERT INTO `mny_address` VALUES ('230', '永州市', '1', '0', '18', '2');
INSERT INTO `mny_address` VALUES ('231', '怀化市', '1', '0', '18', '2');
INSERT INTO `mny_address` VALUES ('232', '娄底市', '1', '0', '18', '2');
INSERT INTO `mny_address` VALUES ('233', '湘西土家族苗族自治州', '1', '0', '18', '2');
INSERT INTO `mny_address` VALUES ('234', '广州市', '1', '0', '19', '2');
INSERT INTO `mny_address` VALUES ('235', '韶关市', '1', '0', '19', '2');
INSERT INTO `mny_address` VALUES ('236', '深圳市', '1', '0', '19', '2');
INSERT INTO `mny_address` VALUES ('237', '珠海市', '1', '0', '19', '2');
INSERT INTO `mny_address` VALUES ('238', '汕头市', '1', '0', '19', '2');
INSERT INTO `mny_address` VALUES ('239', '佛山市', '1', '0', '19', '2');
INSERT INTO `mny_address` VALUES ('240', '江门市', '1', '0', '19', '2');
INSERT INTO `mny_address` VALUES ('241', '湛江市', '1', '0', '19', '2');
INSERT INTO `mny_address` VALUES ('242', '茂名市', '1', '0', '19', '2');
INSERT INTO `mny_address` VALUES ('243', '肇庆市', '1', '0', '19', '2');
INSERT INTO `mny_address` VALUES ('244', '惠州市', '1', '0', '19', '2');
INSERT INTO `mny_address` VALUES ('245', '梅州市', '1', '0', '19', '2');
INSERT INTO `mny_address` VALUES ('246', '汕尾市', '1', '0', '19', '2');
INSERT INTO `mny_address` VALUES ('247', '河源市', '1', '0', '19', '2');
INSERT INTO `mny_address` VALUES ('248', '阳江市', '1', '0', '19', '2');
INSERT INTO `mny_address` VALUES ('249', '清远市', '1', '0', '19', '2');
INSERT INTO `mny_address` VALUES ('250', '东莞市', '1', '0', '19', '2');
INSERT INTO `mny_address` VALUES ('251', '中山市', '1', '0', '19', '2');
INSERT INTO `mny_address` VALUES ('252', '潮州市', '1', '0', '19', '2');
INSERT INTO `mny_address` VALUES ('253', '揭阳市', '1', '0', '19', '2');
INSERT INTO `mny_address` VALUES ('254', '云浮市', '1', '0', '19', '2');
INSERT INTO `mny_address` VALUES ('255', '南宁市', '1', '0', '20', '2');
INSERT INTO `mny_address` VALUES ('256', '柳州市', '1', '0', '20', '2');
INSERT INTO `mny_address` VALUES ('257', '桂林市', '1', '0', '20', '2');
INSERT INTO `mny_address` VALUES ('258', '梧州市', '1', '0', '20', '2');
INSERT INTO `mny_address` VALUES ('259', '北海市', '1', '0', '20', '2');
INSERT INTO `mny_address` VALUES ('260', '防城港市', '1', '0', '20', '2');
INSERT INTO `mny_address` VALUES ('261', '钦州市', '1', '0', '20', '2');
INSERT INTO `mny_address` VALUES ('262', '贵港市', '1', '0', '20', '2');
INSERT INTO `mny_address` VALUES ('263', '玉林市', '1', '0', '20', '2');
INSERT INTO `mny_address` VALUES ('264', '百色市', '1', '0', '20', '2');
INSERT INTO `mny_address` VALUES ('265', '贺州市', '1', '0', '20', '2');
INSERT INTO `mny_address` VALUES ('266', '河池市', '1', '0', '20', '2');
INSERT INTO `mny_address` VALUES ('267', '来宾市', '1', '0', '20', '2');
INSERT INTO `mny_address` VALUES ('268', '崇左市', '1', '0', '20', '2');
INSERT INTO `mny_address` VALUES ('269', '海口市', '1', '0', '21', '2');
INSERT INTO `mny_address` VALUES ('270', '三亚市', '1', '0', '21', '2');
INSERT INTO `mny_address` VALUES ('271', '省直辖县级行政单位', '1', '0', '21', '2');
INSERT INTO `mny_address` VALUES ('272', '市辖区', '1', '0', '22', '2');
INSERT INTO `mny_address` VALUES ('273', '县', '1', '0', '22', '2');
INSERT INTO `mny_address` VALUES ('274', '市', '1', '0', '22', '2');
INSERT INTO `mny_address` VALUES ('275', '成都市', '1', '0', '23', '2');
INSERT INTO `mny_address` VALUES ('276', '自贡市', '1', '0', '23', '2');
INSERT INTO `mny_address` VALUES ('277', '攀枝花市', '1', '0', '23', '2');
INSERT INTO `mny_address` VALUES ('278', '泸州市', '1', '0', '23', '2');
INSERT INTO `mny_address` VALUES ('279', '德阳市', '1', '0', '23', '2');
INSERT INTO `mny_address` VALUES ('280', '绵阳市', '1', '0', '23', '2');
INSERT INTO `mny_address` VALUES ('281', '广元市', '1', '0', '23', '2');
INSERT INTO `mny_address` VALUES ('282', '遂宁市', '1', '0', '23', '2');
INSERT INTO `mny_address` VALUES ('283', '内江市', '1', '0', '23', '2');
INSERT INTO `mny_address` VALUES ('284', '乐山市', '1', '0', '23', '2');
INSERT INTO `mny_address` VALUES ('285', '南充市', '1', '0', '23', '2');
INSERT INTO `mny_address` VALUES ('286', '眉山市', '1', '0', '23', '2');
INSERT INTO `mny_address` VALUES ('287', '宜宾市', '1', '0', '23', '2');
INSERT INTO `mny_address` VALUES ('288', '广安市', '1', '0', '23', '2');
INSERT INTO `mny_address` VALUES ('289', '达州市', '1', '0', '23', '2');
INSERT INTO `mny_address` VALUES ('290', '雅安市', '1', '0', '23', '2');
INSERT INTO `mny_address` VALUES ('291', '巴中市', '1', '0', '23', '2');
INSERT INTO `mny_address` VALUES ('292', '资阳市', '1', '0', '23', '2');
INSERT INTO `mny_address` VALUES ('293', '阿坝藏族羌族自治州', '1', '0', '23', '2');
INSERT INTO `mny_address` VALUES ('294', '甘孜藏族自治州', '1', '0', '23', '2');
INSERT INTO `mny_address` VALUES ('295', '凉山彝族自治州', '1', '0', '23', '2');
INSERT INTO `mny_address` VALUES ('296', '贵阳市', '1', '0', '24', '2');
INSERT INTO `mny_address` VALUES ('297', '六盘水市', '1', '0', '24', '2');
INSERT INTO `mny_address` VALUES ('298', '遵义市', '1', '0', '24', '2');
INSERT INTO `mny_address` VALUES ('299', '安顺市', '1', '0', '24', '2');
INSERT INTO `mny_address` VALUES ('300', '铜仁地区', '1', '0', '24', '2');
INSERT INTO `mny_address` VALUES ('301', '黔西南布依族苗族自治州', '1', '0', '24', '2');
INSERT INTO `mny_address` VALUES ('302', '毕节地区', '1', '0', '24', '2');
INSERT INTO `mny_address` VALUES ('303', '黔东南苗族侗族自治州', '1', '0', '24', '2');
INSERT INTO `mny_address` VALUES ('304', '黔南布依族苗族自治州', '1', '0', '24', '2');
INSERT INTO `mny_address` VALUES ('305', '昆明市', '1', '0', '25', '2');
INSERT INTO `mny_address` VALUES ('306', '曲靖市', '1', '0', '25', '2');
INSERT INTO `mny_address` VALUES ('307', '玉溪市', '1', '0', '25', '2');
INSERT INTO `mny_address` VALUES ('308', '保山市', '1', '0', '25', '2');
INSERT INTO `mny_address` VALUES ('309', '昭通市', '1', '0', '25', '2');
INSERT INTO `mny_address` VALUES ('310', '丽江市', '1', '0', '25', '2');
INSERT INTO `mny_address` VALUES ('311', '思茅市', '1', '0', '25', '2');
INSERT INTO `mny_address` VALUES ('312', '临沧市', '1', '0', '25', '2');
INSERT INTO `mny_address` VALUES ('313', '楚雄彝族自治州', '1', '0', '25', '2');
INSERT INTO `mny_address` VALUES ('314', '红河哈尼族彝族自治州', '1', '0', '25', '2');
INSERT INTO `mny_address` VALUES ('315', '文山壮族苗族自治州', '1', '0', '25', '2');
INSERT INTO `mny_address` VALUES ('316', '西双版纳傣族自治州', '1', '0', '25', '2');
INSERT INTO `mny_address` VALUES ('317', '大理白族自治州', '1', '0', '25', '2');
INSERT INTO `mny_address` VALUES ('318', '德宏傣族景颇族自治州', '1', '0', '25', '2');
INSERT INTO `mny_address` VALUES ('319', '怒江傈僳族自治州', '1', '0', '25', '2');
INSERT INTO `mny_address` VALUES ('320', '迪庆藏族自治州', '1', '0', '25', '2');
INSERT INTO `mny_address` VALUES ('321', '拉萨市', '1', '0', '26', '2');
INSERT INTO `mny_address` VALUES ('322', '昌都地区', '1', '0', '26', '2');
INSERT INTO `mny_address` VALUES ('323', '山南地区', '1', '0', '26', '2');
INSERT INTO `mny_address` VALUES ('324', '日喀则地区', '1', '0', '26', '2');
INSERT INTO `mny_address` VALUES ('325', '那曲地区', '1', '0', '26', '2');
INSERT INTO `mny_address` VALUES ('326', '阿里地区', '1', '0', '26', '2');
INSERT INTO `mny_address` VALUES ('327', '林芝地区', '1', '0', '26', '2');
INSERT INTO `mny_address` VALUES ('328', '西安市', '1', '0', '27', '2');
INSERT INTO `mny_address` VALUES ('329', '铜川市', '1', '0', '27', '2');
INSERT INTO `mny_address` VALUES ('330', '宝鸡市', '1', '0', '27', '2');
INSERT INTO `mny_address` VALUES ('331', '咸阳市', '1', '0', '27', '2');
INSERT INTO `mny_address` VALUES ('332', '渭南市', '1', '0', '27', '2');
INSERT INTO `mny_address` VALUES ('333', '延安市', '1', '0', '27', '2');
INSERT INTO `mny_address` VALUES ('334', '汉中市', '1', '0', '27', '2');
INSERT INTO `mny_address` VALUES ('335', '榆林市', '1', '0', '27', '2');
INSERT INTO `mny_address` VALUES ('336', '安康市', '1', '0', '27', '2');
INSERT INTO `mny_address` VALUES ('337', '商洛市', '1', '0', '27', '2');
INSERT INTO `mny_address` VALUES ('338', '兰州市', '1', '0', '28', '2');
INSERT INTO `mny_address` VALUES ('339', '嘉峪关市', '1', '0', '28', '2');
INSERT INTO `mny_address` VALUES ('340', '金昌市', '1', '0', '28', '2');
INSERT INTO `mny_address` VALUES ('341', '白银市', '1', '0', '28', '2');
INSERT INTO `mny_address` VALUES ('342', '天水市', '1', '0', '28', '2');
INSERT INTO `mny_address` VALUES ('343', '武威市', '1', '0', '28', '2');
INSERT INTO `mny_address` VALUES ('344', '张掖市', '1', '0', '28', '2');
INSERT INTO `mny_address` VALUES ('345', '平凉市', '1', '0', '28', '2');
INSERT INTO `mny_address` VALUES ('346', '酒泉市', '1', '0', '28', '2');
INSERT INTO `mny_address` VALUES ('347', '庆阳市', '1', '0', '28', '2');
INSERT INTO `mny_address` VALUES ('348', '定西市', '1', '0', '28', '2');
INSERT INTO `mny_address` VALUES ('349', '陇南市', '1', '0', '28', '2');
INSERT INTO `mny_address` VALUES ('350', '临夏回族自治州', '1', '0', '28', '2');
INSERT INTO `mny_address` VALUES ('351', '甘南藏族自治州', '1', '0', '28', '2');
INSERT INTO `mny_address` VALUES ('352', '西宁市', '1', '0', '29', '2');
INSERT INTO `mny_address` VALUES ('353', '海东地区', '1', '0', '29', '2');
INSERT INTO `mny_address` VALUES ('354', '海北藏族自治州', '1', '0', '29', '2');
INSERT INTO `mny_address` VALUES ('355', '黄南藏族自治州', '1', '0', '29', '2');
INSERT INTO `mny_address` VALUES ('356', '海南藏族自治州', '1', '0', '29', '2');
INSERT INTO `mny_address` VALUES ('357', '果洛藏族自治州', '1', '0', '29', '2');
INSERT INTO `mny_address` VALUES ('358', '玉树藏族自治州', '1', '0', '29', '2');
INSERT INTO `mny_address` VALUES ('359', '海西蒙古族藏族自治州', '1', '0', '29', '2');
INSERT INTO `mny_address` VALUES ('360', '银川市', '1', '0', '30', '2');
INSERT INTO `mny_address` VALUES ('361', '石嘴山市', '1', '0', '30', '2');
INSERT INTO `mny_address` VALUES ('362', '吴忠市', '1', '0', '30', '2');
INSERT INTO `mny_address` VALUES ('363', '固原市', '1', '0', '30', '2');
INSERT INTO `mny_address` VALUES ('364', '中卫市', '1', '0', '30', '2');
INSERT INTO `mny_address` VALUES ('365', '乌鲁木齐市', '1', '0', '31', '2');
INSERT INTO `mny_address` VALUES ('366', '克拉玛依市', '1', '0', '31', '2');
INSERT INTO `mny_address` VALUES ('367', '吐鲁番地区', '1', '0', '31', '2');
INSERT INTO `mny_address` VALUES ('368', '哈密地区', '1', '0', '31', '2');
INSERT INTO `mny_address` VALUES ('369', '昌吉回族自治州', '1', '0', '31', '2');
INSERT INTO `mny_address` VALUES ('370', '博尔塔拉蒙古自治州', '1', '0', '31', '2');
INSERT INTO `mny_address` VALUES ('371', '巴音郭楞蒙古自治州', '1', '0', '31', '2');
INSERT INTO `mny_address` VALUES ('372', '阿克苏地区', '1', '0', '31', '2');
INSERT INTO `mny_address` VALUES ('373', '克孜勒苏柯尔克孜自治州', '1', '0', '31', '2');
INSERT INTO `mny_address` VALUES ('374', '喀什地区', '1', '0', '31', '2');
INSERT INTO `mny_address` VALUES ('375', '和田地区', '1', '0', '31', '2');
INSERT INTO `mny_address` VALUES ('376', '伊犁哈萨克自治州', '1', '0', '31', '2');
INSERT INTO `mny_address` VALUES ('377', '塔城地区', '1', '0', '31', '2');
INSERT INTO `mny_address` VALUES ('378', '阿勒泰地区', '1', '0', '31', '2');
INSERT INTO `mny_address` VALUES ('379', '省直辖行政单位', '1', '0', '31', '2');
INSERT INTO `mny_address` VALUES ('380', '东城区', '1', '0', '35', '3');
INSERT INTO `mny_address` VALUES ('381', '西城区', '1', '0', '35', '3');
INSERT INTO `mny_address` VALUES ('382', '崇文区', '1', '0', '35', '3');
INSERT INTO `mny_address` VALUES ('383', '宣武区', '1', '0', '35', '3');
INSERT INTO `mny_address` VALUES ('384', '朝阳区', '1', '0', '35', '3');
INSERT INTO `mny_address` VALUES ('385', '丰台区', '1', '0', '35', '3');
INSERT INTO `mny_address` VALUES ('386', '石景山区', '1', '0', '35', '3');
INSERT INTO `mny_address` VALUES ('387', '海淀区', '1', '0', '35', '3');
INSERT INTO `mny_address` VALUES ('388', '门头沟区', '1', '0', '35', '3');
INSERT INTO `mny_address` VALUES ('389', '房山区', '1', '0', '35', '3');
INSERT INTO `mny_address` VALUES ('390', '通州区', '1', '0', '35', '3');
INSERT INTO `mny_address` VALUES ('391', '顺义区', '1', '0', '35', '3');
INSERT INTO `mny_address` VALUES ('392', '昌平区', '1', '0', '35', '3');
INSERT INTO `mny_address` VALUES ('393', '大兴区', '1', '0', '35', '3');
INSERT INTO `mny_address` VALUES ('394', '怀柔区', '1', '0', '35', '3');
INSERT INTO `mny_address` VALUES ('395', '平谷区', '1', '0', '35', '3');
INSERT INTO `mny_address` VALUES ('396', '密云县', '1', '0', '36', '3');
INSERT INTO `mny_address` VALUES ('397', '延庆县', '1', '0', '36', '3');
INSERT INTO `mny_address` VALUES ('398', '和平区', '1', '0', '37', '3');
INSERT INTO `mny_address` VALUES ('399', '河东区', '1', '0', '37', '3');
INSERT INTO `mny_address` VALUES ('400', '河西区', '1', '0', '37', '3');
INSERT INTO `mny_address` VALUES ('401', '南开区', '1', '0', '37', '3');
INSERT INTO `mny_address` VALUES ('402', '河北区', '1', '0', '37', '3');
INSERT INTO `mny_address` VALUES ('403', '红桥区', '1', '0', '37', '3');
INSERT INTO `mny_address` VALUES ('404', '塘沽区', '1', '0', '37', '3');
INSERT INTO `mny_address` VALUES ('405', '汉沽区', '1', '0', '37', '3');
INSERT INTO `mny_address` VALUES ('406', '大港区', '1', '0', '37', '3');
INSERT INTO `mny_address` VALUES ('407', '东丽区', '1', '0', '37', '3');
INSERT INTO `mny_address` VALUES ('408', '西青区', '1', '0', '37', '3');
INSERT INTO `mny_address` VALUES ('409', '津南区', '1', '0', '37', '3');
INSERT INTO `mny_address` VALUES ('410', '北辰区', '1', '0', '37', '3');
INSERT INTO `mny_address` VALUES ('411', '武清区', '1', '0', '37', '3');
INSERT INTO `mny_address` VALUES ('412', '宝坻区', '1', '0', '37', '3');
INSERT INTO `mny_address` VALUES ('413', '宁河县', '1', '0', '38', '3');
INSERT INTO `mny_address` VALUES ('414', '静海县', '1', '0', '38', '3');
INSERT INTO `mny_address` VALUES ('415', '蓟　县', '1', '0', '38', '3');
INSERT INTO `mny_address` VALUES ('416', '市辖区', '1', '0', '39', '3');
INSERT INTO `mny_address` VALUES ('417', '长安区', '1', '0', '39', '3');
INSERT INTO `mny_address` VALUES ('418', '桥东区', '1', '0', '39', '3');
INSERT INTO `mny_address` VALUES ('419', '桥西区', '1', '0', '39', '3');
INSERT INTO `mny_address` VALUES ('420', '新华区', '1', '0', '39', '3');
INSERT INTO `mny_address` VALUES ('421', '井陉矿区', '1', '0', '39', '3');
INSERT INTO `mny_address` VALUES ('422', '裕华区', '1', '0', '39', '3');
INSERT INTO `mny_address` VALUES ('423', '井陉县', '1', '0', '39', '3');
INSERT INTO `mny_address` VALUES ('424', '正定县', '1', '0', '39', '3');
INSERT INTO `mny_address` VALUES ('425', '栾城县', '1', '0', '39', '3');
INSERT INTO `mny_address` VALUES ('426', '行唐县', '1', '0', '39', '3');
INSERT INTO `mny_address` VALUES ('427', '灵寿县', '1', '0', '39', '3');
INSERT INTO `mny_address` VALUES ('428', '高邑县', '1', '0', '39', '3');
INSERT INTO `mny_address` VALUES ('429', '深泽县', '1', '0', '39', '3');
INSERT INTO `mny_address` VALUES ('430', '赞皇县', '1', '0', '39', '3');
INSERT INTO `mny_address` VALUES ('431', '无极县', '1', '0', '39', '3');
INSERT INTO `mny_address` VALUES ('432', '平山县', '1', '0', '39', '3');
INSERT INTO `mny_address` VALUES ('433', '元氏县', '1', '0', '39', '3');
INSERT INTO `mny_address` VALUES ('434', '赵　县', '1', '0', '39', '3');
INSERT INTO `mny_address` VALUES ('435', '辛集市', '1', '0', '39', '3');
INSERT INTO `mny_address` VALUES ('436', '藁城市', '1', '0', '39', '3');
INSERT INTO `mny_address` VALUES ('437', '晋州市', '1', '0', '39', '3');
INSERT INTO `mny_address` VALUES ('438', '新乐市', '1', '0', '39', '3');
INSERT INTO `mny_address` VALUES ('439', '鹿泉市', '1', '0', '39', '3');
INSERT INTO `mny_address` VALUES ('440', '市辖区', '1', '0', '40', '3');
INSERT INTO `mny_address` VALUES ('441', '路南区', '1', '0', '40', '3');
INSERT INTO `mny_address` VALUES ('442', '路北区', '1', '0', '40', '3');
INSERT INTO `mny_address` VALUES ('443', '古冶区', '1', '0', '40', '3');
INSERT INTO `mny_address` VALUES ('444', '开平区', '1', '0', '40', '3');
INSERT INTO `mny_address` VALUES ('445', '丰南区', '1', '0', '40', '3');
INSERT INTO `mny_address` VALUES ('446', '丰润区', '1', '0', '40', '3');
INSERT INTO `mny_address` VALUES ('447', '滦　县', '1', '0', '40', '3');
INSERT INTO `mny_address` VALUES ('448', '滦南县', '1', '0', '40', '3');
INSERT INTO `mny_address` VALUES ('449', '乐亭县', '1', '0', '40', '3');
INSERT INTO `mny_address` VALUES ('450', '迁西县', '1', '0', '40', '3');
INSERT INTO `mny_address` VALUES ('451', '玉田县', '1', '0', '40', '3');
INSERT INTO `mny_address` VALUES ('452', '唐海县', '1', '0', '40', '3');
INSERT INTO `mny_address` VALUES ('453', '遵化市', '1', '0', '40', '3');
INSERT INTO `mny_address` VALUES ('454', '迁安市', '1', '0', '40', '3');
INSERT INTO `mny_address` VALUES ('455', '市辖区', '1', '0', '41', '3');
INSERT INTO `mny_address` VALUES ('456', '海港区', '1', '0', '41', '3');
INSERT INTO `mny_address` VALUES ('457', '山海关区', '1', '0', '41', '3');
INSERT INTO `mny_address` VALUES ('458', '北戴河区', '1', '0', '41', '3');
INSERT INTO `mny_address` VALUES ('459', '青龙满族自治县', '1', '0', '41', '3');
INSERT INTO `mny_address` VALUES ('460', '昌黎县', '1', '0', '41', '3');
INSERT INTO `mny_address` VALUES ('461', '抚宁县', '1', '0', '41', '3');
INSERT INTO `mny_address` VALUES ('462', '卢龙县', '1', '0', '41', '3');
INSERT INTO `mny_address` VALUES ('463', '市辖区', '1', '0', '42', '3');
INSERT INTO `mny_address` VALUES ('464', '邯山区', '1', '0', '42', '3');
INSERT INTO `mny_address` VALUES ('465', '丛台区', '1', '0', '42', '3');
INSERT INTO `mny_address` VALUES ('466', '复兴区', '1', '0', '42', '3');
INSERT INTO `mny_address` VALUES ('467', '峰峰矿区', '1', '0', '42', '3');
INSERT INTO `mny_address` VALUES ('468', '邯郸县', '1', '0', '42', '3');
INSERT INTO `mny_address` VALUES ('469', '临漳县', '1', '0', '42', '3');
INSERT INTO `mny_address` VALUES ('470', '成安县', '1', '0', '42', '3');
INSERT INTO `mny_address` VALUES ('471', '大名县', '1', '0', '42', '3');
INSERT INTO `mny_address` VALUES ('472', '涉　县', '1', '0', '42', '3');
INSERT INTO `mny_address` VALUES ('473', '磁　县', '1', '0', '42', '3');
INSERT INTO `mny_address` VALUES ('474', '肥乡县', '1', '0', '42', '3');
INSERT INTO `mny_address` VALUES ('475', '永年县', '1', '0', '42', '3');
INSERT INTO `mny_address` VALUES ('476', '邱　县', '1', '0', '42', '3');
INSERT INTO `mny_address` VALUES ('477', '鸡泽县', '1', '0', '42', '3');
INSERT INTO `mny_address` VALUES ('478', '广平县', '1', '0', '42', '3');
INSERT INTO `mny_address` VALUES ('479', '馆陶县', '1', '0', '42', '3');
INSERT INTO `mny_address` VALUES ('480', '魏　县', '1', '0', '42', '3');
INSERT INTO `mny_address` VALUES ('481', '曲周县', '1', '0', '42', '3');
INSERT INTO `mny_address` VALUES ('482', '武安市', '1', '0', '42', '3');
INSERT INTO `mny_address` VALUES ('483', '市辖区', '1', '0', '43', '3');
INSERT INTO `mny_address` VALUES ('484', '桥东区', '1', '0', '43', '3');
INSERT INTO `mny_address` VALUES ('485', '桥西区', '1', '0', '43', '3');
INSERT INTO `mny_address` VALUES ('486', '邢台县', '1', '0', '43', '3');
INSERT INTO `mny_address` VALUES ('487', '临城县', '1', '0', '43', '3');
INSERT INTO `mny_address` VALUES ('488', '内丘县', '1', '0', '43', '3');
INSERT INTO `mny_address` VALUES ('489', '柏乡县', '1', '0', '43', '3');
INSERT INTO `mny_address` VALUES ('490', '隆尧县', '1', '0', '43', '3');
INSERT INTO `mny_address` VALUES ('491', '任　县', '1', '0', '43', '3');
INSERT INTO `mny_address` VALUES ('492', '南和县', '1', '0', '43', '3');
INSERT INTO `mny_address` VALUES ('493', '宁晋县', '1', '0', '43', '3');
INSERT INTO `mny_address` VALUES ('494', '巨鹿县', '1', '0', '43', '3');
INSERT INTO `mny_address` VALUES ('495', '新河县', '1', '0', '43', '3');
INSERT INTO `mny_address` VALUES ('496', '广宗县', '1', '0', '43', '3');
INSERT INTO `mny_address` VALUES ('497', '平乡县', '1', '0', '43', '3');
INSERT INTO `mny_address` VALUES ('498', '威　县', '1', '0', '43', '3');
INSERT INTO `mny_address` VALUES ('499', '清河县', '1', '0', '43', '3');
INSERT INTO `mny_address` VALUES ('500', '临西县', '1', '0', '43', '3');
INSERT INTO `mny_address` VALUES ('501', '南宫市', '1', '0', '43', '3');
INSERT INTO `mny_address` VALUES ('502', '沙河市', '1', '0', '43', '3');
INSERT INTO `mny_address` VALUES ('503', '市辖区', '1', '0', '44', '3');
INSERT INTO `mny_address` VALUES ('504', '新市区', '1', '0', '44', '3');
INSERT INTO `mny_address` VALUES ('505', '北市区', '1', '0', '44', '3');
INSERT INTO `mny_address` VALUES ('506', '南市区', '1', '0', '44', '3');
INSERT INTO `mny_address` VALUES ('507', '满城县', '1', '0', '44', '3');
INSERT INTO `mny_address` VALUES ('508', '清苑县', '1', '0', '44', '3');
INSERT INTO `mny_address` VALUES ('509', '涞水县', '1', '0', '44', '3');
INSERT INTO `mny_address` VALUES ('510', '阜平县', '1', '0', '44', '3');
INSERT INTO `mny_address` VALUES ('511', '徐水县', '1', '0', '44', '3');
INSERT INTO `mny_address` VALUES ('512', '定兴县', '1', '0', '44', '3');
INSERT INTO `mny_address` VALUES ('513', '唐　县', '1', '0', '44', '3');
INSERT INTO `mny_address` VALUES ('514', '高阳县', '1', '0', '44', '3');
INSERT INTO `mny_address` VALUES ('515', '容城县', '1', '0', '44', '3');
INSERT INTO `mny_address` VALUES ('516', '涞源县', '1', '0', '44', '3');
INSERT INTO `mny_address` VALUES ('517', '望都县', '1', '0', '44', '3');
INSERT INTO `mny_address` VALUES ('518', '安新县', '1', '0', '44', '3');
INSERT INTO `mny_address` VALUES ('519', '易　县', '1', '0', '44', '3');
INSERT INTO `mny_address` VALUES ('520', '曲阳县', '1', '0', '44', '3');
INSERT INTO `mny_address` VALUES ('521', '蠡　县', '1', '0', '44', '3');
INSERT INTO `mny_address` VALUES ('522', '顺平县', '1', '0', '44', '3');
INSERT INTO `mny_address` VALUES ('523', '博野县', '1', '0', '44', '3');
INSERT INTO `mny_address` VALUES ('524', '雄　县', '1', '0', '44', '3');
INSERT INTO `mny_address` VALUES ('525', '涿州市', '1', '0', '44', '3');
INSERT INTO `mny_address` VALUES ('526', '定州市', '1', '0', '44', '3');
INSERT INTO `mny_address` VALUES ('527', '安国市', '1', '0', '44', '3');
INSERT INTO `mny_address` VALUES ('528', '高碑店市', '1', '0', '44', '3');
INSERT INTO `mny_address` VALUES ('529', '市辖区', '1', '0', '45', '3');
INSERT INTO `mny_address` VALUES ('530', '桥东区', '1', '0', '45', '3');
INSERT INTO `mny_address` VALUES ('531', '桥西区', '1', '0', '45', '3');
INSERT INTO `mny_address` VALUES ('532', '宣化区', '1', '0', '45', '3');
INSERT INTO `mny_address` VALUES ('533', '下花园区', '1', '0', '45', '3');
INSERT INTO `mny_address` VALUES ('534', '宣化县', '1', '0', '45', '3');
INSERT INTO `mny_address` VALUES ('535', '张北县', '1', '0', '45', '3');
INSERT INTO `mny_address` VALUES ('536', '康保县', '1', '0', '45', '3');
INSERT INTO `mny_address` VALUES ('537', '沽源县', '1', '0', '45', '3');
INSERT INTO `mny_address` VALUES ('538', '尚义县', '1', '0', '45', '3');
INSERT INTO `mny_address` VALUES ('539', '蔚　县', '1', '0', '45', '3');
INSERT INTO `mny_address` VALUES ('540', '阳原县', '1', '0', '45', '3');
INSERT INTO `mny_address` VALUES ('541', '怀安县', '1', '0', '45', '3');
INSERT INTO `mny_address` VALUES ('542', '万全县', '1', '0', '45', '3');
INSERT INTO `mny_address` VALUES ('543', '怀来县', '1', '0', '45', '3');
INSERT INTO `mny_address` VALUES ('544', '涿鹿县', '1', '0', '45', '3');
INSERT INTO `mny_address` VALUES ('545', '赤城县', '1', '0', '45', '3');
INSERT INTO `mny_address` VALUES ('546', '崇礼县', '1', '0', '45', '3');
INSERT INTO `mny_address` VALUES ('547', '市辖区', '1', '0', '46', '3');
INSERT INTO `mny_address` VALUES ('548', '双桥区', '1', '0', '46', '3');
INSERT INTO `mny_address` VALUES ('549', '双滦区', '1', '0', '46', '3');
INSERT INTO `mny_address` VALUES ('550', '鹰手营子矿区', '1', '0', '46', '3');
INSERT INTO `mny_address` VALUES ('551', '承德县', '1', '0', '46', '3');
INSERT INTO `mny_address` VALUES ('552', '兴隆县', '1', '0', '46', '3');
INSERT INTO `mny_address` VALUES ('553', '平泉县', '1', '0', '46', '3');
INSERT INTO `mny_address` VALUES ('554', '滦平县', '1', '0', '46', '3');
INSERT INTO `mny_address` VALUES ('555', '隆化县', '1', '0', '46', '3');
INSERT INTO `mny_address` VALUES ('556', '丰宁满族自治县', '1', '0', '46', '3');
INSERT INTO `mny_address` VALUES ('557', '宽城满族自治县', '1', '0', '46', '3');
INSERT INTO `mny_address` VALUES ('558', '围场满族蒙古族自治县', '1', '0', '46', '3');
INSERT INTO `mny_address` VALUES ('559', '市辖区', '1', '0', '47', '3');
INSERT INTO `mny_address` VALUES ('560', '新华区', '1', '0', '47', '3');
INSERT INTO `mny_address` VALUES ('561', '运河区', '1', '0', '47', '3');
INSERT INTO `mny_address` VALUES ('562', '沧　县', '1', '0', '47', '3');
INSERT INTO `mny_address` VALUES ('563', '青　县', '1', '0', '47', '3');
INSERT INTO `mny_address` VALUES ('564', '东光县', '1', '0', '47', '3');
INSERT INTO `mny_address` VALUES ('565', '海兴县', '1', '0', '47', '3');
INSERT INTO `mny_address` VALUES ('566', '盐山县', '1', '0', '47', '3');
INSERT INTO `mny_address` VALUES ('567', '肃宁县', '1', '0', '47', '3');
INSERT INTO `mny_address` VALUES ('568', '南皮县', '1', '0', '47', '3');
INSERT INTO `mny_address` VALUES ('569', '吴桥县', '1', '0', '47', '3');
INSERT INTO `mny_address` VALUES ('570', '献　县', '1', '0', '47', '3');
INSERT INTO `mny_address` VALUES ('571', '孟村回族自治县', '1', '0', '47', '3');
INSERT INTO `mny_address` VALUES ('572', '泊头市', '1', '0', '47', '3');
INSERT INTO `mny_address` VALUES ('573', '任丘市', '1', '0', '47', '3');
INSERT INTO `mny_address` VALUES ('574', '黄骅市', '1', '0', '47', '3');
INSERT INTO `mny_address` VALUES ('575', '河间市', '1', '0', '47', '3');
INSERT INTO `mny_address` VALUES ('576', '市辖区', '1', '0', '48', '3');
INSERT INTO `mny_address` VALUES ('577', '安次区', '1', '0', '48', '3');
INSERT INTO `mny_address` VALUES ('578', '广阳区', '1', '0', '48', '3');
INSERT INTO `mny_address` VALUES ('579', '固安县', '1', '0', '48', '3');
INSERT INTO `mny_address` VALUES ('580', '永清县', '1', '0', '48', '3');
INSERT INTO `mny_address` VALUES ('581', '香河县', '1', '0', '48', '3');
INSERT INTO `mny_address` VALUES ('582', '大城县', '1', '0', '48', '3');
INSERT INTO `mny_address` VALUES ('583', '文安县', '1', '0', '48', '3');
INSERT INTO `mny_address` VALUES ('584', '大厂回族自治县', '1', '0', '48', '3');
INSERT INTO `mny_address` VALUES ('585', '霸州市', '1', '0', '48', '3');
INSERT INTO `mny_address` VALUES ('586', '三河市', '1', '0', '48', '3');
INSERT INTO `mny_address` VALUES ('587', '市辖区', '1', '0', '49', '3');
INSERT INTO `mny_address` VALUES ('588', '桃城区', '1', '0', '49', '3');
INSERT INTO `mny_address` VALUES ('589', '枣强县', '1', '0', '49', '3');
INSERT INTO `mny_address` VALUES ('590', '武邑县', '1', '0', '49', '3');
INSERT INTO `mny_address` VALUES ('591', '武强县', '1', '0', '49', '3');
INSERT INTO `mny_address` VALUES ('592', '饶阳县', '1', '0', '49', '3');
INSERT INTO `mny_address` VALUES ('593', '安平县', '1', '0', '49', '3');
INSERT INTO `mny_address` VALUES ('594', '故城县', '1', '0', '49', '3');
INSERT INTO `mny_address` VALUES ('595', '景　县', '1', '0', '49', '3');
INSERT INTO `mny_address` VALUES ('596', '阜城县', '1', '0', '49', '3');
INSERT INTO `mny_address` VALUES ('597', '冀州市', '1', '0', '49', '3');
INSERT INTO `mny_address` VALUES ('598', '深州市', '1', '0', '49', '3');
INSERT INTO `mny_address` VALUES ('599', '市辖区', '1', '0', '50', '3');
INSERT INTO `mny_address` VALUES ('600', '小店区', '1', '0', '50', '3');
INSERT INTO `mny_address` VALUES ('601', '迎泽区', '1', '0', '50', '3');
INSERT INTO `mny_address` VALUES ('602', '杏花岭区', '1', '0', '50', '3');
INSERT INTO `mny_address` VALUES ('603', '尖草坪区', '1', '0', '50', '3');
INSERT INTO `mny_address` VALUES ('604', '万柏林区', '1', '0', '50', '3');
INSERT INTO `mny_address` VALUES ('605', '晋源区', '1', '0', '50', '3');
INSERT INTO `mny_address` VALUES ('606', '清徐县', '1', '0', '50', '3');
INSERT INTO `mny_address` VALUES ('607', '阳曲县', '1', '0', '50', '3');
INSERT INTO `mny_address` VALUES ('608', '娄烦县', '1', '0', '50', '3');
INSERT INTO `mny_address` VALUES ('609', '古交市', '1', '0', '50', '3');
INSERT INTO `mny_address` VALUES ('610', '市辖区', '1', '0', '51', '3');
INSERT INTO `mny_address` VALUES ('611', '城　区', '1', '0', '51', '3');
INSERT INTO `mny_address` VALUES ('612', '矿　区', '1', '0', '51', '3');
INSERT INTO `mny_address` VALUES ('613', '南郊区', '1', '0', '51', '3');
INSERT INTO `mny_address` VALUES ('614', '新荣区', '1', '0', '51', '3');
INSERT INTO `mny_address` VALUES ('615', '阳高县', '1', '0', '51', '3');
INSERT INTO `mny_address` VALUES ('616', '天镇县', '1', '0', '51', '3');
INSERT INTO `mny_address` VALUES ('617', '广灵县', '1', '0', '51', '3');
INSERT INTO `mny_address` VALUES ('618', '灵丘县', '1', '0', '51', '3');
INSERT INTO `mny_address` VALUES ('619', '浑源县', '1', '0', '51', '3');
INSERT INTO `mny_address` VALUES ('620', '左云县', '1', '0', '51', '3');
INSERT INTO `mny_address` VALUES ('621', '大同县', '1', '0', '51', '3');
INSERT INTO `mny_address` VALUES ('622', '市辖区', '1', '0', '52', '3');
INSERT INTO `mny_address` VALUES ('623', '城　区', '1', '0', '52', '3');
INSERT INTO `mny_address` VALUES ('624', '矿　区', '1', '0', '52', '3');
INSERT INTO `mny_address` VALUES ('625', '郊　区', '1', '0', '52', '3');
INSERT INTO `mny_address` VALUES ('626', '平定县', '1', '0', '52', '3');
INSERT INTO `mny_address` VALUES ('627', '盂　县', '1', '0', '52', '3');
INSERT INTO `mny_address` VALUES ('628', '市辖区', '1', '0', '53', '3');
INSERT INTO `mny_address` VALUES ('629', '城　区', '1', '0', '53', '3');
INSERT INTO `mny_address` VALUES ('630', '郊　区', '1', '0', '53', '3');
INSERT INTO `mny_address` VALUES ('631', '长治县', '1', '0', '53', '3');
INSERT INTO `mny_address` VALUES ('632', '襄垣县', '1', '0', '53', '3');
INSERT INTO `mny_address` VALUES ('633', '屯留县', '1', '0', '53', '3');
INSERT INTO `mny_address` VALUES ('634', '平顺县', '1', '0', '53', '3');
INSERT INTO `mny_address` VALUES ('635', '黎城县', '1', '0', '53', '3');
INSERT INTO `mny_address` VALUES ('636', '壶关县', '1', '0', '53', '3');
INSERT INTO `mny_address` VALUES ('637', '长子县', '1', '0', '53', '3');
INSERT INTO `mny_address` VALUES ('638', '武乡县', '1', '0', '53', '3');
INSERT INTO `mny_address` VALUES ('639', '沁　县', '1', '0', '53', '3');
INSERT INTO `mny_address` VALUES ('640', '沁源县', '1', '0', '53', '3');
INSERT INTO `mny_address` VALUES ('641', '潞城市', '1', '0', '53', '3');
INSERT INTO `mny_address` VALUES ('642', '市辖区', '1', '0', '54', '3');
INSERT INTO `mny_address` VALUES ('643', '城　区', '1', '0', '54', '3');
INSERT INTO `mny_address` VALUES ('644', '沁水县', '1', '0', '54', '3');
INSERT INTO `mny_address` VALUES ('645', '阳城县', '1', '0', '54', '3');
INSERT INTO `mny_address` VALUES ('646', '陵川县', '1', '0', '54', '3');
INSERT INTO `mny_address` VALUES ('647', '泽州县', '1', '0', '54', '3');
INSERT INTO `mny_address` VALUES ('648', '高平市', '1', '0', '54', '3');
INSERT INTO `mny_address` VALUES ('649', '市辖区', '1', '0', '55', '3');
INSERT INTO `mny_address` VALUES ('650', '朔城区', '1', '0', '55', '3');
INSERT INTO `mny_address` VALUES ('651', '平鲁区', '1', '0', '55', '3');
INSERT INTO `mny_address` VALUES ('652', '山阴县', '1', '0', '55', '3');
INSERT INTO `mny_address` VALUES ('653', '应　县', '1', '0', '55', '3');
INSERT INTO `mny_address` VALUES ('654', '右玉县', '1', '0', '55', '3');
INSERT INTO `mny_address` VALUES ('655', '怀仁县', '1', '0', '55', '3');
INSERT INTO `mny_address` VALUES ('656', '市辖区', '1', '0', '56', '3');
INSERT INTO `mny_address` VALUES ('657', '榆次区', '1', '0', '56', '3');
INSERT INTO `mny_address` VALUES ('658', '榆社县', '1', '0', '56', '3');
INSERT INTO `mny_address` VALUES ('659', '左权县', '1', '0', '56', '3');
INSERT INTO `mny_address` VALUES ('660', '和顺县', '1', '0', '56', '3');
INSERT INTO `mny_address` VALUES ('661', '昔阳县', '1', '0', '56', '3');
INSERT INTO `mny_address` VALUES ('662', '寿阳县', '1', '0', '56', '3');
INSERT INTO `mny_address` VALUES ('663', '太谷县', '1', '0', '56', '3');
INSERT INTO `mny_address` VALUES ('664', '祁　县', '1', '0', '56', '3');
INSERT INTO `mny_address` VALUES ('665', '平遥县', '1', '0', '56', '3');
INSERT INTO `mny_address` VALUES ('666', '灵石县', '1', '0', '56', '3');
INSERT INTO `mny_address` VALUES ('667', '介休市', '1', '0', '56', '3');
INSERT INTO `mny_address` VALUES ('668', '市辖区', '1', '0', '57', '3');
INSERT INTO `mny_address` VALUES ('669', '盐湖区', '1', '0', '57', '3');
INSERT INTO `mny_address` VALUES ('670', '临猗县', '1', '0', '57', '3');
INSERT INTO `mny_address` VALUES ('671', '万荣县', '1', '0', '57', '3');
INSERT INTO `mny_address` VALUES ('672', '闻喜县', '1', '0', '57', '3');
INSERT INTO `mny_address` VALUES ('673', '稷山县', '1', '0', '57', '3');
INSERT INTO `mny_address` VALUES ('674', '新绛县', '1', '0', '57', '3');
INSERT INTO `mny_address` VALUES ('675', '绛　县', '1', '0', '57', '3');
INSERT INTO `mny_address` VALUES ('676', '垣曲县', '1', '0', '57', '3');
INSERT INTO `mny_address` VALUES ('677', '夏　县', '1', '0', '57', '3');
INSERT INTO `mny_address` VALUES ('678', '平陆县', '1', '0', '57', '3');
INSERT INTO `mny_address` VALUES ('679', '芮城县', '1', '0', '57', '3');
INSERT INTO `mny_address` VALUES ('680', '永济市', '1', '0', '57', '3');
INSERT INTO `mny_address` VALUES ('681', '河津市', '1', '0', '57', '3');
INSERT INTO `mny_address` VALUES ('682', '市辖区', '1', '0', '58', '3');
INSERT INTO `mny_address` VALUES ('683', '忻府区', '1', '0', '58', '3');
INSERT INTO `mny_address` VALUES ('684', '定襄县', '1', '0', '58', '3');
INSERT INTO `mny_address` VALUES ('685', '五台县', '1', '0', '58', '3');
INSERT INTO `mny_address` VALUES ('686', '代　县', '1', '0', '58', '3');
INSERT INTO `mny_address` VALUES ('687', '繁峙县', '1', '0', '58', '3');
INSERT INTO `mny_address` VALUES ('688', '宁武县', '1', '0', '58', '3');
INSERT INTO `mny_address` VALUES ('689', '静乐县', '1', '0', '58', '3');
INSERT INTO `mny_address` VALUES ('690', '神池县', '1', '0', '58', '3');
INSERT INTO `mny_address` VALUES ('691', '五寨县', '1', '0', '58', '3');
INSERT INTO `mny_address` VALUES ('692', '岢岚县', '1', '0', '58', '3');
INSERT INTO `mny_address` VALUES ('693', '河曲县', '1', '0', '58', '3');
INSERT INTO `mny_address` VALUES ('694', '保德县', '1', '0', '58', '3');
INSERT INTO `mny_address` VALUES ('695', '偏关县', '1', '0', '58', '3');
INSERT INTO `mny_address` VALUES ('696', '原平市', '1', '0', '58', '3');
INSERT INTO `mny_address` VALUES ('697', '市辖区', '1', '0', '59', '3');
INSERT INTO `mny_address` VALUES ('698', '尧都区', '1', '0', '59', '3');
INSERT INTO `mny_address` VALUES ('699', '曲沃县', '1', '0', '59', '3');
INSERT INTO `mny_address` VALUES ('700', '翼城县', '1', '0', '59', '3');
INSERT INTO `mny_address` VALUES ('701', '襄汾县', '1', '0', '59', '3');
INSERT INTO `mny_address` VALUES ('702', '洪洞县', '1', '0', '59', '3');
INSERT INTO `mny_address` VALUES ('703', '古　县', '1', '0', '59', '3');
INSERT INTO `mny_address` VALUES ('704', '安泽县', '1', '0', '59', '3');
INSERT INTO `mny_address` VALUES ('705', '浮山县', '1', '0', '59', '3');
INSERT INTO `mny_address` VALUES ('706', '吉　县', '1', '0', '59', '3');
INSERT INTO `mny_address` VALUES ('707', '乡宁县', '1', '0', '59', '3');
INSERT INTO `mny_address` VALUES ('708', '大宁县', '1', '0', '59', '3');
INSERT INTO `mny_address` VALUES ('709', '隰　县', '1', '0', '59', '3');
INSERT INTO `mny_address` VALUES ('710', '永和县', '1', '0', '59', '3');
INSERT INTO `mny_address` VALUES ('711', '蒲　县', '1', '0', '59', '3');
INSERT INTO `mny_address` VALUES ('712', '汾西县', '1', '0', '59', '3');
INSERT INTO `mny_address` VALUES ('713', '侯马市', '1', '0', '59', '3');
INSERT INTO `mny_address` VALUES ('714', '霍州市', '1', '0', '59', '3');
INSERT INTO `mny_address` VALUES ('715', '市辖区', '1', '0', '60', '3');
INSERT INTO `mny_address` VALUES ('716', '离石区', '1', '0', '60', '3');
INSERT INTO `mny_address` VALUES ('717', '文水县', '1', '0', '60', '3');
INSERT INTO `mny_address` VALUES ('718', '交城县', '1', '0', '60', '3');
INSERT INTO `mny_address` VALUES ('719', '兴　县', '1', '0', '60', '3');
INSERT INTO `mny_address` VALUES ('720', '临　县', '1', '0', '60', '3');
INSERT INTO `mny_address` VALUES ('721', '柳林县', '1', '0', '60', '3');
INSERT INTO `mny_address` VALUES ('722', '石楼县', '1', '0', '60', '3');
INSERT INTO `mny_address` VALUES ('723', '岚　县', '1', '0', '60', '3');
INSERT INTO `mny_address` VALUES ('724', '方山县', '1', '0', '60', '3');
INSERT INTO `mny_address` VALUES ('725', '中阳县', '1', '0', '60', '3');
INSERT INTO `mny_address` VALUES ('726', '交口县', '1', '0', '60', '3');
INSERT INTO `mny_address` VALUES ('727', '孝义市', '1', '0', '60', '3');
INSERT INTO `mny_address` VALUES ('728', '汾阳市', '1', '0', '60', '3');
INSERT INTO `mny_address` VALUES ('729', '市辖区', '1', '0', '61', '3');
INSERT INTO `mny_address` VALUES ('730', '新城区', '1', '0', '61', '3');
INSERT INTO `mny_address` VALUES ('731', '回民区', '1', '0', '61', '3');
INSERT INTO `mny_address` VALUES ('732', '玉泉区', '1', '0', '61', '3');
INSERT INTO `mny_address` VALUES ('733', '赛罕区', '1', '0', '61', '3');
INSERT INTO `mny_address` VALUES ('734', '土默特左旗', '1', '0', '61', '3');
INSERT INTO `mny_address` VALUES ('735', '托克托县', '1', '0', '61', '3');
INSERT INTO `mny_address` VALUES ('736', '和林格尔县', '1', '0', '61', '3');
INSERT INTO `mny_address` VALUES ('737', '清水河县', '1', '0', '61', '3');
INSERT INTO `mny_address` VALUES ('738', '武川县', '1', '0', '61', '3');
INSERT INTO `mny_address` VALUES ('739', '市辖区', '1', '0', '62', '3');
INSERT INTO `mny_address` VALUES ('740', '东河区', '1', '0', '62', '3');
INSERT INTO `mny_address` VALUES ('741', '昆都仑区', '1', '0', '62', '3');
INSERT INTO `mny_address` VALUES ('742', '青山区', '1', '0', '62', '3');
INSERT INTO `mny_address` VALUES ('743', '石拐区', '1', '0', '62', '3');
INSERT INTO `mny_address` VALUES ('744', '白云矿区', '1', '0', '62', '3');
INSERT INTO `mny_address` VALUES ('745', '九原区', '1', '0', '62', '3');
INSERT INTO `mny_address` VALUES ('746', '土默特右旗', '1', '0', '62', '3');
INSERT INTO `mny_address` VALUES ('747', '固阳县', '1', '0', '62', '3');
INSERT INTO `mny_address` VALUES ('748', '达尔罕茂明安联合旗', '1', '0', '62', '3');
INSERT INTO `mny_address` VALUES ('749', '市辖区', '1', '0', '63', '3');
INSERT INTO `mny_address` VALUES ('750', '海勃湾区', '1', '0', '63', '3');
INSERT INTO `mny_address` VALUES ('751', '海南区', '1', '0', '63', '3');
INSERT INTO `mny_address` VALUES ('752', '乌达区', '1', '0', '63', '3');
INSERT INTO `mny_address` VALUES ('753', '市辖区', '1', '0', '64', '3');
INSERT INTO `mny_address` VALUES ('754', '红山区', '1', '0', '64', '3');
INSERT INTO `mny_address` VALUES ('755', '元宝山区', '1', '0', '64', '3');
INSERT INTO `mny_address` VALUES ('756', '松山区', '1', '0', '64', '3');
INSERT INTO `mny_address` VALUES ('757', '阿鲁科尔沁旗', '1', '0', '64', '3');
INSERT INTO `mny_address` VALUES ('758', '巴林左旗', '1', '0', '64', '3');
INSERT INTO `mny_address` VALUES ('759', '巴林右旗', '1', '0', '64', '3');
INSERT INTO `mny_address` VALUES ('760', '林西县', '1', '0', '64', '3');
INSERT INTO `mny_address` VALUES ('761', '克什克腾旗', '1', '0', '64', '3');
INSERT INTO `mny_address` VALUES ('762', '翁牛特旗', '1', '0', '64', '3');
INSERT INTO `mny_address` VALUES ('763', '喀喇沁旗', '1', '0', '64', '3');
INSERT INTO `mny_address` VALUES ('764', '宁城县', '1', '0', '64', '3');
INSERT INTO `mny_address` VALUES ('765', '敖汉旗', '1', '0', '64', '3');
INSERT INTO `mny_address` VALUES ('766', '市辖区', '1', '0', '65', '3');
INSERT INTO `mny_address` VALUES ('767', '科尔沁区', '1', '0', '65', '3');
INSERT INTO `mny_address` VALUES ('768', '科尔沁左翼中旗', '1', '0', '65', '3');
INSERT INTO `mny_address` VALUES ('769', '科尔沁左翼后旗', '1', '0', '65', '3');
INSERT INTO `mny_address` VALUES ('770', '开鲁县', '1', '0', '65', '3');
INSERT INTO `mny_address` VALUES ('771', '库伦旗', '1', '0', '65', '3');
INSERT INTO `mny_address` VALUES ('772', '奈曼旗', '1', '0', '65', '3');
INSERT INTO `mny_address` VALUES ('773', '扎鲁特旗', '1', '0', '65', '3');
INSERT INTO `mny_address` VALUES ('774', '霍林郭勒市', '1', '0', '65', '3');
INSERT INTO `mny_address` VALUES ('775', '东胜区', '1', '0', '66', '3');
INSERT INTO `mny_address` VALUES ('776', '达拉特旗', '1', '0', '66', '3');
INSERT INTO `mny_address` VALUES ('777', '准格尔旗', '1', '0', '66', '3');
INSERT INTO `mny_address` VALUES ('778', '鄂托克前旗', '1', '0', '66', '3');
INSERT INTO `mny_address` VALUES ('779', '鄂托克旗', '1', '0', '66', '3');
INSERT INTO `mny_address` VALUES ('780', '杭锦旗', '1', '0', '66', '3');
INSERT INTO `mny_address` VALUES ('781', '乌审旗', '1', '0', '66', '3');
INSERT INTO `mny_address` VALUES ('782', '伊金霍洛旗', '1', '0', '66', '3');
INSERT INTO `mny_address` VALUES ('783', '市辖区', '1', '0', '67', '3');
INSERT INTO `mny_address` VALUES ('784', '海拉尔区', '1', '0', '67', '3');
INSERT INTO `mny_address` VALUES ('785', '阿荣旗', '1', '0', '67', '3');
INSERT INTO `mny_address` VALUES ('786', '莫力达瓦达斡尔族自治旗', '1', '0', '67', '3');
INSERT INTO `mny_address` VALUES ('787', '鄂伦春自治旗', '1', '0', '67', '3');
INSERT INTO `mny_address` VALUES ('788', '鄂温克族自治旗', '1', '0', '67', '3');
INSERT INTO `mny_address` VALUES ('789', '陈巴尔虎旗', '1', '0', '67', '3');
INSERT INTO `mny_address` VALUES ('790', '新巴尔虎左旗', '1', '0', '67', '3');
INSERT INTO `mny_address` VALUES ('791', '新巴尔虎右旗', '1', '0', '67', '3');
INSERT INTO `mny_address` VALUES ('792', '满洲里市', '1', '0', '67', '3');
INSERT INTO `mny_address` VALUES ('793', '牙克石市', '1', '0', '67', '3');
INSERT INTO `mny_address` VALUES ('794', '扎兰屯市', '1', '0', '67', '3');
INSERT INTO `mny_address` VALUES ('795', '额尔古纳市', '1', '0', '67', '3');
INSERT INTO `mny_address` VALUES ('796', '根河市', '1', '0', '67', '3');
INSERT INTO `mny_address` VALUES ('797', '市辖区', '1', '0', '68', '3');
INSERT INTO `mny_address` VALUES ('798', '临河区', '1', '0', '68', '3');
INSERT INTO `mny_address` VALUES ('799', '五原县', '1', '0', '68', '3');
INSERT INTO `mny_address` VALUES ('800', '磴口县', '1', '0', '68', '3');
INSERT INTO `mny_address` VALUES ('801', '乌拉特前旗', '1', '0', '68', '3');
INSERT INTO `mny_address` VALUES ('802', '乌拉特中旗', '1', '0', '68', '3');
INSERT INTO `mny_address` VALUES ('803', '乌拉特后旗', '1', '0', '68', '3');
INSERT INTO `mny_address` VALUES ('804', '杭锦后旗', '1', '0', '68', '3');
INSERT INTO `mny_address` VALUES ('805', '市辖区', '1', '0', '69', '3');
INSERT INTO `mny_address` VALUES ('806', '集宁区', '1', '0', '69', '3');
INSERT INTO `mny_address` VALUES ('807', '卓资县', '1', '0', '69', '3');
INSERT INTO `mny_address` VALUES ('808', '化德县', '1', '0', '69', '3');
INSERT INTO `mny_address` VALUES ('809', '商都县', '1', '0', '69', '3');
INSERT INTO `mny_address` VALUES ('810', '兴和县', '1', '0', '69', '3');
INSERT INTO `mny_address` VALUES ('811', '凉城县', '1', '0', '69', '3');
INSERT INTO `mny_address` VALUES ('812', '察哈尔右翼前旗', '1', '0', '69', '3');
INSERT INTO `mny_address` VALUES ('813', '察哈尔右翼中旗', '1', '0', '69', '3');
INSERT INTO `mny_address` VALUES ('814', '察哈尔右翼后旗', '1', '0', '69', '3');
INSERT INTO `mny_address` VALUES ('815', '四子王旗', '1', '0', '69', '3');
INSERT INTO `mny_address` VALUES ('816', '丰镇市', '1', '0', '69', '3');
INSERT INTO `mny_address` VALUES ('817', '乌兰浩特市', '1', '0', '70', '3');
INSERT INTO `mny_address` VALUES ('818', '阿尔山市', '1', '0', '70', '3');
INSERT INTO `mny_address` VALUES ('819', '科尔沁右翼前旗', '1', '0', '70', '3');
INSERT INTO `mny_address` VALUES ('820', '科尔沁右翼中旗', '1', '0', '70', '3');
INSERT INTO `mny_address` VALUES ('821', '扎赉特旗', '1', '0', '70', '3');
INSERT INTO `mny_address` VALUES ('822', '突泉县', '1', '0', '70', '3');
INSERT INTO `mny_address` VALUES ('823', '二连浩特市', '1', '0', '71', '3');
INSERT INTO `mny_address` VALUES ('824', '锡林浩特市', '1', '0', '71', '3');
INSERT INTO `mny_address` VALUES ('825', '阿巴嘎旗', '1', '0', '71', '3');
INSERT INTO `mny_address` VALUES ('826', '苏尼特左旗', '1', '0', '71', '3');
INSERT INTO `mny_address` VALUES ('827', '苏尼特右旗', '1', '0', '71', '3');
INSERT INTO `mny_address` VALUES ('828', '东乌珠穆沁旗', '1', '0', '71', '3');
INSERT INTO `mny_address` VALUES ('829', '西乌珠穆沁旗', '1', '0', '71', '3');
INSERT INTO `mny_address` VALUES ('830', '太仆寺旗', '1', '0', '71', '3');
INSERT INTO `mny_address` VALUES ('831', '镶黄旗', '1', '0', '71', '3');
INSERT INTO `mny_address` VALUES ('832', '正镶白旗', '1', '0', '71', '3');
INSERT INTO `mny_address` VALUES ('833', '正蓝旗', '1', '0', '71', '3');
INSERT INTO `mny_address` VALUES ('834', '多伦县', '1', '0', '71', '3');
INSERT INTO `mny_address` VALUES ('835', '阿拉善左旗', '1', '0', '72', '3');
INSERT INTO `mny_address` VALUES ('836', '阿拉善右旗', '1', '0', '72', '3');
INSERT INTO `mny_address` VALUES ('837', '额济纳旗', '1', '0', '72', '3');
INSERT INTO `mny_address` VALUES ('838', '市辖区', '1', '0', '73', '3');
INSERT INTO `mny_address` VALUES ('839', '和平区', '1', '0', '73', '3');
INSERT INTO `mny_address` VALUES ('840', '沈河区', '1', '0', '73', '3');
INSERT INTO `mny_address` VALUES ('841', '大东区', '1', '0', '73', '3');
INSERT INTO `mny_address` VALUES ('842', '皇姑区', '1', '0', '73', '3');
INSERT INTO `mny_address` VALUES ('843', '铁西区', '1', '0', '73', '3');
INSERT INTO `mny_address` VALUES ('844', '苏家屯区', '1', '0', '73', '3');
INSERT INTO `mny_address` VALUES ('845', '东陵区', '1', '0', '73', '3');
INSERT INTO `mny_address` VALUES ('846', '新城子区', '1', '0', '73', '3');
INSERT INTO `mny_address` VALUES ('847', '于洪区', '1', '0', '73', '3');
INSERT INTO `mny_address` VALUES ('848', '辽中县', '1', '0', '73', '3');
INSERT INTO `mny_address` VALUES ('849', '康平县', '1', '0', '73', '3');
INSERT INTO `mny_address` VALUES ('850', '法库县', '1', '0', '73', '3');
INSERT INTO `mny_address` VALUES ('851', '新民市', '1', '0', '73', '3');
INSERT INTO `mny_address` VALUES ('852', '市辖区', '1', '0', '74', '3');
INSERT INTO `mny_address` VALUES ('853', '中山区', '1', '0', '74', '3');
INSERT INTO `mny_address` VALUES ('854', '西岗区', '1', '0', '74', '3');
INSERT INTO `mny_address` VALUES ('855', '沙河口区', '1', '0', '74', '3');
INSERT INTO `mny_address` VALUES ('856', '甘井子区', '1', '0', '74', '3');
INSERT INTO `mny_address` VALUES ('857', '旅顺口区', '1', '0', '74', '3');
INSERT INTO `mny_address` VALUES ('858', '金州区', '1', '0', '74', '3');
INSERT INTO `mny_address` VALUES ('859', '长海县', '1', '0', '74', '3');
INSERT INTO `mny_address` VALUES ('860', '瓦房店市', '1', '0', '74', '3');
INSERT INTO `mny_address` VALUES ('861', '普兰店市', '1', '0', '74', '3');
INSERT INTO `mny_address` VALUES ('862', '庄河市', '1', '0', '74', '3');
INSERT INTO `mny_address` VALUES ('863', '市辖区', '1', '0', '75', '3');
INSERT INTO `mny_address` VALUES ('864', '铁东区', '1', '0', '75', '3');
INSERT INTO `mny_address` VALUES ('865', '铁西区', '1', '0', '75', '3');
INSERT INTO `mny_address` VALUES ('866', '立山区', '1', '0', '75', '3');
INSERT INTO `mny_address` VALUES ('867', '千山区', '1', '0', '75', '3');
INSERT INTO `mny_address` VALUES ('868', '台安县', '1', '0', '75', '3');
INSERT INTO `mny_address` VALUES ('869', '岫岩满族自治县', '1', '0', '75', '3');
INSERT INTO `mny_address` VALUES ('870', '海城市', '1', '0', '75', '3');
INSERT INTO `mny_address` VALUES ('871', '市辖区', '1', '0', '76', '3');
INSERT INTO `mny_address` VALUES ('872', '新抚区', '1', '0', '76', '3');
INSERT INTO `mny_address` VALUES ('873', '东洲区', '1', '0', '76', '3');
INSERT INTO `mny_address` VALUES ('874', '望花区', '1', '0', '76', '3');
INSERT INTO `mny_address` VALUES ('875', '顺城区', '1', '0', '76', '3');
INSERT INTO `mny_address` VALUES ('876', '抚顺县', '1', '0', '76', '3');
INSERT INTO `mny_address` VALUES ('877', '新宾满族自治县', '1', '0', '76', '3');
INSERT INTO `mny_address` VALUES ('878', '清原满族自治县', '1', '0', '76', '3');
INSERT INTO `mny_address` VALUES ('879', '市辖区', '1', '0', '77', '3');
INSERT INTO `mny_address` VALUES ('880', '平山区', '1', '0', '77', '3');
INSERT INTO `mny_address` VALUES ('881', '溪湖区', '1', '0', '77', '3');
INSERT INTO `mny_address` VALUES ('882', '明山区', '1', '0', '77', '3');
INSERT INTO `mny_address` VALUES ('883', '南芬区', '1', '0', '77', '3');
INSERT INTO `mny_address` VALUES ('884', '本溪满族自治县', '1', '0', '77', '3');
INSERT INTO `mny_address` VALUES ('885', '桓仁满族自治县', '1', '0', '77', '3');
INSERT INTO `mny_address` VALUES ('886', '市辖区', '1', '0', '78', '3');
INSERT INTO `mny_address` VALUES ('887', '元宝区', '1', '0', '78', '3');
INSERT INTO `mny_address` VALUES ('888', '振兴区', '1', '0', '78', '3');
INSERT INTO `mny_address` VALUES ('889', '振安区', '1', '0', '78', '3');
INSERT INTO `mny_address` VALUES ('890', '宽甸满族自治县', '1', '0', '78', '3');
INSERT INTO `mny_address` VALUES ('891', '东港市', '1', '0', '78', '3');
INSERT INTO `mny_address` VALUES ('892', '凤城市', '1', '0', '78', '3');
INSERT INTO `mny_address` VALUES ('893', '市辖区', '1', '0', '79', '3');
INSERT INTO `mny_address` VALUES ('894', '古塔区', '1', '0', '79', '3');
INSERT INTO `mny_address` VALUES ('895', '凌河区', '1', '0', '79', '3');
INSERT INTO `mny_address` VALUES ('896', '太和区', '1', '0', '79', '3');
INSERT INTO `mny_address` VALUES ('897', '黑山县', '1', '0', '79', '3');
INSERT INTO `mny_address` VALUES ('898', '义　县', '1', '0', '79', '3');
INSERT INTO `mny_address` VALUES ('899', '凌海市', '1', '0', '79', '3');
INSERT INTO `mny_address` VALUES ('900', '北宁市', '1', '0', '79', '3');
INSERT INTO `mny_address` VALUES ('901', '市辖区', '1', '0', '80', '3');
INSERT INTO `mny_address` VALUES ('902', '站前区', '1', '0', '80', '3');
INSERT INTO `mny_address` VALUES ('903', '西市区', '1', '0', '80', '3');
INSERT INTO `mny_address` VALUES ('904', '鲅鱼圈区', '1', '0', '80', '3');
INSERT INTO `mny_address` VALUES ('905', '老边区', '1', '0', '80', '3');
INSERT INTO `mny_address` VALUES ('906', '盖州市', '1', '0', '80', '3');
INSERT INTO `mny_address` VALUES ('907', '大石桥市', '1', '0', '80', '3');
INSERT INTO `mny_address` VALUES ('908', '市辖区', '1', '0', '81', '3');
INSERT INTO `mny_address` VALUES ('909', '海州区', '1', '0', '81', '3');
INSERT INTO `mny_address` VALUES ('910', '新邱区', '1', '0', '81', '3');
INSERT INTO `mny_address` VALUES ('911', '太平区', '1', '0', '81', '3');
INSERT INTO `mny_address` VALUES ('912', '清河门区', '1', '0', '81', '3');
INSERT INTO `mny_address` VALUES ('913', '细河区', '1', '0', '81', '3');
INSERT INTO `mny_address` VALUES ('914', '阜新蒙古族自治县', '1', '0', '81', '3');
INSERT INTO `mny_address` VALUES ('915', '彰武县', '1', '0', '81', '3');
INSERT INTO `mny_address` VALUES ('916', '市辖区', '1', '0', '82', '3');
INSERT INTO `mny_address` VALUES ('917', '白塔区', '1', '0', '82', '3');
INSERT INTO `mny_address` VALUES ('918', '文圣区', '1', '0', '82', '3');
INSERT INTO `mny_address` VALUES ('919', '宏伟区', '1', '0', '82', '3');
INSERT INTO `mny_address` VALUES ('920', '弓长岭区', '1', '0', '82', '3');
INSERT INTO `mny_address` VALUES ('921', '太子河区', '1', '0', '82', '3');
INSERT INTO `mny_address` VALUES ('922', '辽阳县', '1', '0', '82', '3');
INSERT INTO `mny_address` VALUES ('923', '灯塔市', '1', '0', '82', '3');
INSERT INTO `mny_address` VALUES ('924', '市辖区', '1', '0', '83', '3');
INSERT INTO `mny_address` VALUES ('925', '双台子区', '1', '0', '83', '3');
INSERT INTO `mny_address` VALUES ('926', '兴隆台区', '1', '0', '83', '3');
INSERT INTO `mny_address` VALUES ('927', '大洼县', '1', '0', '83', '3');
INSERT INTO `mny_address` VALUES ('928', '盘山县', '1', '0', '83', '3');
INSERT INTO `mny_address` VALUES ('929', '市辖区', '1', '0', '84', '3');
INSERT INTO `mny_address` VALUES ('930', '银州区', '1', '0', '84', '3');
INSERT INTO `mny_address` VALUES ('931', '清河区', '1', '0', '84', '3');
INSERT INTO `mny_address` VALUES ('932', '铁岭县', '1', '0', '84', '3');
INSERT INTO `mny_address` VALUES ('933', '西丰县', '1', '0', '84', '3');
INSERT INTO `mny_address` VALUES ('934', '昌图县', '1', '0', '84', '3');
INSERT INTO `mny_address` VALUES ('935', '调兵山市', '1', '0', '84', '3');
INSERT INTO `mny_address` VALUES ('936', '开原市', '1', '0', '84', '3');
INSERT INTO `mny_address` VALUES ('937', '市辖区', '1', '0', '85', '3');
INSERT INTO `mny_address` VALUES ('938', '双塔区', '1', '0', '85', '3');
INSERT INTO `mny_address` VALUES ('939', '龙城区', '1', '0', '85', '3');
INSERT INTO `mny_address` VALUES ('940', '朝阳县', '1', '0', '85', '3');
INSERT INTO `mny_address` VALUES ('941', '建平县', '1', '0', '85', '3');
INSERT INTO `mny_address` VALUES ('942', '喀喇沁左翼蒙古族自治县', '1', '0', '85', '3');
INSERT INTO `mny_address` VALUES ('943', '北票市', '1', '0', '85', '3');
INSERT INTO `mny_address` VALUES ('944', '凌源市', '1', '0', '85', '3');
INSERT INTO `mny_address` VALUES ('945', '市辖区', '1', '0', '86', '3');
INSERT INTO `mny_address` VALUES ('946', '连山区', '1', '0', '86', '3');
INSERT INTO `mny_address` VALUES ('947', '龙港区', '1', '0', '86', '3');
INSERT INTO `mny_address` VALUES ('948', '南票区', '1', '0', '86', '3');
INSERT INTO `mny_address` VALUES ('949', '绥中县', '1', '0', '86', '3');
INSERT INTO `mny_address` VALUES ('950', '建昌县', '1', '0', '86', '3');
INSERT INTO `mny_address` VALUES ('951', '兴城市', '1', '0', '86', '3');
INSERT INTO `mny_address` VALUES ('952', '市辖区', '1', '0', '87', '3');
INSERT INTO `mny_address` VALUES ('953', '南关区', '1', '0', '87', '3');
INSERT INTO `mny_address` VALUES ('954', '宽城区', '1', '0', '87', '3');
INSERT INTO `mny_address` VALUES ('955', '朝阳区', '1', '0', '87', '3');
INSERT INTO `mny_address` VALUES ('956', '二道区', '1', '0', '87', '3');
INSERT INTO `mny_address` VALUES ('957', '绿园区', '1', '0', '87', '3');
INSERT INTO `mny_address` VALUES ('958', '双阳区', '1', '0', '87', '3');
INSERT INTO `mny_address` VALUES ('959', '农安县', '1', '0', '87', '3');
INSERT INTO `mny_address` VALUES ('960', '九台市', '1', '0', '87', '3');
INSERT INTO `mny_address` VALUES ('961', '榆树市', '1', '0', '87', '3');
INSERT INTO `mny_address` VALUES ('962', '德惠市', '1', '0', '87', '3');
INSERT INTO `mny_address` VALUES ('963', '市辖区', '1', '0', '88', '3');
INSERT INTO `mny_address` VALUES ('964', '昌邑区', '1', '0', '88', '3');
INSERT INTO `mny_address` VALUES ('965', '龙潭区', '1', '0', '88', '3');
INSERT INTO `mny_address` VALUES ('966', '船营区', '1', '0', '88', '3');
INSERT INTO `mny_address` VALUES ('967', '丰满区', '1', '0', '88', '3');
INSERT INTO `mny_address` VALUES ('968', '永吉县', '1', '0', '88', '3');
INSERT INTO `mny_address` VALUES ('969', '蛟河市', '1', '0', '88', '3');
INSERT INTO `mny_address` VALUES ('970', '桦甸市', '1', '0', '88', '3');
INSERT INTO `mny_address` VALUES ('971', '舒兰市', '1', '0', '88', '3');
INSERT INTO `mny_address` VALUES ('972', '磐石市', '1', '0', '88', '3');
INSERT INTO `mny_address` VALUES ('973', '市辖区', '1', '0', '89', '3');
INSERT INTO `mny_address` VALUES ('974', '铁西区', '1', '0', '89', '3');
INSERT INTO `mny_address` VALUES ('975', '铁东区', '1', '0', '89', '3');
INSERT INTO `mny_address` VALUES ('976', '梨树县', '1', '0', '89', '3');
INSERT INTO `mny_address` VALUES ('977', '伊通满族自治县', '1', '0', '89', '3');
INSERT INTO `mny_address` VALUES ('978', '公主岭市', '1', '0', '89', '3');
INSERT INTO `mny_address` VALUES ('979', '双辽市', '1', '0', '89', '3');
INSERT INTO `mny_address` VALUES ('980', '市辖区', '1', '0', '90', '3');
INSERT INTO `mny_address` VALUES ('981', '龙山区', '1', '0', '90', '3');
INSERT INTO `mny_address` VALUES ('982', '西安区', '1', '0', '90', '3');
INSERT INTO `mny_address` VALUES ('983', '东丰县', '1', '0', '90', '3');
INSERT INTO `mny_address` VALUES ('984', '东辽县', '1', '0', '90', '3');
INSERT INTO `mny_address` VALUES ('985', '市辖区', '1', '0', '91', '3');
INSERT INTO `mny_address` VALUES ('986', '东昌区', '1', '0', '91', '3');
INSERT INTO `mny_address` VALUES ('987', '二道江区', '1', '0', '91', '3');
INSERT INTO `mny_address` VALUES ('988', '通化县', '1', '0', '91', '3');
INSERT INTO `mny_address` VALUES ('989', '辉南县', '1', '0', '91', '3');
INSERT INTO `mny_address` VALUES ('990', '柳河县', '1', '0', '91', '3');
INSERT INTO `mny_address` VALUES ('991', '梅河口市', '1', '0', '91', '3');
INSERT INTO `mny_address` VALUES ('992', '集安市', '1', '0', '91', '3');
INSERT INTO `mny_address` VALUES ('993', '市辖区', '1', '0', '92', '3');
INSERT INTO `mny_address` VALUES ('994', '八道江区', '1', '0', '92', '3');
INSERT INTO `mny_address` VALUES ('995', '抚松县', '1', '0', '92', '3');
INSERT INTO `mny_address` VALUES ('996', '靖宇县', '1', '0', '92', '3');
INSERT INTO `mny_address` VALUES ('997', '长白朝鲜族自治县', '1', '0', '92', '3');
INSERT INTO `mny_address` VALUES ('998', '江源县', '1', '0', '92', '3');
INSERT INTO `mny_address` VALUES ('999', '临江市', '1', '0', '92', '3');
INSERT INTO `mny_address` VALUES ('1000', '市辖区', '1', '0', '93', '3');
INSERT INTO `mny_address` VALUES ('1001', '宁江区', '1', '0', '93', '3');
INSERT INTO `mny_address` VALUES ('1002', '前郭尔罗斯蒙古族自治县', '1', '0', '93', '3');
INSERT INTO `mny_address` VALUES ('1003', '长岭县', '1', '0', '93', '3');
INSERT INTO `mny_address` VALUES ('1004', '乾安县', '1', '0', '93', '3');
INSERT INTO `mny_address` VALUES ('1005', '扶余县', '1', '0', '93', '3');
INSERT INTO `mny_address` VALUES ('1006', '市辖区', '1', '0', '94', '3');
INSERT INTO `mny_address` VALUES ('1007', '洮北区', '1', '0', '94', '3');
INSERT INTO `mny_address` VALUES ('1008', '镇赉县', '1', '0', '94', '3');
INSERT INTO `mny_address` VALUES ('1009', '通榆县', '1', '0', '94', '3');
INSERT INTO `mny_address` VALUES ('1010', '洮南市', '1', '0', '94', '3');
INSERT INTO `mny_address` VALUES ('1011', '大安市', '1', '0', '94', '3');
INSERT INTO `mny_address` VALUES ('1012', '延吉市', '1', '0', '95', '3');
INSERT INTO `mny_address` VALUES ('1013', '图们市', '1', '0', '95', '3');
INSERT INTO `mny_address` VALUES ('1014', '敦化市', '1', '0', '95', '3');
INSERT INTO `mny_address` VALUES ('1015', '珲春市', '1', '0', '95', '3');
INSERT INTO `mny_address` VALUES ('1016', '龙井市', '1', '0', '95', '3');
INSERT INTO `mny_address` VALUES ('1017', '和龙市', '1', '0', '95', '3');
INSERT INTO `mny_address` VALUES ('1018', '汪清县', '1', '0', '95', '3');
INSERT INTO `mny_address` VALUES ('1019', '安图县', '1', '0', '95', '3');
INSERT INTO `mny_address` VALUES ('1020', '市辖区', '1', '0', '96', '3');
INSERT INTO `mny_address` VALUES ('1021', '道里区', '1', '0', '96', '3');
INSERT INTO `mny_address` VALUES ('1022', '南岗区', '1', '0', '96', '3');
INSERT INTO `mny_address` VALUES ('1023', '道外区', '1', '0', '96', '3');
INSERT INTO `mny_address` VALUES ('1024', '香坊区', '1', '0', '96', '3');
INSERT INTO `mny_address` VALUES ('1025', '动力区', '1', '0', '96', '3');
INSERT INTO `mny_address` VALUES ('1026', '平房区', '1', '0', '96', '3');
INSERT INTO `mny_address` VALUES ('1027', '松北区', '1', '0', '96', '3');
INSERT INTO `mny_address` VALUES ('1028', '呼兰区', '1', '0', '96', '3');
INSERT INTO `mny_address` VALUES ('1029', '依兰县', '1', '0', '96', '3');
INSERT INTO `mny_address` VALUES ('1030', '方正县', '1', '0', '96', '3');
INSERT INTO `mny_address` VALUES ('1031', '宾　县', '1', '0', '96', '3');
INSERT INTO `mny_address` VALUES ('1032', '巴彦县', '1', '0', '96', '3');
INSERT INTO `mny_address` VALUES ('1033', '木兰县', '1', '0', '96', '3');
INSERT INTO `mny_address` VALUES ('1034', '通河县', '1', '0', '96', '3');
INSERT INTO `mny_address` VALUES ('1035', '延寿县', '1', '0', '96', '3');
INSERT INTO `mny_address` VALUES ('1036', '阿城市', '1', '0', '96', '3');
INSERT INTO `mny_address` VALUES ('1037', '双城市', '1', '0', '96', '3');
INSERT INTO `mny_address` VALUES ('1038', '尚志市', '1', '0', '96', '3');
INSERT INTO `mny_address` VALUES ('1039', '五常市', '1', '0', '96', '3');
INSERT INTO `mny_address` VALUES ('1040', '市辖区', '1', '0', '97', '3');
INSERT INTO `mny_address` VALUES ('1041', '龙沙区', '1', '0', '97', '3');
INSERT INTO `mny_address` VALUES ('1042', '建华区', '1', '0', '97', '3');
INSERT INTO `mny_address` VALUES ('1043', '铁锋区', '1', '0', '97', '3');
INSERT INTO `mny_address` VALUES ('1044', '昂昂溪区', '1', '0', '97', '3');
INSERT INTO `mny_address` VALUES ('1045', '富拉尔基区', '1', '0', '97', '3');
INSERT INTO `mny_address` VALUES ('1046', '碾子山区', '1', '0', '97', '3');
INSERT INTO `mny_address` VALUES ('1047', '梅里斯达斡尔族区', '1', '0', '97', '3');
INSERT INTO `mny_address` VALUES ('1048', '龙江县', '1', '0', '97', '3');
INSERT INTO `mny_address` VALUES ('1049', '依安县', '1', '0', '97', '3');
INSERT INTO `mny_address` VALUES ('1050', '泰来县', '1', '0', '97', '3');
INSERT INTO `mny_address` VALUES ('1051', '甘南县', '1', '0', '97', '3');
INSERT INTO `mny_address` VALUES ('1052', '富裕县', '1', '0', '97', '3');
INSERT INTO `mny_address` VALUES ('1053', '克山县', '1', '0', '97', '3');
INSERT INTO `mny_address` VALUES ('1054', '克东县', '1', '0', '97', '3');
INSERT INTO `mny_address` VALUES ('1055', '拜泉县', '1', '0', '97', '3');
INSERT INTO `mny_address` VALUES ('1056', '讷河市', '1', '0', '97', '3');
INSERT INTO `mny_address` VALUES ('1057', '市辖区', '1', '0', '98', '3');
INSERT INTO `mny_address` VALUES ('1058', '鸡冠区', '1', '0', '98', '3');
INSERT INTO `mny_address` VALUES ('1059', '恒山区', '1', '0', '98', '3');
INSERT INTO `mny_address` VALUES ('1060', '滴道区', '1', '0', '98', '3');
INSERT INTO `mny_address` VALUES ('1061', '梨树区', '1', '0', '98', '3');
INSERT INTO `mny_address` VALUES ('1062', '城子河区', '1', '0', '98', '3');
INSERT INTO `mny_address` VALUES ('1063', '麻山区', '1', '0', '98', '3');
INSERT INTO `mny_address` VALUES ('1064', '鸡东县', '1', '0', '98', '3');
INSERT INTO `mny_address` VALUES ('1065', '虎林市', '1', '0', '98', '3');
INSERT INTO `mny_address` VALUES ('1066', '密山市', '1', '0', '98', '3');
INSERT INTO `mny_address` VALUES ('1067', '市辖区', '1', '0', '99', '3');
INSERT INTO `mny_address` VALUES ('1068', '向阳区', '1', '0', '99', '3');
INSERT INTO `mny_address` VALUES ('1069', '工农区', '1', '0', '99', '3');
INSERT INTO `mny_address` VALUES ('1070', '南山区', '1', '0', '99', '3');
INSERT INTO `mny_address` VALUES ('1071', '兴安区', '1', '0', '99', '3');
INSERT INTO `mny_address` VALUES ('1072', '东山区', '1', '0', '99', '3');
INSERT INTO `mny_address` VALUES ('1073', '兴山区', '1', '0', '99', '3');
INSERT INTO `mny_address` VALUES ('1074', '萝北县', '1', '0', '99', '3');
INSERT INTO `mny_address` VALUES ('1075', '绥滨县', '1', '0', '99', '3');
INSERT INTO `mny_address` VALUES ('1076', '市辖区', '1', '0', '100', '3');
INSERT INTO `mny_address` VALUES ('1077', '尖山区', '1', '0', '100', '3');
INSERT INTO `mny_address` VALUES ('1078', '岭东区', '1', '0', '100', '3');
INSERT INTO `mny_address` VALUES ('1079', '四方台区', '1', '0', '100', '3');
INSERT INTO `mny_address` VALUES ('1080', '宝山区', '1', '0', '100', '3');
INSERT INTO `mny_address` VALUES ('1081', '集贤县', '1', '0', '100', '3');
INSERT INTO `mny_address` VALUES ('1082', '友谊县', '1', '0', '100', '3');
INSERT INTO `mny_address` VALUES ('1083', '宝清县', '1', '0', '100', '3');
INSERT INTO `mny_address` VALUES ('1084', '饶河县', '1', '0', '100', '3');
INSERT INTO `mny_address` VALUES ('1085', '市辖区', '1', '0', '101', '3');
INSERT INTO `mny_address` VALUES ('1086', '萨尔图区', '1', '0', '101', '3');
INSERT INTO `mny_address` VALUES ('1087', '龙凤区', '1', '0', '101', '3');
INSERT INTO `mny_address` VALUES ('1088', '让胡路区', '1', '0', '101', '3');
INSERT INTO `mny_address` VALUES ('1089', '红岗区', '1', '0', '101', '3');
INSERT INTO `mny_address` VALUES ('1090', '大同区', '1', '0', '101', '3');
INSERT INTO `mny_address` VALUES ('1091', '肇州县', '1', '0', '101', '3');
INSERT INTO `mny_address` VALUES ('1092', '肇源县', '1', '0', '101', '3');
INSERT INTO `mny_address` VALUES ('1093', '林甸县', '1', '0', '101', '3');
INSERT INTO `mny_address` VALUES ('1094', '杜尔伯特蒙古族自治县', '1', '0', '101', '3');
INSERT INTO `mny_address` VALUES ('1095', '市辖区', '1', '0', '102', '3');
INSERT INTO `mny_address` VALUES ('1096', '伊春区', '1', '0', '102', '3');
INSERT INTO `mny_address` VALUES ('1097', '南岔区', '1', '0', '102', '3');
INSERT INTO `mny_address` VALUES ('1098', '友好区', '1', '0', '102', '3');
INSERT INTO `mny_address` VALUES ('1099', '西林区', '1', '0', '102', '3');
INSERT INTO `mny_address` VALUES ('1100', '翠峦区', '1', '0', '102', '3');
INSERT INTO `mny_address` VALUES ('1101', '新青区', '1', '0', '102', '3');
INSERT INTO `mny_address` VALUES ('1102', '美溪区', '1', '0', '102', '3');
INSERT INTO `mny_address` VALUES ('1103', '金山屯区', '1', '0', '102', '3');
INSERT INTO `mny_address` VALUES ('1104', '五营区', '1', '0', '102', '3');
INSERT INTO `mny_address` VALUES ('1105', '乌马河区', '1', '0', '102', '3');
INSERT INTO `mny_address` VALUES ('1106', '汤旺河区', '1', '0', '102', '3');
INSERT INTO `mny_address` VALUES ('1107', '带岭区', '1', '0', '102', '3');
INSERT INTO `mny_address` VALUES ('1108', '乌伊岭区', '1', '0', '102', '3');
INSERT INTO `mny_address` VALUES ('1109', '红星区', '1', '0', '102', '3');
INSERT INTO `mny_address` VALUES ('1110', '上甘岭区', '1', '0', '102', '3');
INSERT INTO `mny_address` VALUES ('1111', '嘉荫县', '1', '0', '102', '3');
INSERT INTO `mny_address` VALUES ('1112', '铁力市', '1', '0', '102', '3');
INSERT INTO `mny_address` VALUES ('1113', '市辖区', '1', '0', '103', '3');
INSERT INTO `mny_address` VALUES ('1114', '永红区', '1', '0', '103', '3');
INSERT INTO `mny_address` VALUES ('1115', '向阳区', '1', '0', '103', '3');
INSERT INTO `mny_address` VALUES ('1116', '前进区', '1', '0', '103', '3');
INSERT INTO `mny_address` VALUES ('1117', '东风区', '1', '0', '103', '3');
INSERT INTO `mny_address` VALUES ('1118', '郊　区', '1', '0', '103', '3');
INSERT INTO `mny_address` VALUES ('1119', '桦南县', '1', '0', '103', '3');
INSERT INTO `mny_address` VALUES ('1120', '桦川县', '1', '0', '103', '3');
INSERT INTO `mny_address` VALUES ('1121', '汤原县', '1', '0', '103', '3');
INSERT INTO `mny_address` VALUES ('1122', '抚远县', '1', '0', '103', '3');
INSERT INTO `mny_address` VALUES ('1123', '同江市', '1', '0', '103', '3');
INSERT INTO `mny_address` VALUES ('1124', '富锦市', '1', '0', '103', '3');
INSERT INTO `mny_address` VALUES ('1125', '市辖区', '1', '0', '104', '3');
INSERT INTO `mny_address` VALUES ('1126', '新兴区', '1', '0', '104', '3');
INSERT INTO `mny_address` VALUES ('1127', '桃山区', '1', '0', '104', '3');
INSERT INTO `mny_address` VALUES ('1128', '茄子河区', '1', '0', '104', '3');
INSERT INTO `mny_address` VALUES ('1129', '勃利县', '1', '0', '104', '3');
INSERT INTO `mny_address` VALUES ('1130', '市辖区', '1', '0', '105', '3');
INSERT INTO `mny_address` VALUES ('1131', '东安区', '1', '0', '105', '3');
INSERT INTO `mny_address` VALUES ('1132', '阳明区', '1', '0', '105', '3');
INSERT INTO `mny_address` VALUES ('1133', '爱民区', '1', '0', '105', '3');
INSERT INTO `mny_address` VALUES ('1134', '西安区', '1', '0', '105', '3');
INSERT INTO `mny_address` VALUES ('1135', '东宁县', '1', '0', '105', '3');
INSERT INTO `mny_address` VALUES ('1136', '林口县', '1', '0', '105', '3');
INSERT INTO `mny_address` VALUES ('1137', '绥芬河市', '1', '0', '105', '3');
INSERT INTO `mny_address` VALUES ('1138', '海林市', '1', '0', '105', '3');
INSERT INTO `mny_address` VALUES ('1139', '宁安市', '1', '0', '105', '3');
INSERT INTO `mny_address` VALUES ('1140', '穆棱市', '1', '0', '105', '3');
INSERT INTO `mny_address` VALUES ('1141', '市辖区', '1', '0', '106', '3');
INSERT INTO `mny_address` VALUES ('1142', '爱辉区', '1', '0', '106', '3');
INSERT INTO `mny_address` VALUES ('1143', '嫩江县', '1', '0', '106', '3');
INSERT INTO `mny_address` VALUES ('1144', '逊克县', '1', '0', '106', '3');
INSERT INTO `mny_address` VALUES ('1145', '孙吴县', '1', '0', '106', '3');
INSERT INTO `mny_address` VALUES ('1146', '北安市', '1', '0', '106', '3');
INSERT INTO `mny_address` VALUES ('1147', '五大连池市', '1', '0', '106', '3');
INSERT INTO `mny_address` VALUES ('1148', '市辖区', '1', '0', '107', '3');
INSERT INTO `mny_address` VALUES ('1149', '北林区', '1', '0', '107', '3');
INSERT INTO `mny_address` VALUES ('1150', '望奎县', '1', '0', '107', '3');
INSERT INTO `mny_address` VALUES ('1151', '兰西县', '1', '0', '107', '3');
INSERT INTO `mny_address` VALUES ('1152', '青冈县', '1', '0', '107', '3');
INSERT INTO `mny_address` VALUES ('1153', '庆安县', '1', '0', '107', '3');
INSERT INTO `mny_address` VALUES ('1154', '明水县', '1', '0', '107', '3');
INSERT INTO `mny_address` VALUES ('1155', '绥棱县', '1', '0', '107', '3');
INSERT INTO `mny_address` VALUES ('1156', '安达市', '1', '0', '107', '3');
INSERT INTO `mny_address` VALUES ('1157', '肇东市', '1', '0', '107', '3');
INSERT INTO `mny_address` VALUES ('1158', '海伦市', '1', '0', '107', '3');
INSERT INTO `mny_address` VALUES ('1159', '呼玛县', '1', '0', '108', '3');
INSERT INTO `mny_address` VALUES ('1160', '塔河县', '1', '0', '108', '3');
INSERT INTO `mny_address` VALUES ('1161', '漠河县', '1', '0', '108', '3');
INSERT INTO `mny_address` VALUES ('1162', '黄浦区', '1', '0', '109', '3');
INSERT INTO `mny_address` VALUES ('1163', '卢湾区', '1', '0', '109', '3');
INSERT INTO `mny_address` VALUES ('1164', '徐汇区', '1', '0', '109', '3');
INSERT INTO `mny_address` VALUES ('1165', '长宁区', '1', '0', '109', '3');
INSERT INTO `mny_address` VALUES ('1166', '静安区', '1', '0', '109', '3');
INSERT INTO `mny_address` VALUES ('1167', '普陀区', '1', '0', '109', '3');
INSERT INTO `mny_address` VALUES ('1168', '闸北区', '1', '0', '109', '3');
INSERT INTO `mny_address` VALUES ('1169', '虹口区', '1', '0', '109', '3');
INSERT INTO `mny_address` VALUES ('1170', '杨浦区', '1', '0', '109', '3');
INSERT INTO `mny_address` VALUES ('1171', '闵行区', '1', '0', '109', '3');
INSERT INTO `mny_address` VALUES ('1172', '宝山区', '1', '0', '109', '3');
INSERT INTO `mny_address` VALUES ('1173', '嘉定区', '1', '0', '109', '3');
INSERT INTO `mny_address` VALUES ('1174', '浦东新区', '1', '0', '109', '3');
INSERT INTO `mny_address` VALUES ('1175', '金山区', '1', '0', '109', '3');
INSERT INTO `mny_address` VALUES ('1176', '松江区', '1', '0', '109', '3');
INSERT INTO `mny_address` VALUES ('1177', '青浦区', '1', '0', '109', '3');
INSERT INTO `mny_address` VALUES ('1178', '南汇区', '1', '0', '109', '3');
INSERT INTO `mny_address` VALUES ('1179', '奉贤区', '1', '0', '109', '3');
INSERT INTO `mny_address` VALUES ('1180', '崇明县', '1', '0', '110', '3');
INSERT INTO `mny_address` VALUES ('1181', '市辖区', '1', '0', '111', '3');
INSERT INTO `mny_address` VALUES ('1182', '玄武区', '1', '0', '111', '3');
INSERT INTO `mny_address` VALUES ('1183', '白下区', '1', '0', '111', '3');
INSERT INTO `mny_address` VALUES ('1184', '秦淮区', '1', '0', '111', '3');
INSERT INTO `mny_address` VALUES ('1185', '建邺区', '1', '0', '111', '3');
INSERT INTO `mny_address` VALUES ('1186', '鼓楼区', '1', '0', '111', '3');
INSERT INTO `mny_address` VALUES ('1187', '下关区', '1', '0', '111', '3');
INSERT INTO `mny_address` VALUES ('1188', '浦口区', '1', '0', '111', '3');
INSERT INTO `mny_address` VALUES ('1189', '栖霞区', '1', '0', '111', '3');
INSERT INTO `mny_address` VALUES ('1190', '雨花台区', '1', '0', '111', '3');
INSERT INTO `mny_address` VALUES ('1191', '江宁区', '1', '0', '111', '3');
INSERT INTO `mny_address` VALUES ('1192', '六合区', '1', '0', '111', '3');
INSERT INTO `mny_address` VALUES ('1193', '溧水县', '1', '0', '111', '3');
INSERT INTO `mny_address` VALUES ('1194', '高淳县', '1', '0', '111', '3');
INSERT INTO `mny_address` VALUES ('1195', '市辖区', '1', '0', '112', '3');
INSERT INTO `mny_address` VALUES ('1196', '崇安区', '1', '0', '112', '3');
INSERT INTO `mny_address` VALUES ('1197', '南长区', '1', '0', '112', '3');
INSERT INTO `mny_address` VALUES ('1198', '北塘区', '1', '0', '112', '3');
INSERT INTO `mny_address` VALUES ('1199', '锡山区', '1', '0', '112', '3');
INSERT INTO `mny_address` VALUES ('1200', '惠山区', '1', '0', '112', '3');
INSERT INTO `mny_address` VALUES ('1201', '滨湖区', '1', '0', '112', '3');
INSERT INTO `mny_address` VALUES ('1202', '江阴市', '1', '0', '112', '3');
INSERT INTO `mny_address` VALUES ('1203', '宜兴市', '1', '0', '112', '3');
INSERT INTO `mny_address` VALUES ('1204', '市辖区', '1', '0', '113', '3');
INSERT INTO `mny_address` VALUES ('1205', '鼓楼区', '1', '0', '113', '3');
INSERT INTO `mny_address` VALUES ('1206', '云龙区', '1', '0', '113', '3');
INSERT INTO `mny_address` VALUES ('1207', '九里区', '1', '0', '113', '3');
INSERT INTO `mny_address` VALUES ('1208', '贾汪区', '1', '0', '113', '3');
INSERT INTO `mny_address` VALUES ('1209', '泉山区', '1', '0', '113', '3');
INSERT INTO `mny_address` VALUES ('1210', '丰　县', '1', '0', '113', '3');
INSERT INTO `mny_address` VALUES ('1211', '沛　县', '1', '0', '113', '3');
INSERT INTO `mny_address` VALUES ('1212', '铜山县', '1', '0', '113', '3');
INSERT INTO `mny_address` VALUES ('1213', '睢宁县', '1', '0', '113', '3');
INSERT INTO `mny_address` VALUES ('1214', '新沂市', '1', '0', '113', '3');
INSERT INTO `mny_address` VALUES ('1215', '邳州市', '1', '0', '113', '3');
INSERT INTO `mny_address` VALUES ('1216', '市辖区', '1', '0', '114', '3');
INSERT INTO `mny_address` VALUES ('1217', '天宁区', '1', '0', '114', '3');
INSERT INTO `mny_address` VALUES ('1218', '钟楼区', '1', '0', '114', '3');
INSERT INTO `mny_address` VALUES ('1219', '戚墅堰区', '1', '0', '114', '3');
INSERT INTO `mny_address` VALUES ('1220', '新北区', '1', '0', '114', '3');
INSERT INTO `mny_address` VALUES ('1221', '武进区', '1', '0', '114', '3');
INSERT INTO `mny_address` VALUES ('1222', '溧阳市', '1', '0', '114', '3');
INSERT INTO `mny_address` VALUES ('1223', '金坛市', '1', '0', '114', '3');
INSERT INTO `mny_address` VALUES ('1224', '市辖区', '1', '0', '115', '3');
INSERT INTO `mny_address` VALUES ('1225', '沧浪区', '1', '0', '115', '3');
INSERT INTO `mny_address` VALUES ('1226', '平江区', '1', '0', '115', '3');
INSERT INTO `mny_address` VALUES ('1227', '金阊区', '1', '0', '115', '3');
INSERT INTO `mny_address` VALUES ('1228', '虎丘区', '1', '0', '115', '3');
INSERT INTO `mny_address` VALUES ('1229', '吴中区', '1', '0', '115', '3');
INSERT INTO `mny_address` VALUES ('1230', '相城区', '1', '0', '115', '3');
INSERT INTO `mny_address` VALUES ('1231', '常熟市', '1', '0', '115', '3');
INSERT INTO `mny_address` VALUES ('1232', '张家港市', '1', '0', '115', '3');
INSERT INTO `mny_address` VALUES ('1233', '昆山市', '1', '0', '115', '3');
INSERT INTO `mny_address` VALUES ('1234', '吴江市', '1', '0', '115', '3');
INSERT INTO `mny_address` VALUES ('1235', '太仓市', '1', '0', '115', '3');
INSERT INTO `mny_address` VALUES ('1236', '市辖区', '1', '0', '116', '3');
INSERT INTO `mny_address` VALUES ('1237', '崇川区', '1', '0', '116', '3');
INSERT INTO `mny_address` VALUES ('1238', '港闸区', '1', '0', '116', '3');
INSERT INTO `mny_address` VALUES ('1239', '海安县', '1', '0', '116', '3');
INSERT INTO `mny_address` VALUES ('1240', '如东县', '1', '0', '116', '3');
INSERT INTO `mny_address` VALUES ('1241', '启东市', '1', '0', '116', '3');
INSERT INTO `mny_address` VALUES ('1242', '如皋市', '1', '0', '116', '3');
INSERT INTO `mny_address` VALUES ('1243', '通州市', '1', '0', '116', '3');
INSERT INTO `mny_address` VALUES ('1244', '海门市', '1', '0', '116', '3');
INSERT INTO `mny_address` VALUES ('1245', '市辖区', '1', '0', '117', '3');
INSERT INTO `mny_address` VALUES ('1246', '连云区', '1', '0', '117', '3');
INSERT INTO `mny_address` VALUES ('1247', '新浦区', '1', '0', '117', '3');
INSERT INTO `mny_address` VALUES ('1248', '海州区', '1', '0', '117', '3');
INSERT INTO `mny_address` VALUES ('1249', '赣榆县', '1', '0', '117', '3');
INSERT INTO `mny_address` VALUES ('1250', '东海县', '1', '0', '117', '3');
INSERT INTO `mny_address` VALUES ('1251', '灌云县', '1', '0', '117', '3');
INSERT INTO `mny_address` VALUES ('1252', '灌南县', '1', '0', '117', '3');
INSERT INTO `mny_address` VALUES ('1253', '市辖区', '1', '0', '118', '3');
INSERT INTO `mny_address` VALUES ('1254', '清河区', '1', '0', '118', '3');
INSERT INTO `mny_address` VALUES ('1255', '楚州区', '1', '0', '118', '3');
INSERT INTO `mny_address` VALUES ('1256', '淮阴区', '1', '0', '118', '3');
INSERT INTO `mny_address` VALUES ('1257', '清浦区', '1', '0', '118', '3');
INSERT INTO `mny_address` VALUES ('1258', '涟水县', '1', '0', '118', '3');
INSERT INTO `mny_address` VALUES ('1259', '洪泽县', '1', '0', '118', '3');
INSERT INTO `mny_address` VALUES ('1260', '盱眙县', '1', '0', '118', '3');
INSERT INTO `mny_address` VALUES ('1261', '金湖县', '1', '0', '118', '3');
INSERT INTO `mny_address` VALUES ('1262', '市辖区', '1', '0', '119', '3');
INSERT INTO `mny_address` VALUES ('1263', '亭湖区', '1', '0', '119', '3');
INSERT INTO `mny_address` VALUES ('1264', '盐都区', '1', '0', '119', '3');
INSERT INTO `mny_address` VALUES ('1265', '响水县', '1', '0', '119', '3');
INSERT INTO `mny_address` VALUES ('1266', '滨海县', '1', '0', '119', '3');
INSERT INTO `mny_address` VALUES ('1267', '阜宁县', '1', '0', '119', '3');
INSERT INTO `mny_address` VALUES ('1268', '射阳县', '1', '0', '119', '3');
INSERT INTO `mny_address` VALUES ('1269', '建湖县', '1', '0', '119', '3');
INSERT INTO `mny_address` VALUES ('1270', '东台市', '1', '0', '119', '3');
INSERT INTO `mny_address` VALUES ('1271', '大丰市', '1', '0', '119', '3');
INSERT INTO `mny_address` VALUES ('1272', '市辖区', '1', '0', '120', '3');
INSERT INTO `mny_address` VALUES ('1273', '广陵区', '1', '0', '120', '3');
INSERT INTO `mny_address` VALUES ('1274', '邗江区', '1', '0', '120', '3');
INSERT INTO `mny_address` VALUES ('1275', '郊　区', '1', '0', '120', '3');
INSERT INTO `mny_address` VALUES ('1276', '宝应县', '1', '0', '120', '3');
INSERT INTO `mny_address` VALUES ('1277', '仪征市', '1', '0', '120', '3');
INSERT INTO `mny_address` VALUES ('1278', '高邮市', '1', '0', '120', '3');
INSERT INTO `mny_address` VALUES ('1279', '江都市', '1', '0', '120', '3');
INSERT INTO `mny_address` VALUES ('1280', '市辖区', '1', '0', '121', '3');
INSERT INTO `mny_address` VALUES ('1281', '京口区', '1', '0', '121', '3');
INSERT INTO `mny_address` VALUES ('1282', '润州区', '1', '0', '121', '3');
INSERT INTO `mny_address` VALUES ('1283', '丹徒区', '1', '0', '121', '3');
INSERT INTO `mny_address` VALUES ('1284', '丹阳市', '1', '0', '121', '3');
INSERT INTO `mny_address` VALUES ('1285', '扬中市', '1', '0', '121', '3');
INSERT INTO `mny_address` VALUES ('1286', '句容市', '1', '0', '121', '3');
INSERT INTO `mny_address` VALUES ('1287', '市辖区', '1', '0', '122', '3');
INSERT INTO `mny_address` VALUES ('1288', '海陵区', '1', '0', '122', '3');
INSERT INTO `mny_address` VALUES ('1289', '高港区', '1', '0', '122', '3');
INSERT INTO `mny_address` VALUES ('1290', '兴化市', '1', '0', '122', '3');
INSERT INTO `mny_address` VALUES ('1291', '靖江市', '1', '0', '122', '3');
INSERT INTO `mny_address` VALUES ('1292', '泰兴市', '1', '0', '122', '3');
INSERT INTO `mny_address` VALUES ('1293', '姜堰市', '1', '0', '122', '3');
INSERT INTO `mny_address` VALUES ('1294', '市辖区', '1', '0', '123', '3');
INSERT INTO `mny_address` VALUES ('1295', '宿城区', '1', '0', '123', '3');
INSERT INTO `mny_address` VALUES ('1296', '宿豫区', '1', '0', '123', '3');
INSERT INTO `mny_address` VALUES ('1297', '沭阳县', '1', '0', '123', '3');
INSERT INTO `mny_address` VALUES ('1298', '泗阳县', '1', '0', '123', '3');
INSERT INTO `mny_address` VALUES ('1299', '泗洪县', '1', '0', '123', '3');
INSERT INTO `mny_address` VALUES ('1300', '市辖区', '1', '0', '124', '3');
INSERT INTO `mny_address` VALUES ('1301', '上城区', '1', '0', '124', '3');
INSERT INTO `mny_address` VALUES ('1302', '下城区', '1', '0', '124', '3');
INSERT INTO `mny_address` VALUES ('1303', '江干区', '1', '0', '124', '3');
INSERT INTO `mny_address` VALUES ('1304', '拱墅区', '1', '0', '124', '3');
INSERT INTO `mny_address` VALUES ('1305', '西湖区', '1', '0', '124', '3');
INSERT INTO `mny_address` VALUES ('1306', '滨江区', '1', '0', '124', '3');
INSERT INTO `mny_address` VALUES ('1307', '萧山区', '1', '0', '124', '3');
INSERT INTO `mny_address` VALUES ('1308', '余杭区', '1', '0', '124', '3');
INSERT INTO `mny_address` VALUES ('1309', '桐庐县', '1', '0', '124', '3');
INSERT INTO `mny_address` VALUES ('1310', '淳安县', '1', '0', '124', '3');
INSERT INTO `mny_address` VALUES ('1311', '建德市', '1', '0', '124', '3');
INSERT INTO `mny_address` VALUES ('1312', '富阳市', '1', '0', '124', '3');
INSERT INTO `mny_address` VALUES ('1313', '临安市', '1', '0', '124', '3');
INSERT INTO `mny_address` VALUES ('1314', '市辖区', '1', '0', '125', '3');
INSERT INTO `mny_address` VALUES ('1315', '海曙区', '1', '0', '125', '3');
INSERT INTO `mny_address` VALUES ('1316', '江东区', '1', '0', '125', '3');
INSERT INTO `mny_address` VALUES ('1317', '江北区', '1', '0', '125', '3');
INSERT INTO `mny_address` VALUES ('1318', '北仑区', '1', '0', '125', '3');
INSERT INTO `mny_address` VALUES ('1319', '镇海区', '1', '0', '125', '3');
INSERT INTO `mny_address` VALUES ('1320', '鄞州区', '1', '0', '125', '3');
INSERT INTO `mny_address` VALUES ('1321', '象山县', '1', '0', '125', '3');
INSERT INTO `mny_address` VALUES ('1322', '宁海县', '1', '0', '125', '3');
INSERT INTO `mny_address` VALUES ('1323', '余姚市', '1', '0', '125', '3');
INSERT INTO `mny_address` VALUES ('1324', '慈溪市', '1', '0', '125', '3');
INSERT INTO `mny_address` VALUES ('1325', '奉化市', '1', '0', '125', '3');
INSERT INTO `mny_address` VALUES ('1326', '市辖区', '1', '0', '126', '3');
INSERT INTO `mny_address` VALUES ('1327', '鹿城区', '1', '0', '126', '3');
INSERT INTO `mny_address` VALUES ('1328', '龙湾区', '1', '0', '126', '3');
INSERT INTO `mny_address` VALUES ('1329', '瓯海区', '1', '0', '126', '3');
INSERT INTO `mny_address` VALUES ('1330', '洞头县', '1', '0', '126', '3');
INSERT INTO `mny_address` VALUES ('1331', '永嘉县', '1', '0', '126', '3');
INSERT INTO `mny_address` VALUES ('1332', '平阳县', '1', '0', '126', '3');
INSERT INTO `mny_address` VALUES ('1333', '苍南县', '1', '0', '126', '3');
INSERT INTO `mny_address` VALUES ('1334', '文成县', '1', '0', '126', '3');
INSERT INTO `mny_address` VALUES ('1335', '泰顺县', '1', '0', '126', '3');
INSERT INTO `mny_address` VALUES ('1336', '瑞安市', '1', '0', '126', '3');
INSERT INTO `mny_address` VALUES ('1337', '乐清市', '1', '0', '126', '3');
INSERT INTO `mny_address` VALUES ('1338', '市辖区', '1', '0', '127', '3');
INSERT INTO `mny_address` VALUES ('1339', '秀城区', '1', '0', '127', '3');
INSERT INTO `mny_address` VALUES ('1340', '秀洲区', '1', '0', '127', '3');
INSERT INTO `mny_address` VALUES ('1341', '嘉善县', '1', '0', '127', '3');
INSERT INTO `mny_address` VALUES ('1342', '海盐县', '1', '0', '127', '3');
INSERT INTO `mny_address` VALUES ('1343', '海宁市', '1', '0', '127', '3');
INSERT INTO `mny_address` VALUES ('1344', '平湖市', '1', '0', '127', '3');
INSERT INTO `mny_address` VALUES ('1345', '桐乡市', '1', '0', '127', '3');
INSERT INTO `mny_address` VALUES ('1346', '市辖区', '1', '0', '128', '3');
INSERT INTO `mny_address` VALUES ('1347', '吴兴区', '1', '0', '128', '3');
INSERT INTO `mny_address` VALUES ('1348', '南浔区', '1', '0', '128', '3');
INSERT INTO `mny_address` VALUES ('1349', '德清县', '1', '0', '128', '3');
INSERT INTO `mny_address` VALUES ('1350', '长兴县', '1', '0', '128', '3');
INSERT INTO `mny_address` VALUES ('1351', '安吉县', '1', '0', '128', '3');
INSERT INTO `mny_address` VALUES ('1352', '市辖区', '1', '0', '129', '3');
INSERT INTO `mny_address` VALUES ('1353', '越城区', '1', '0', '129', '3');
INSERT INTO `mny_address` VALUES ('1354', '绍兴县', '1', '0', '129', '3');
INSERT INTO `mny_address` VALUES ('1355', '新昌县', '1', '0', '129', '3');
INSERT INTO `mny_address` VALUES ('1356', '诸暨市', '1', '0', '129', '3');
INSERT INTO `mny_address` VALUES ('1357', '上虞市', '1', '0', '129', '3');
INSERT INTO `mny_address` VALUES ('1358', '嵊州市', '1', '0', '129', '3');
INSERT INTO `mny_address` VALUES ('1359', '市辖区', '1', '0', '130', '3');
INSERT INTO `mny_address` VALUES ('1360', '婺城区', '1', '0', '130', '3');
INSERT INTO `mny_address` VALUES ('1361', '金东区', '1', '0', '130', '3');
INSERT INTO `mny_address` VALUES ('1362', '武义县', '1', '0', '130', '3');
INSERT INTO `mny_address` VALUES ('1363', '浦江县', '1', '0', '130', '3');
INSERT INTO `mny_address` VALUES ('1364', '磐安县', '1', '0', '130', '3');
INSERT INTO `mny_address` VALUES ('1365', '兰溪市', '1', '0', '130', '3');
INSERT INTO `mny_address` VALUES ('1366', '义乌市', '1', '0', '130', '3');
INSERT INTO `mny_address` VALUES ('1367', '东阳市', '1', '0', '130', '3');
INSERT INTO `mny_address` VALUES ('1368', '永康市', '1', '0', '130', '3');
INSERT INTO `mny_address` VALUES ('1369', '市辖区', '1', '0', '131', '3');
INSERT INTO `mny_address` VALUES ('1370', '柯城区', '1', '0', '131', '3');
INSERT INTO `mny_address` VALUES ('1371', '衢江区', '1', '0', '131', '3');
INSERT INTO `mny_address` VALUES ('1372', '常山县', '1', '0', '131', '3');
INSERT INTO `mny_address` VALUES ('1373', '开化县', '1', '0', '131', '3');
INSERT INTO `mny_address` VALUES ('1374', '龙游县', '1', '0', '131', '3');
INSERT INTO `mny_address` VALUES ('1375', '江山市', '1', '0', '131', '3');
INSERT INTO `mny_address` VALUES ('1376', '市辖区', '1', '0', '132', '3');
INSERT INTO `mny_address` VALUES ('1377', '定海区', '1', '0', '132', '3');
INSERT INTO `mny_address` VALUES ('1378', '普陀区', '1', '0', '132', '3');
INSERT INTO `mny_address` VALUES ('1379', '岱山县', '1', '0', '132', '3');
INSERT INTO `mny_address` VALUES ('1380', '嵊泗县', '1', '0', '132', '3');
INSERT INTO `mny_address` VALUES ('1381', '市辖区', '1', '0', '133', '3');
INSERT INTO `mny_address` VALUES ('1382', '椒江区', '1', '0', '133', '3');
INSERT INTO `mny_address` VALUES ('1383', '黄岩区', '1', '0', '133', '3');
INSERT INTO `mny_address` VALUES ('1384', '路桥区', '1', '0', '133', '3');
INSERT INTO `mny_address` VALUES ('1385', '玉环县', '1', '0', '133', '3');
INSERT INTO `mny_address` VALUES ('1386', '三门县', '1', '0', '133', '3');
INSERT INTO `mny_address` VALUES ('1387', '天台县', '1', '0', '133', '3');
INSERT INTO `mny_address` VALUES ('1388', '仙居县', '1', '0', '133', '3');
INSERT INTO `mny_address` VALUES ('1389', '温岭市', '1', '0', '133', '3');
INSERT INTO `mny_address` VALUES ('1390', '临海市', '1', '0', '133', '3');
INSERT INTO `mny_address` VALUES ('1391', '市辖区', '1', '0', '134', '3');
INSERT INTO `mny_address` VALUES ('1392', '莲都区', '1', '0', '134', '3');
INSERT INTO `mny_address` VALUES ('1393', '青田县', '1', '0', '134', '3');
INSERT INTO `mny_address` VALUES ('1394', '缙云县', '1', '0', '134', '3');
INSERT INTO `mny_address` VALUES ('1395', '遂昌县', '1', '0', '134', '3');
INSERT INTO `mny_address` VALUES ('1396', '松阳县', '1', '0', '134', '3');
INSERT INTO `mny_address` VALUES ('1397', '云和县', '1', '0', '134', '3');
INSERT INTO `mny_address` VALUES ('1398', '庆元县', '1', '0', '134', '3');
INSERT INTO `mny_address` VALUES ('1399', '景宁畲族自治县', '1', '0', '134', '3');
INSERT INTO `mny_address` VALUES ('1400', '龙泉市', '1', '0', '134', '3');
INSERT INTO `mny_address` VALUES ('1401', '市辖区', '1', '0', '135', '3');
INSERT INTO `mny_address` VALUES ('1402', '瑶海区', '1', '0', '135', '3');
INSERT INTO `mny_address` VALUES ('1403', '庐阳区', '1', '0', '135', '3');
INSERT INTO `mny_address` VALUES ('1404', '蜀山区', '1', '0', '135', '3');
INSERT INTO `mny_address` VALUES ('1405', '包河区', '1', '0', '135', '3');
INSERT INTO `mny_address` VALUES ('1406', '长丰县', '1', '0', '135', '3');
INSERT INTO `mny_address` VALUES ('1407', '肥东县', '1', '0', '135', '3');
INSERT INTO `mny_address` VALUES ('1408', '肥西县', '1', '0', '135', '3');
INSERT INTO `mny_address` VALUES ('1409', '市辖区', '1', '0', '136', '3');
INSERT INTO `mny_address` VALUES ('1410', '镜湖区', '1', '0', '136', '3');
INSERT INTO `mny_address` VALUES ('1411', '马塘区', '1', '0', '136', '3');
INSERT INTO `mny_address` VALUES ('1412', '新芜区', '1', '0', '136', '3');
INSERT INTO `mny_address` VALUES ('1413', '鸠江区', '1', '0', '136', '3');
INSERT INTO `mny_address` VALUES ('1414', '芜湖县', '1', '0', '136', '3');
INSERT INTO `mny_address` VALUES ('1415', '繁昌县', '1', '0', '136', '3');
INSERT INTO `mny_address` VALUES ('1416', '南陵县', '1', '0', '136', '3');
INSERT INTO `mny_address` VALUES ('1417', '市辖区', '1', '0', '137', '3');
INSERT INTO `mny_address` VALUES ('1418', '龙子湖区', '1', '0', '137', '3');
INSERT INTO `mny_address` VALUES ('1419', '蚌山区', '1', '0', '137', '3');
INSERT INTO `mny_address` VALUES ('1420', '禹会区', '1', '0', '137', '3');
INSERT INTO `mny_address` VALUES ('1421', '淮上区', '1', '0', '137', '3');
INSERT INTO `mny_address` VALUES ('1422', '怀远县', '1', '0', '137', '3');
INSERT INTO `mny_address` VALUES ('1423', '五河县', '1', '0', '137', '3');
INSERT INTO `mny_address` VALUES ('1424', '固镇县', '1', '0', '137', '3');
INSERT INTO `mny_address` VALUES ('1425', '市辖区', '1', '0', '138', '3');
INSERT INTO `mny_address` VALUES ('1426', '大通区', '1', '0', '138', '3');
INSERT INTO `mny_address` VALUES ('1427', '田家庵区', '1', '0', '138', '3');
INSERT INTO `mny_address` VALUES ('1428', '谢家集区', '1', '0', '138', '3');
INSERT INTO `mny_address` VALUES ('1429', '八公山区', '1', '0', '138', '3');
INSERT INTO `mny_address` VALUES ('1430', '潘集区', '1', '0', '138', '3');
INSERT INTO `mny_address` VALUES ('1431', '凤台县', '1', '0', '138', '3');
INSERT INTO `mny_address` VALUES ('1432', '市辖区', '1', '0', '139', '3');
INSERT INTO `mny_address` VALUES ('1433', '金家庄区', '1', '0', '139', '3');
INSERT INTO `mny_address` VALUES ('1434', '花山区', '1', '0', '139', '3');
INSERT INTO `mny_address` VALUES ('1435', '雨山区', '1', '0', '139', '3');
INSERT INTO `mny_address` VALUES ('1436', '当涂县', '1', '0', '139', '3');
INSERT INTO `mny_address` VALUES ('1437', '市辖区', '1', '0', '140', '3');
INSERT INTO `mny_address` VALUES ('1438', '杜集区', '1', '0', '140', '3');
INSERT INTO `mny_address` VALUES ('1439', '相山区', '1', '0', '140', '3');
INSERT INTO `mny_address` VALUES ('1440', '烈山区', '1', '0', '140', '3');
INSERT INTO `mny_address` VALUES ('1441', '濉溪县', '1', '0', '140', '3');
INSERT INTO `mny_address` VALUES ('1442', '市辖区', '1', '0', '141', '3');
INSERT INTO `mny_address` VALUES ('1443', '铜官山区', '1', '0', '141', '3');
INSERT INTO `mny_address` VALUES ('1444', '狮子山区', '1', '0', '141', '3');
INSERT INTO `mny_address` VALUES ('1445', '郊　区', '1', '0', '141', '3');
INSERT INTO `mny_address` VALUES ('1446', '铜陵县', '1', '0', '141', '3');
INSERT INTO `mny_address` VALUES ('1447', '市辖区', '1', '0', '142', '3');
INSERT INTO `mny_address` VALUES ('1448', '迎江区', '1', '0', '142', '3');
INSERT INTO `mny_address` VALUES ('1449', '大观区', '1', '0', '142', '3');
INSERT INTO `mny_address` VALUES ('1450', '郊　区', '1', '0', '142', '3');
INSERT INTO `mny_address` VALUES ('1451', '怀宁县', '1', '0', '142', '3');
INSERT INTO `mny_address` VALUES ('1452', '枞阳县', '1', '0', '142', '3');
INSERT INTO `mny_address` VALUES ('1453', '潜山县', '1', '0', '142', '3');
INSERT INTO `mny_address` VALUES ('1454', '太湖县', '1', '0', '142', '3');
INSERT INTO `mny_address` VALUES ('1455', '宿松县', '1', '0', '142', '3');
INSERT INTO `mny_address` VALUES ('1456', '望江县', '1', '0', '142', '3');
INSERT INTO `mny_address` VALUES ('1457', '岳西县', '1', '0', '142', '3');
INSERT INTO `mny_address` VALUES ('1458', '桐城市', '1', '0', '142', '3');
INSERT INTO `mny_address` VALUES ('1459', '市辖区', '1', '0', '143', '3');
INSERT INTO `mny_address` VALUES ('1460', '屯溪区', '1', '0', '143', '3');
INSERT INTO `mny_address` VALUES ('1461', '黄山区', '1', '0', '143', '3');
INSERT INTO `mny_address` VALUES ('1462', '徽州区', '1', '0', '143', '3');
INSERT INTO `mny_address` VALUES ('1463', '歙　县', '1', '0', '143', '3');
INSERT INTO `mny_address` VALUES ('1464', '休宁县', '1', '0', '143', '3');
INSERT INTO `mny_address` VALUES ('1465', '黟　县', '1', '0', '143', '3');
INSERT INTO `mny_address` VALUES ('1466', '祁门县', '1', '0', '143', '3');
INSERT INTO `mny_address` VALUES ('1467', '市辖区', '1', '0', '144', '3');
INSERT INTO `mny_address` VALUES ('1468', '琅琊区', '1', '0', '144', '3');
INSERT INTO `mny_address` VALUES ('1469', '南谯区', '1', '0', '144', '3');
INSERT INTO `mny_address` VALUES ('1470', '来安县', '1', '0', '144', '3');
INSERT INTO `mny_address` VALUES ('1471', '全椒县', '1', '0', '144', '3');
INSERT INTO `mny_address` VALUES ('1472', '定远县', '1', '0', '144', '3');
INSERT INTO `mny_address` VALUES ('1473', '凤阳县', '1', '0', '144', '3');
INSERT INTO `mny_address` VALUES ('1474', '天长市', '1', '0', '144', '3');
INSERT INTO `mny_address` VALUES ('1475', '明光市', '1', '0', '144', '3');
INSERT INTO `mny_address` VALUES ('1476', '市辖区', '1', '0', '145', '3');
INSERT INTO `mny_address` VALUES ('1477', '颍州区', '1', '0', '145', '3');
INSERT INTO `mny_address` VALUES ('1478', '颍东区', '1', '0', '145', '3');
INSERT INTO `mny_address` VALUES ('1479', '颍泉区', '1', '0', '145', '3');
INSERT INTO `mny_address` VALUES ('1480', '临泉县', '1', '0', '145', '3');
INSERT INTO `mny_address` VALUES ('1481', '太和县', '1', '0', '145', '3');
INSERT INTO `mny_address` VALUES ('1482', '阜南县', '1', '0', '145', '3');
INSERT INTO `mny_address` VALUES ('1483', '颍上县', '1', '0', '145', '3');
INSERT INTO `mny_address` VALUES ('1484', '界首市', '1', '0', '145', '3');
INSERT INTO `mny_address` VALUES ('1485', '市辖区', '1', '0', '146', '3');
INSERT INTO `mny_address` VALUES ('1486', '墉桥区', '1', '0', '146', '3');
INSERT INTO `mny_address` VALUES ('1487', '砀山县', '1', '0', '146', '3');
INSERT INTO `mny_address` VALUES ('1488', '萧　县', '1', '0', '146', '3');
INSERT INTO `mny_address` VALUES ('1489', '灵璧县', '1', '0', '146', '3');
INSERT INTO `mny_address` VALUES ('1490', '泗　县', '1', '0', '146', '3');
INSERT INTO `mny_address` VALUES ('1491', '市辖区', '1', '0', '147', '3');
INSERT INTO `mny_address` VALUES ('1492', '居巢区', '1', '0', '147', '3');
INSERT INTO `mny_address` VALUES ('1493', '庐江县', '1', '0', '147', '3');
INSERT INTO `mny_address` VALUES ('1494', '无为县', '1', '0', '147', '3');
INSERT INTO `mny_address` VALUES ('1495', '含山县', '1', '0', '147', '3');
INSERT INTO `mny_address` VALUES ('1496', '和　县', '1', '0', '147', '3');
INSERT INTO `mny_address` VALUES ('1497', '市辖区', '1', '0', '148', '3');
INSERT INTO `mny_address` VALUES ('1498', '金安区', '1', '0', '148', '3');
INSERT INTO `mny_address` VALUES ('1499', '裕安区', '1', '0', '148', '3');
INSERT INTO `mny_address` VALUES ('1500', '寿　县', '1', '0', '148', '3');
INSERT INTO `mny_address` VALUES ('1501', '霍邱县', '1', '0', '148', '3');
INSERT INTO `mny_address` VALUES ('1502', '舒城县', '1', '0', '148', '3');
INSERT INTO `mny_address` VALUES ('1503', '金寨县', '1', '0', '148', '3');
INSERT INTO `mny_address` VALUES ('1504', '霍山县', '1', '0', '148', '3');
INSERT INTO `mny_address` VALUES ('1505', '市辖区', '1', '0', '149', '3');
INSERT INTO `mny_address` VALUES ('1506', '谯城区', '1', '0', '149', '3');
INSERT INTO `mny_address` VALUES ('1507', '涡阳县', '1', '0', '149', '3');
INSERT INTO `mny_address` VALUES ('1508', '蒙城县', '1', '0', '149', '3');
INSERT INTO `mny_address` VALUES ('1509', '利辛县', '1', '0', '149', '3');
INSERT INTO `mny_address` VALUES ('1510', '市辖区', '1', '0', '150', '3');
INSERT INTO `mny_address` VALUES ('1511', '贵池区', '1', '0', '150', '3');
INSERT INTO `mny_address` VALUES ('1512', '东至县', '1', '0', '150', '3');
INSERT INTO `mny_address` VALUES ('1513', '石台县', '1', '0', '150', '3');
INSERT INTO `mny_address` VALUES ('1514', '青阳县', '1', '0', '150', '3');
INSERT INTO `mny_address` VALUES ('1515', '市辖区', '1', '0', '151', '3');
INSERT INTO `mny_address` VALUES ('1516', '宣州区', '1', '0', '151', '3');
INSERT INTO `mny_address` VALUES ('1517', '郎溪县', '1', '0', '151', '3');
INSERT INTO `mny_address` VALUES ('1518', '广德县', '1', '0', '151', '3');
INSERT INTO `mny_address` VALUES ('1519', '泾　县', '1', '0', '151', '3');
INSERT INTO `mny_address` VALUES ('1520', '绩溪县', '1', '0', '151', '3');
INSERT INTO `mny_address` VALUES ('1521', '旌德县', '1', '0', '151', '3');
INSERT INTO `mny_address` VALUES ('1522', '宁国市', '1', '0', '151', '3');
INSERT INTO `mny_address` VALUES ('1523', '市辖区', '1', '0', '152', '3');
INSERT INTO `mny_address` VALUES ('1524', '鼓楼区', '1', '0', '152', '3');
INSERT INTO `mny_address` VALUES ('1525', '台江区', '1', '0', '152', '3');
INSERT INTO `mny_address` VALUES ('1526', '仓山区', '1', '0', '152', '3');
INSERT INTO `mny_address` VALUES ('1527', '马尾区', '1', '0', '152', '3');
INSERT INTO `mny_address` VALUES ('1528', '晋安区', '1', '0', '152', '3');
INSERT INTO `mny_address` VALUES ('1529', '闽侯县', '1', '0', '152', '3');
INSERT INTO `mny_address` VALUES ('1530', '连江县', '1', '0', '152', '3');
INSERT INTO `mny_address` VALUES ('1531', '罗源县', '1', '0', '152', '3');
INSERT INTO `mny_address` VALUES ('1532', '闽清县', '1', '0', '152', '3');
INSERT INTO `mny_address` VALUES ('1533', '永泰县', '1', '0', '152', '3');
INSERT INTO `mny_address` VALUES ('1534', '平潭县', '1', '0', '152', '3');
INSERT INTO `mny_address` VALUES ('1535', '福清市', '1', '0', '152', '3');
INSERT INTO `mny_address` VALUES ('1536', '长乐市', '1', '0', '152', '3');
INSERT INTO `mny_address` VALUES ('1537', '市辖区', '1', '0', '153', '3');
INSERT INTO `mny_address` VALUES ('1538', '思明区', '1', '0', '153', '3');
INSERT INTO `mny_address` VALUES ('1539', '海沧区', '1', '0', '153', '3');
INSERT INTO `mny_address` VALUES ('1540', '湖里区', '1', '0', '153', '3');
INSERT INTO `mny_address` VALUES ('1541', '集美区', '1', '0', '153', '3');
INSERT INTO `mny_address` VALUES ('1542', '同安区', '1', '0', '153', '3');
INSERT INTO `mny_address` VALUES ('1543', '翔安区', '1', '0', '153', '3');
INSERT INTO `mny_address` VALUES ('1544', '市辖区', '1', '0', '154', '3');
INSERT INTO `mny_address` VALUES ('1545', '城厢区', '1', '0', '154', '3');
INSERT INTO `mny_address` VALUES ('1546', '涵江区', '1', '0', '154', '3');
INSERT INTO `mny_address` VALUES ('1547', '荔城区', '1', '0', '154', '3');
INSERT INTO `mny_address` VALUES ('1548', '秀屿区', '1', '0', '154', '3');
INSERT INTO `mny_address` VALUES ('1549', '仙游县', '1', '0', '154', '3');
INSERT INTO `mny_address` VALUES ('1550', '市辖区', '1', '0', '155', '3');
INSERT INTO `mny_address` VALUES ('1551', '梅列区', '1', '0', '155', '3');
INSERT INTO `mny_address` VALUES ('1552', '三元区', '1', '0', '155', '3');
INSERT INTO `mny_address` VALUES ('1553', '明溪县', '1', '0', '155', '3');
INSERT INTO `mny_address` VALUES ('1554', '清流县', '1', '0', '155', '3');
INSERT INTO `mny_address` VALUES ('1555', '宁化县', '1', '0', '155', '3');
INSERT INTO `mny_address` VALUES ('1556', '大田县', '1', '0', '155', '3');
INSERT INTO `mny_address` VALUES ('1557', '尤溪县', '1', '0', '155', '3');
INSERT INTO `mny_address` VALUES ('1558', '沙　县', '1', '0', '155', '3');
INSERT INTO `mny_address` VALUES ('1559', '将乐县', '1', '0', '155', '3');
INSERT INTO `mny_address` VALUES ('1560', '泰宁县', '1', '0', '155', '3');
INSERT INTO `mny_address` VALUES ('1561', '建宁县', '1', '0', '155', '3');
INSERT INTO `mny_address` VALUES ('1562', '永安市', '1', '0', '155', '3');
INSERT INTO `mny_address` VALUES ('1563', '市辖区', '1', '0', '156', '3');
INSERT INTO `mny_address` VALUES ('1564', '鲤城区', '1', '0', '156', '3');
INSERT INTO `mny_address` VALUES ('1565', '丰泽区', '1', '0', '156', '3');
INSERT INTO `mny_address` VALUES ('1566', '洛江区', '1', '0', '156', '3');
INSERT INTO `mny_address` VALUES ('1567', '泉港区', '1', '0', '156', '3');
INSERT INTO `mny_address` VALUES ('1568', '惠安县', '1', '0', '156', '3');
INSERT INTO `mny_address` VALUES ('1569', '安溪县', '1', '0', '156', '3');
INSERT INTO `mny_address` VALUES ('1570', '永春县', '1', '0', '156', '3');
INSERT INTO `mny_address` VALUES ('1571', '德化县', '1', '0', '156', '3');
INSERT INTO `mny_address` VALUES ('1572', '金门县', '1', '0', '156', '3');
INSERT INTO `mny_address` VALUES ('1573', '石狮市', '1', '0', '156', '3');
INSERT INTO `mny_address` VALUES ('1574', '晋江市', '1', '0', '156', '3');
INSERT INTO `mny_address` VALUES ('1575', '南安市', '1', '0', '156', '3');
INSERT INTO `mny_address` VALUES ('1576', '市辖区', '1', '0', '157', '3');
INSERT INTO `mny_address` VALUES ('1577', '芗城区', '1', '0', '157', '3');
INSERT INTO `mny_address` VALUES ('1578', '龙文区', '1', '0', '157', '3');
INSERT INTO `mny_address` VALUES ('1579', '云霄县', '1', '0', '157', '3');
INSERT INTO `mny_address` VALUES ('1580', '漳浦县', '1', '0', '157', '3');
INSERT INTO `mny_address` VALUES ('1581', '诏安县', '1', '0', '157', '3');
INSERT INTO `mny_address` VALUES ('1582', '长泰县', '1', '0', '157', '3');
INSERT INTO `mny_address` VALUES ('1583', '东山县', '1', '0', '157', '3');
INSERT INTO `mny_address` VALUES ('1584', '南靖县', '1', '0', '157', '3');
INSERT INTO `mny_address` VALUES ('1585', '平和县', '1', '0', '157', '3');
INSERT INTO `mny_address` VALUES ('1586', '华安县', '1', '0', '157', '3');
INSERT INTO `mny_address` VALUES ('1587', '龙海市', '1', '0', '157', '3');
INSERT INTO `mny_address` VALUES ('1588', '市辖区', '1', '0', '158', '3');
INSERT INTO `mny_address` VALUES ('1589', '延平区', '1', '0', '158', '3');
INSERT INTO `mny_address` VALUES ('1590', '顺昌县', '1', '0', '158', '3');
INSERT INTO `mny_address` VALUES ('1591', '浦城县', '1', '0', '158', '3');
INSERT INTO `mny_address` VALUES ('1592', '光泽县', '1', '0', '158', '3');
INSERT INTO `mny_address` VALUES ('1593', '松溪县', '1', '0', '158', '3');
INSERT INTO `mny_address` VALUES ('1594', '政和县', '1', '0', '158', '3');
INSERT INTO `mny_address` VALUES ('1595', '邵武市', '1', '0', '158', '3');
INSERT INTO `mny_address` VALUES ('1596', '武夷山市', '1', '0', '158', '3');
INSERT INTO `mny_address` VALUES ('1597', '建瓯市', '1', '0', '158', '3');
INSERT INTO `mny_address` VALUES ('1598', '建阳市', '1', '0', '158', '3');
INSERT INTO `mny_address` VALUES ('1599', '市辖区', '1', '0', '159', '3');
INSERT INTO `mny_address` VALUES ('1600', '新罗区', '1', '0', '159', '3');
INSERT INTO `mny_address` VALUES ('1601', '长汀县', '1', '0', '159', '3');
INSERT INTO `mny_address` VALUES ('1602', '永定县', '1', '0', '159', '3');
INSERT INTO `mny_address` VALUES ('1603', '上杭县', '1', '0', '159', '3');
INSERT INTO `mny_address` VALUES ('1604', '武平县', '1', '0', '159', '3');
INSERT INTO `mny_address` VALUES ('1605', '连城县', '1', '0', '159', '3');
INSERT INTO `mny_address` VALUES ('1606', '漳平市', '1', '0', '159', '3');
INSERT INTO `mny_address` VALUES ('1607', '市辖区', '1', '0', '160', '3');
INSERT INTO `mny_address` VALUES ('1608', '蕉城区', '1', '0', '160', '3');
INSERT INTO `mny_address` VALUES ('1609', '霞浦县', '1', '0', '160', '3');
INSERT INTO `mny_address` VALUES ('1610', '古田县', '1', '0', '160', '3');
INSERT INTO `mny_address` VALUES ('1611', '屏南县', '1', '0', '160', '3');
INSERT INTO `mny_address` VALUES ('1612', '寿宁县', '1', '0', '160', '3');
INSERT INTO `mny_address` VALUES ('1613', '周宁县', '1', '0', '160', '3');
INSERT INTO `mny_address` VALUES ('1614', '柘荣县', '1', '0', '160', '3');
INSERT INTO `mny_address` VALUES ('1615', '福安市', '1', '0', '160', '3');
INSERT INTO `mny_address` VALUES ('1616', '福鼎市', '1', '0', '160', '3');
INSERT INTO `mny_address` VALUES ('1617', '市辖区', '1', '0', '161', '3');
INSERT INTO `mny_address` VALUES ('1618', '东湖区', '1', '0', '161', '3');
INSERT INTO `mny_address` VALUES ('1619', '西湖区', '1', '0', '161', '3');
INSERT INTO `mny_address` VALUES ('1620', '青云谱区', '1', '0', '161', '3');
INSERT INTO `mny_address` VALUES ('1621', '湾里区', '1', '0', '161', '3');
INSERT INTO `mny_address` VALUES ('1622', '青山湖区', '1', '0', '161', '3');
INSERT INTO `mny_address` VALUES ('1623', '南昌县', '1', '0', '161', '3');
INSERT INTO `mny_address` VALUES ('1624', '新建县', '1', '0', '161', '3');
INSERT INTO `mny_address` VALUES ('1625', '安义县', '1', '0', '161', '3');
INSERT INTO `mny_address` VALUES ('1626', '进贤县', '1', '0', '161', '3');
INSERT INTO `mny_address` VALUES ('1627', '市辖区', '1', '0', '162', '3');
INSERT INTO `mny_address` VALUES ('1628', '昌江区', '1', '0', '162', '3');
INSERT INTO `mny_address` VALUES ('1629', '珠山区', '1', '0', '162', '3');
INSERT INTO `mny_address` VALUES ('1630', '浮梁县', '1', '0', '162', '3');
INSERT INTO `mny_address` VALUES ('1631', '乐平市', '1', '0', '162', '3');
INSERT INTO `mny_address` VALUES ('1632', '市辖区', '1', '0', '163', '3');
INSERT INTO `mny_address` VALUES ('1633', '安源区', '1', '0', '163', '3');
INSERT INTO `mny_address` VALUES ('1634', '湘东区', '1', '0', '163', '3');
INSERT INTO `mny_address` VALUES ('1635', '莲花县', '1', '0', '163', '3');
INSERT INTO `mny_address` VALUES ('1636', '上栗县', '1', '0', '163', '3');
INSERT INTO `mny_address` VALUES ('1637', '芦溪县', '1', '0', '163', '3');
INSERT INTO `mny_address` VALUES ('1638', '市辖区', '1', '0', '164', '3');
INSERT INTO `mny_address` VALUES ('1639', '庐山区', '1', '0', '164', '3');
INSERT INTO `mny_address` VALUES ('1640', '浔阳区', '1', '0', '164', '3');
INSERT INTO `mny_address` VALUES ('1641', '九江县', '1', '0', '164', '3');
INSERT INTO `mny_address` VALUES ('1642', '武宁县', '1', '0', '164', '3');
INSERT INTO `mny_address` VALUES ('1643', '修水县', '1', '0', '164', '3');
INSERT INTO `mny_address` VALUES ('1644', '永修县', '1', '0', '164', '3');
INSERT INTO `mny_address` VALUES ('1645', '德安县', '1', '0', '164', '3');
INSERT INTO `mny_address` VALUES ('1646', '星子县', '1', '0', '164', '3');
INSERT INTO `mny_address` VALUES ('1647', '都昌县', '1', '0', '164', '3');
INSERT INTO `mny_address` VALUES ('1648', '湖口县', '1', '0', '164', '3');
INSERT INTO `mny_address` VALUES ('1649', '彭泽县', '1', '0', '164', '3');
INSERT INTO `mny_address` VALUES ('1650', '瑞昌市', '1', '0', '164', '3');
INSERT INTO `mny_address` VALUES ('1651', '市辖区', '1', '0', '165', '3');
INSERT INTO `mny_address` VALUES ('1652', '渝水区', '1', '0', '165', '3');
INSERT INTO `mny_address` VALUES ('1653', '分宜县', '1', '0', '165', '3');
INSERT INTO `mny_address` VALUES ('1654', '市辖区', '1', '0', '166', '3');
INSERT INTO `mny_address` VALUES ('1655', '月湖区', '1', '0', '166', '3');
INSERT INTO `mny_address` VALUES ('1656', '余江县', '1', '0', '166', '3');
INSERT INTO `mny_address` VALUES ('1657', '贵溪市', '1', '0', '166', '3');
INSERT INTO `mny_address` VALUES ('1658', '市辖区', '1', '0', '167', '3');
INSERT INTO `mny_address` VALUES ('1659', '章贡区', '1', '0', '167', '3');
INSERT INTO `mny_address` VALUES ('1660', '赣　县', '1', '0', '167', '3');
INSERT INTO `mny_address` VALUES ('1661', '信丰县', '1', '0', '167', '3');
INSERT INTO `mny_address` VALUES ('1662', '大余县', '1', '0', '167', '3');
INSERT INTO `mny_address` VALUES ('1663', '上犹县', '1', '0', '167', '3');
INSERT INTO `mny_address` VALUES ('1664', '崇义县', '1', '0', '167', '3');
INSERT INTO `mny_address` VALUES ('1665', '安远县', '1', '0', '167', '3');
INSERT INTO `mny_address` VALUES ('1666', '龙南县', '1', '0', '167', '3');
INSERT INTO `mny_address` VALUES ('1667', '定南县', '1', '0', '167', '3');
INSERT INTO `mny_address` VALUES ('1668', '全南县', '1', '0', '167', '3');
INSERT INTO `mny_address` VALUES ('1669', '宁都县', '1', '0', '167', '3');
INSERT INTO `mny_address` VALUES ('1670', '于都县', '1', '0', '167', '3');
INSERT INTO `mny_address` VALUES ('1671', '兴国县', '1', '0', '167', '3');
INSERT INTO `mny_address` VALUES ('1672', '会昌县', '1', '0', '167', '3');
INSERT INTO `mny_address` VALUES ('1673', '寻乌县', '1', '0', '167', '3');
INSERT INTO `mny_address` VALUES ('1674', '石城县', '1', '0', '167', '3');
INSERT INTO `mny_address` VALUES ('1675', '瑞金市', '1', '0', '167', '3');
INSERT INTO `mny_address` VALUES ('1676', '南康市', '1', '0', '167', '3');
INSERT INTO `mny_address` VALUES ('1677', '市辖区', '1', '0', '168', '3');
INSERT INTO `mny_address` VALUES ('1678', '吉州区', '1', '0', '168', '3');
INSERT INTO `mny_address` VALUES ('1679', '青原区', '1', '0', '168', '3');
INSERT INTO `mny_address` VALUES ('1680', '吉安县', '1', '0', '168', '3');
INSERT INTO `mny_address` VALUES ('1681', '吉水县', '1', '0', '168', '3');
INSERT INTO `mny_address` VALUES ('1682', '峡江县', '1', '0', '168', '3');
INSERT INTO `mny_address` VALUES ('1683', '新干县', '1', '0', '168', '3');
INSERT INTO `mny_address` VALUES ('1684', '永丰县', '1', '0', '168', '3');
INSERT INTO `mny_address` VALUES ('1685', '泰和县', '1', '0', '168', '3');
INSERT INTO `mny_address` VALUES ('1686', '遂川县', '1', '0', '168', '3');
INSERT INTO `mny_address` VALUES ('1687', '万安县', '1', '0', '168', '3');
INSERT INTO `mny_address` VALUES ('1688', '安福县', '1', '0', '168', '3');
INSERT INTO `mny_address` VALUES ('1689', '永新县', '1', '0', '168', '3');
INSERT INTO `mny_address` VALUES ('1690', '井冈山市', '1', '0', '168', '3');
INSERT INTO `mny_address` VALUES ('1691', '市辖区', '1', '0', '169', '3');
INSERT INTO `mny_address` VALUES ('1692', '袁州区', '1', '0', '169', '3');
INSERT INTO `mny_address` VALUES ('1693', '奉新县', '1', '0', '169', '3');
INSERT INTO `mny_address` VALUES ('1694', '万载县', '1', '0', '169', '3');
INSERT INTO `mny_address` VALUES ('1695', '上高县', '1', '0', '169', '3');
INSERT INTO `mny_address` VALUES ('1696', '宜丰县', '1', '0', '169', '3');
INSERT INTO `mny_address` VALUES ('1697', '靖安县', '1', '0', '169', '3');
INSERT INTO `mny_address` VALUES ('1698', '铜鼓县', '1', '0', '169', '3');
INSERT INTO `mny_address` VALUES ('1699', '丰城市', '1', '0', '169', '3');
INSERT INTO `mny_address` VALUES ('1700', '樟树市', '1', '0', '169', '3');
INSERT INTO `mny_address` VALUES ('1701', '高安市', '1', '0', '169', '3');
INSERT INTO `mny_address` VALUES ('1702', '市辖区', '1', '0', '170', '3');
INSERT INTO `mny_address` VALUES ('1703', '临川区', '1', '0', '170', '3');
INSERT INTO `mny_address` VALUES ('1704', '南城县', '1', '0', '170', '3');
INSERT INTO `mny_address` VALUES ('1705', '黎川县', '1', '0', '170', '3');
INSERT INTO `mny_address` VALUES ('1706', '南丰县', '1', '0', '170', '3');
INSERT INTO `mny_address` VALUES ('1707', '崇仁县', '1', '0', '170', '3');
INSERT INTO `mny_address` VALUES ('1708', '乐安县', '1', '0', '170', '3');
INSERT INTO `mny_address` VALUES ('1709', '宜黄县', '1', '0', '170', '3');
INSERT INTO `mny_address` VALUES ('1710', '金溪县', '1', '0', '170', '3');
INSERT INTO `mny_address` VALUES ('1711', '资溪县', '1', '0', '170', '3');
INSERT INTO `mny_address` VALUES ('1712', '东乡县', '1', '0', '170', '3');
INSERT INTO `mny_address` VALUES ('1713', '广昌县', '1', '0', '170', '3');
INSERT INTO `mny_address` VALUES ('1714', '市辖区', '1', '0', '171', '3');
INSERT INTO `mny_address` VALUES ('1715', '信州区', '1', '0', '171', '3');
INSERT INTO `mny_address` VALUES ('1716', '上饶县', '1', '0', '171', '3');
INSERT INTO `mny_address` VALUES ('1717', '广丰县', '1', '0', '171', '3');
INSERT INTO `mny_address` VALUES ('1718', '玉山县', '1', '0', '171', '3');
INSERT INTO `mny_address` VALUES ('1719', '铅山县', '1', '0', '171', '3');
INSERT INTO `mny_address` VALUES ('1720', '横峰县', '1', '0', '171', '3');
INSERT INTO `mny_address` VALUES ('1721', '弋阳县', '1', '0', '171', '3');
INSERT INTO `mny_address` VALUES ('1722', '余干县', '1', '0', '171', '3');
INSERT INTO `mny_address` VALUES ('1723', '鄱阳县', '1', '0', '171', '3');
INSERT INTO `mny_address` VALUES ('1724', '万年县', '1', '0', '171', '3');
INSERT INTO `mny_address` VALUES ('1725', '婺源县', '1', '0', '171', '3');
INSERT INTO `mny_address` VALUES ('1726', '德兴市', '1', '0', '171', '3');
INSERT INTO `mny_address` VALUES ('1727', '市辖区', '1', '0', '172', '3');
INSERT INTO `mny_address` VALUES ('1728', '历下区', '1', '0', '172', '3');
INSERT INTO `mny_address` VALUES ('1729', '市中区', '1', '0', '172', '3');
INSERT INTO `mny_address` VALUES ('1730', '槐荫区', '1', '0', '172', '3');
INSERT INTO `mny_address` VALUES ('1731', '天桥区', '1', '0', '172', '3');
INSERT INTO `mny_address` VALUES ('1732', '历城区', '1', '0', '172', '3');
INSERT INTO `mny_address` VALUES ('1733', '长清区', '1', '0', '172', '3');
INSERT INTO `mny_address` VALUES ('1734', '平阴县', '1', '0', '172', '3');
INSERT INTO `mny_address` VALUES ('1735', '济阳县', '1', '0', '172', '3');
INSERT INTO `mny_address` VALUES ('1736', '商河县', '1', '0', '172', '3');
INSERT INTO `mny_address` VALUES ('1737', '章丘市', '1', '0', '172', '3');
INSERT INTO `mny_address` VALUES ('1738', '市辖区', '1', '0', '173', '3');
INSERT INTO `mny_address` VALUES ('1739', '市南区', '1', '0', '173', '3');
INSERT INTO `mny_address` VALUES ('1740', '市北区', '1', '0', '173', '3');
INSERT INTO `mny_address` VALUES ('1741', '四方区', '1', '0', '173', '3');
INSERT INTO `mny_address` VALUES ('1742', '黄岛区', '1', '0', '173', '3');
INSERT INTO `mny_address` VALUES ('1743', '崂山区', '1', '0', '173', '3');
INSERT INTO `mny_address` VALUES ('1744', '李沧区', '1', '0', '173', '3');
INSERT INTO `mny_address` VALUES ('1745', '城阳区', '1', '0', '173', '3');
INSERT INTO `mny_address` VALUES ('1746', '胶州市', '1', '0', '173', '3');
INSERT INTO `mny_address` VALUES ('1747', '即墨市', '1', '0', '173', '3');
INSERT INTO `mny_address` VALUES ('1748', '平度市', '1', '0', '173', '3');
INSERT INTO `mny_address` VALUES ('1749', '胶南市', '1', '0', '173', '3');
INSERT INTO `mny_address` VALUES ('1750', '莱西市', '1', '0', '173', '3');
INSERT INTO `mny_address` VALUES ('1751', '市辖区', '1', '0', '174', '3');
INSERT INTO `mny_address` VALUES ('1752', '淄川区', '1', '0', '174', '3');
INSERT INTO `mny_address` VALUES ('1753', '张店区', '1', '0', '174', '3');
INSERT INTO `mny_address` VALUES ('1754', '博山区', '1', '0', '174', '3');
INSERT INTO `mny_address` VALUES ('1755', '临淄区', '1', '0', '174', '3');
INSERT INTO `mny_address` VALUES ('1756', '周村区', '1', '0', '174', '3');
INSERT INTO `mny_address` VALUES ('1757', '桓台县', '1', '0', '174', '3');
INSERT INTO `mny_address` VALUES ('1758', '高青县', '1', '0', '174', '3');
INSERT INTO `mny_address` VALUES ('1759', '沂源县', '1', '0', '174', '3');
INSERT INTO `mny_address` VALUES ('1760', '市辖区', '1', '0', '175', '3');
INSERT INTO `mny_address` VALUES ('1761', '市中区', '1', '0', '175', '3');
INSERT INTO `mny_address` VALUES ('1762', '薛城区', '1', '0', '175', '3');
INSERT INTO `mny_address` VALUES ('1763', '峄城区', '1', '0', '175', '3');
INSERT INTO `mny_address` VALUES ('1764', '台儿庄区', '1', '0', '175', '3');
INSERT INTO `mny_address` VALUES ('1765', '山亭区', '1', '0', '175', '3');
INSERT INTO `mny_address` VALUES ('1766', '滕州市', '1', '0', '175', '3');
INSERT INTO `mny_address` VALUES ('1767', '市辖区', '1', '0', '176', '3');
INSERT INTO `mny_address` VALUES ('1768', '东营区', '1', '0', '176', '3');
INSERT INTO `mny_address` VALUES ('1769', '河口区', '1', '0', '176', '3');
INSERT INTO `mny_address` VALUES ('1770', '垦利县', '1', '0', '176', '3');
INSERT INTO `mny_address` VALUES ('1771', '利津县', '1', '0', '176', '3');
INSERT INTO `mny_address` VALUES ('1772', '广饶县', '1', '0', '176', '3');
INSERT INTO `mny_address` VALUES ('1773', '市辖区', '1', '0', '177', '3');
INSERT INTO `mny_address` VALUES ('1774', '芝罘区', '1', '0', '177', '3');
INSERT INTO `mny_address` VALUES ('1775', '福山区', '1', '0', '177', '3');
INSERT INTO `mny_address` VALUES ('1776', '牟平区', '1', '0', '177', '3');
INSERT INTO `mny_address` VALUES ('1777', '莱山区', '1', '0', '177', '3');
INSERT INTO `mny_address` VALUES ('1778', '长岛县', '1', '0', '177', '3');
INSERT INTO `mny_address` VALUES ('1779', '龙口市', '1', '0', '177', '3');
INSERT INTO `mny_address` VALUES ('1780', '莱阳市', '1', '0', '177', '3');
INSERT INTO `mny_address` VALUES ('1781', '莱州市', '1', '0', '177', '3');
INSERT INTO `mny_address` VALUES ('1782', '蓬莱市', '1', '0', '177', '3');
INSERT INTO `mny_address` VALUES ('1783', '招远市', '1', '0', '177', '3');
INSERT INTO `mny_address` VALUES ('1784', '栖霞市', '1', '0', '177', '3');
INSERT INTO `mny_address` VALUES ('1785', '海阳市', '1', '0', '177', '3');
INSERT INTO `mny_address` VALUES ('1786', '市辖区', '1', '0', '178', '3');
INSERT INTO `mny_address` VALUES ('1787', '潍城区', '1', '0', '178', '3');
INSERT INTO `mny_address` VALUES ('1788', '寒亭区', '1', '0', '178', '3');
INSERT INTO `mny_address` VALUES ('1789', '坊子区', '1', '0', '178', '3');
INSERT INTO `mny_address` VALUES ('1790', '奎文区', '1', '0', '178', '3');
INSERT INTO `mny_address` VALUES ('1791', '临朐县', '1', '0', '178', '3');
INSERT INTO `mny_address` VALUES ('1792', '昌乐县', '1', '0', '178', '3');
INSERT INTO `mny_address` VALUES ('1793', '青州市', '1', '0', '178', '3');
INSERT INTO `mny_address` VALUES ('1794', '诸城市', '1', '0', '178', '3');
INSERT INTO `mny_address` VALUES ('1795', '寿光市', '1', '0', '178', '3');
INSERT INTO `mny_address` VALUES ('1796', '安丘市', '1', '0', '178', '3');
INSERT INTO `mny_address` VALUES ('1797', '高密市', '1', '0', '178', '3');
INSERT INTO `mny_address` VALUES ('1798', '昌邑市', '1', '0', '178', '3');
INSERT INTO `mny_address` VALUES ('1799', '市辖区', '1', '0', '179', '3');
INSERT INTO `mny_address` VALUES ('1800', '市中区', '1', '0', '179', '3');
INSERT INTO `mny_address` VALUES ('1801', '任城区', '1', '0', '179', '3');
INSERT INTO `mny_address` VALUES ('1802', '微山县', '1', '0', '179', '3');
INSERT INTO `mny_address` VALUES ('1803', '鱼台县', '1', '0', '179', '3');
INSERT INTO `mny_address` VALUES ('1804', '金乡县', '1', '0', '179', '3');
INSERT INTO `mny_address` VALUES ('1805', '嘉祥县', '1', '0', '179', '3');
INSERT INTO `mny_address` VALUES ('1806', '汶上县', '1', '0', '179', '3');
INSERT INTO `mny_address` VALUES ('1807', '泗水县', '1', '0', '179', '3');
INSERT INTO `mny_address` VALUES ('1808', '梁山县', '1', '0', '179', '3');
INSERT INTO `mny_address` VALUES ('1809', '曲阜市', '1', '0', '179', '3');
INSERT INTO `mny_address` VALUES ('1810', '兖州市', '1', '0', '179', '3');
INSERT INTO `mny_address` VALUES ('1811', '邹城市', '1', '0', '179', '3');
INSERT INTO `mny_address` VALUES ('1812', '市辖区', '1', '0', '180', '3');
INSERT INTO `mny_address` VALUES ('1813', '泰山区', '1', '0', '180', '3');
INSERT INTO `mny_address` VALUES ('1814', '岱岳区', '1', '0', '180', '3');
INSERT INTO `mny_address` VALUES ('1815', '宁阳县', '1', '0', '180', '3');
INSERT INTO `mny_address` VALUES ('1816', '东平县', '1', '0', '180', '3');
INSERT INTO `mny_address` VALUES ('1817', '新泰市', '1', '0', '180', '3');
INSERT INTO `mny_address` VALUES ('1818', '肥城市', '1', '0', '180', '3');
INSERT INTO `mny_address` VALUES ('1819', '市辖区', '1', '0', '181', '3');
INSERT INTO `mny_address` VALUES ('1820', '环翠区', '1', '0', '181', '3');
INSERT INTO `mny_address` VALUES ('1821', '文登市', '1', '0', '181', '3');
INSERT INTO `mny_address` VALUES ('1822', '荣成市', '1', '0', '181', '3');
INSERT INTO `mny_address` VALUES ('1823', '乳山市', '1', '0', '181', '3');
INSERT INTO `mny_address` VALUES ('1824', '市辖区', '1', '0', '182', '3');
INSERT INTO `mny_address` VALUES ('1825', '东港区', '1', '0', '182', '3');
INSERT INTO `mny_address` VALUES ('1826', '岚山区', '1', '0', '182', '3');
INSERT INTO `mny_address` VALUES ('1827', '五莲县', '1', '0', '182', '3');
INSERT INTO `mny_address` VALUES ('1828', '莒　县', '1', '0', '182', '3');
INSERT INTO `mny_address` VALUES ('1829', '市辖区', '1', '0', '183', '3');
INSERT INTO `mny_address` VALUES ('1830', '莱城区', '1', '0', '183', '3');
INSERT INTO `mny_address` VALUES ('1831', '钢城区', '1', '0', '183', '3');
INSERT INTO `mny_address` VALUES ('1832', '市辖区', '1', '0', '184', '3');
INSERT INTO `mny_address` VALUES ('1833', '兰山区', '1', '0', '184', '3');
INSERT INTO `mny_address` VALUES ('1834', '罗庄区', '1', '0', '184', '3');
INSERT INTO `mny_address` VALUES ('1835', '河东区', '1', '0', '184', '3');
INSERT INTO `mny_address` VALUES ('1836', '沂南县', '1', '0', '184', '3');
INSERT INTO `mny_address` VALUES ('1837', '郯城县', '1', '0', '184', '3');
INSERT INTO `mny_address` VALUES ('1838', '沂水县', '1', '0', '184', '3');
INSERT INTO `mny_address` VALUES ('1839', '苍山县', '1', '0', '184', '3');
INSERT INTO `mny_address` VALUES ('1840', '费　县', '1', '0', '184', '3');
INSERT INTO `mny_address` VALUES ('1841', '平邑县', '1', '0', '184', '3');
INSERT INTO `mny_address` VALUES ('1842', '莒南县', '1', '0', '184', '3');
INSERT INTO `mny_address` VALUES ('1843', '蒙阴县', '1', '0', '184', '3');
INSERT INTO `mny_address` VALUES ('1844', '临沭县', '1', '0', '184', '3');
INSERT INTO `mny_address` VALUES ('1845', '市辖区', '1', '0', '185', '3');
INSERT INTO `mny_address` VALUES ('1846', '德城区', '1', '0', '185', '3');
INSERT INTO `mny_address` VALUES ('1847', '陵　县', '1', '0', '185', '3');
INSERT INTO `mny_address` VALUES ('1848', '宁津县', '1', '0', '185', '3');
INSERT INTO `mny_address` VALUES ('1849', '庆云县', '1', '0', '185', '3');
INSERT INTO `mny_address` VALUES ('1850', '临邑县', '1', '0', '185', '3');
INSERT INTO `mny_address` VALUES ('1851', '齐河县', '1', '0', '185', '3');
INSERT INTO `mny_address` VALUES ('1852', '平原县', '1', '0', '185', '3');
INSERT INTO `mny_address` VALUES ('1853', '夏津县', '1', '0', '185', '3');
INSERT INTO `mny_address` VALUES ('1854', '武城县', '1', '0', '185', '3');
INSERT INTO `mny_address` VALUES ('1855', '乐陵市', '1', '0', '185', '3');
INSERT INTO `mny_address` VALUES ('1856', '禹城市', '1', '0', '185', '3');
INSERT INTO `mny_address` VALUES ('1857', '市辖区', '1', '0', '186', '3');
INSERT INTO `mny_address` VALUES ('1858', '东昌府区', '1', '0', '186', '3');
INSERT INTO `mny_address` VALUES ('1859', '阳谷县', '1', '0', '186', '3');
INSERT INTO `mny_address` VALUES ('1860', '莘　县', '1', '0', '186', '3');
INSERT INTO `mny_address` VALUES ('1861', '茌平县', '1', '0', '186', '3');
INSERT INTO `mny_address` VALUES ('1862', '东阿县', '1', '0', '186', '3');
INSERT INTO `mny_address` VALUES ('1863', '冠　县', '1', '0', '186', '3');
INSERT INTO `mny_address` VALUES ('1864', '高唐县', '1', '0', '186', '3');
INSERT INTO `mny_address` VALUES ('1865', '临清市', '1', '0', '186', '3');
INSERT INTO `mny_address` VALUES ('1866', '市辖区', '1', '0', '187', '3');
INSERT INTO `mny_address` VALUES ('1867', '滨城区', '1', '0', '187', '3');
INSERT INTO `mny_address` VALUES ('1868', '惠民县', '1', '0', '187', '3');
INSERT INTO `mny_address` VALUES ('1869', '阳信县', '1', '0', '187', '3');
INSERT INTO `mny_address` VALUES ('1870', '无棣县', '1', '0', '187', '3');
INSERT INTO `mny_address` VALUES ('1871', '沾化县', '1', '0', '187', '3');
INSERT INTO `mny_address` VALUES ('1872', '博兴县', '1', '0', '187', '3');
INSERT INTO `mny_address` VALUES ('1873', '邹平县', '1', '0', '187', '3');
INSERT INTO `mny_address` VALUES ('1874', '市辖区', '1', '0', '188', '3');
INSERT INTO `mny_address` VALUES ('1875', '牡丹区', '1', '0', '188', '3');
INSERT INTO `mny_address` VALUES ('1876', '曹　县', '1', '0', '188', '3');
INSERT INTO `mny_address` VALUES ('1877', '单　县', '1', '0', '188', '3');
INSERT INTO `mny_address` VALUES ('1878', '成武县', '1', '0', '188', '3');
INSERT INTO `mny_address` VALUES ('1879', '巨野县', '1', '0', '188', '3');
INSERT INTO `mny_address` VALUES ('1880', '郓城县', '1', '0', '188', '3');
INSERT INTO `mny_address` VALUES ('1881', '鄄城县', '1', '0', '188', '3');
INSERT INTO `mny_address` VALUES ('1882', '定陶县', '1', '0', '188', '3');
INSERT INTO `mny_address` VALUES ('1883', '东明县', '1', '0', '188', '3');
INSERT INTO `mny_address` VALUES ('1884', '市辖区', '1', '0', '189', '3');
INSERT INTO `mny_address` VALUES ('1885', '中原区', '1', '0', '189', '3');
INSERT INTO `mny_address` VALUES ('1886', '二七区', '1', '0', '189', '3');
INSERT INTO `mny_address` VALUES ('1887', '管城回族区', '1', '0', '189', '3');
INSERT INTO `mny_address` VALUES ('1888', '金水区', '1', '0', '189', '3');
INSERT INTO `mny_address` VALUES ('1889', '上街区', '1', '0', '189', '3');
INSERT INTO `mny_address` VALUES ('1890', '邙山区', '1', '0', '189', '3');
INSERT INTO `mny_address` VALUES ('1891', '中牟县', '1', '0', '189', '3');
INSERT INTO `mny_address` VALUES ('1892', '巩义市', '1', '0', '189', '3');
INSERT INTO `mny_address` VALUES ('1893', '荥阳市', '1', '0', '189', '3');
INSERT INTO `mny_address` VALUES ('1894', '新密市', '1', '0', '189', '3');
INSERT INTO `mny_address` VALUES ('1895', '新郑市', '1', '0', '189', '3');
INSERT INTO `mny_address` VALUES ('1896', '登封市', '1', '0', '189', '3');
INSERT INTO `mny_address` VALUES ('1897', '市辖区', '1', '0', '190', '3');
INSERT INTO `mny_address` VALUES ('1898', '龙亭区', '1', '0', '190', '3');
INSERT INTO `mny_address` VALUES ('1899', '顺河回族区', '1', '0', '190', '3');
INSERT INTO `mny_address` VALUES ('1900', '鼓楼区', '1', '0', '190', '3');
INSERT INTO `mny_address` VALUES ('1901', '南关区', '1', '0', '190', '3');
INSERT INTO `mny_address` VALUES ('1902', '郊　区', '1', '0', '190', '3');
INSERT INTO `mny_address` VALUES ('1903', '杞　县', '1', '0', '190', '3');
INSERT INTO `mny_address` VALUES ('1904', '通许县', '1', '0', '190', '3');
INSERT INTO `mny_address` VALUES ('1905', '尉氏县', '1', '0', '190', '3');
INSERT INTO `mny_address` VALUES ('1906', '开封县', '1', '0', '190', '3');
INSERT INTO `mny_address` VALUES ('1907', '兰考县', '1', '0', '190', '3');
INSERT INTO `mny_address` VALUES ('1908', '市辖区', '1', '0', '191', '3');
INSERT INTO `mny_address` VALUES ('1909', '老城区', '1', '0', '191', '3');
INSERT INTO `mny_address` VALUES ('1910', '西工区', '1', '0', '191', '3');
INSERT INTO `mny_address` VALUES ('1911', '廛河回族区', '1', '0', '191', '3');
INSERT INTO `mny_address` VALUES ('1912', '涧西区', '1', '0', '191', '3');
INSERT INTO `mny_address` VALUES ('1913', '吉利区', '1', '0', '191', '3');
INSERT INTO `mny_address` VALUES ('1914', '洛龙区', '1', '0', '191', '3');
INSERT INTO `mny_address` VALUES ('1915', '孟津县', '1', '0', '191', '3');
INSERT INTO `mny_address` VALUES ('1916', '新安县', '1', '0', '191', '3');
INSERT INTO `mny_address` VALUES ('1917', '栾川县', '1', '0', '191', '3');
INSERT INTO `mny_address` VALUES ('1918', '嵩　县', '1', '0', '191', '3');
INSERT INTO `mny_address` VALUES ('1919', '汝阳县', '1', '0', '191', '3');
INSERT INTO `mny_address` VALUES ('1920', '宜阳县', '1', '0', '191', '3');
INSERT INTO `mny_address` VALUES ('1921', '洛宁县', '1', '0', '191', '3');
INSERT INTO `mny_address` VALUES ('1922', '伊川县', '1', '0', '191', '3');
INSERT INTO `mny_address` VALUES ('1923', '偃师市', '1', '0', '191', '3');
INSERT INTO `mny_address` VALUES ('1924', '市辖区', '1', '0', '192', '3');
INSERT INTO `mny_address` VALUES ('1925', '新华区', '1', '0', '192', '3');
INSERT INTO `mny_address` VALUES ('1926', '卫东区', '1', '0', '192', '3');
INSERT INTO `mny_address` VALUES ('1927', '石龙区', '1', '0', '192', '3');
INSERT INTO `mny_address` VALUES ('1928', '湛河区', '1', '0', '192', '3');
INSERT INTO `mny_address` VALUES ('1929', '宝丰县', '1', '0', '192', '3');
INSERT INTO `mny_address` VALUES ('1930', '叶　县', '1', '0', '192', '3');
INSERT INTO `mny_address` VALUES ('1931', '鲁山县', '1', '0', '192', '3');
INSERT INTO `mny_address` VALUES ('1932', '郏　县', '1', '0', '192', '3');
INSERT INTO `mny_address` VALUES ('1933', '舞钢市', '1', '0', '192', '3');
INSERT INTO `mny_address` VALUES ('1934', '汝州市', '1', '0', '192', '3');
INSERT INTO `mny_address` VALUES ('1935', '市辖区', '1', '0', '193', '3');
INSERT INTO `mny_address` VALUES ('1936', '文峰区', '1', '0', '193', '3');
INSERT INTO `mny_address` VALUES ('1937', '北关区', '1', '0', '193', '3');
INSERT INTO `mny_address` VALUES ('1938', '殷都区', '1', '0', '193', '3');
INSERT INTO `mny_address` VALUES ('1939', '龙安区', '1', '0', '193', '3');
INSERT INTO `mny_address` VALUES ('1940', '安阳县', '1', '0', '193', '3');
INSERT INTO `mny_address` VALUES ('1941', '汤阴县', '1', '0', '193', '3');
INSERT INTO `mny_address` VALUES ('1942', '滑　县', '1', '0', '193', '3');
INSERT INTO `mny_address` VALUES ('1943', '内黄县', '1', '0', '193', '3');
INSERT INTO `mny_address` VALUES ('1944', '林州市', '1', '0', '193', '3');
INSERT INTO `mny_address` VALUES ('1945', '市辖区', '1', '0', '194', '3');
INSERT INTO `mny_address` VALUES ('1946', '鹤山区', '1', '0', '194', '3');
INSERT INTO `mny_address` VALUES ('1947', '山城区', '1', '0', '194', '3');
INSERT INTO `mny_address` VALUES ('1948', '淇滨区', '1', '0', '194', '3');
INSERT INTO `mny_address` VALUES ('1949', '浚　县', '1', '0', '194', '3');
INSERT INTO `mny_address` VALUES ('1950', '淇　县', '1', '0', '194', '3');
INSERT INTO `mny_address` VALUES ('1951', '市辖区', '1', '0', '195', '3');
INSERT INTO `mny_address` VALUES ('1952', '红旗区', '1', '0', '195', '3');
INSERT INTO `mny_address` VALUES ('1953', '卫滨区', '1', '0', '195', '3');
INSERT INTO `mny_address` VALUES ('1954', '凤泉区', '1', '0', '195', '3');
INSERT INTO `mny_address` VALUES ('1955', '牧野区', '1', '0', '195', '3');
INSERT INTO `mny_address` VALUES ('1956', '新乡县', '1', '0', '195', '3');
INSERT INTO `mny_address` VALUES ('1957', '获嘉县', '1', '0', '195', '3');
INSERT INTO `mny_address` VALUES ('1958', '原阳县', '1', '0', '195', '3');
INSERT INTO `mny_address` VALUES ('1959', '延津县', '1', '0', '195', '3');
INSERT INTO `mny_address` VALUES ('1960', '封丘县', '1', '0', '195', '3');
INSERT INTO `mny_address` VALUES ('1961', '长垣县', '1', '0', '195', '3');
INSERT INTO `mny_address` VALUES ('1962', '卫辉市', '1', '0', '195', '3');
INSERT INTO `mny_address` VALUES ('1963', '辉县市', '1', '0', '195', '3');
INSERT INTO `mny_address` VALUES ('1964', '市辖区', '1', '0', '196', '3');
INSERT INTO `mny_address` VALUES ('1965', '解放区', '1', '0', '196', '3');
INSERT INTO `mny_address` VALUES ('1966', '中站区', '1', '0', '196', '3');
INSERT INTO `mny_address` VALUES ('1967', '马村区', '1', '0', '196', '3');
INSERT INTO `mny_address` VALUES ('1968', '山阳区', '1', '0', '196', '3');
INSERT INTO `mny_address` VALUES ('1969', '修武县', '1', '0', '196', '3');
INSERT INTO `mny_address` VALUES ('1970', '博爱县', '1', '0', '196', '3');
INSERT INTO `mny_address` VALUES ('1971', '武陟县', '1', '0', '196', '3');
INSERT INTO `mny_address` VALUES ('1972', '温　县', '1', '0', '196', '3');
INSERT INTO `mny_address` VALUES ('1973', '济源市', '1', '0', '196', '3');
INSERT INTO `mny_address` VALUES ('1974', '沁阳市', '1', '0', '196', '3');
INSERT INTO `mny_address` VALUES ('1975', '孟州市', '1', '0', '196', '3');
INSERT INTO `mny_address` VALUES ('1976', '市辖区', '1', '0', '197', '3');
INSERT INTO `mny_address` VALUES ('1977', '华龙区', '1', '0', '197', '3');
INSERT INTO `mny_address` VALUES ('1978', '清丰县', '1', '0', '197', '3');
INSERT INTO `mny_address` VALUES ('1979', '南乐县', '1', '0', '197', '3');
INSERT INTO `mny_address` VALUES ('1980', '范　县', '1', '0', '197', '3');
INSERT INTO `mny_address` VALUES ('1981', '台前县', '1', '0', '197', '3');
INSERT INTO `mny_address` VALUES ('1982', '濮阳县', '1', '0', '197', '3');
INSERT INTO `mny_address` VALUES ('1983', '市辖区', '1', '0', '198', '3');
INSERT INTO `mny_address` VALUES ('1984', '魏都区', '1', '0', '198', '3');
INSERT INTO `mny_address` VALUES ('1985', '许昌县', '1', '0', '198', '3');
INSERT INTO `mny_address` VALUES ('1986', '鄢陵县', '1', '0', '198', '3');
INSERT INTO `mny_address` VALUES ('1987', '襄城县', '1', '0', '198', '3');
INSERT INTO `mny_address` VALUES ('1988', '禹州市', '1', '0', '198', '3');
INSERT INTO `mny_address` VALUES ('1989', '长葛市', '1', '0', '198', '3');
INSERT INTO `mny_address` VALUES ('1990', '市辖区', '1', '0', '199', '3');
INSERT INTO `mny_address` VALUES ('1991', '源汇区', '1', '0', '199', '3');
INSERT INTO `mny_address` VALUES ('1992', '郾城区', '1', '0', '199', '3');
INSERT INTO `mny_address` VALUES ('1993', '召陵区', '1', '0', '199', '3');
INSERT INTO `mny_address` VALUES ('1994', '舞阳县', '1', '0', '199', '3');
INSERT INTO `mny_address` VALUES ('1995', '临颍县', '1', '0', '199', '3');
INSERT INTO `mny_address` VALUES ('1996', '市辖区', '1', '0', '200', '3');
INSERT INTO `mny_address` VALUES ('1997', '湖滨区', '1', '0', '200', '3');
INSERT INTO `mny_address` VALUES ('1998', '渑池县', '1', '0', '200', '3');
INSERT INTO `mny_address` VALUES ('1999', '陕　县', '1', '0', '200', '3');
INSERT INTO `mny_address` VALUES ('2000', '卢氏县', '1', '0', '200', '3');
INSERT INTO `mny_address` VALUES ('2001', '义马市', '1', '0', '200', '3');
INSERT INTO `mny_address` VALUES ('2002', '灵宝市', '1', '0', '200', '3');
INSERT INTO `mny_address` VALUES ('2003', '市辖区', '1', '0', '201', '3');
INSERT INTO `mny_address` VALUES ('2004', '宛城区', '1', '0', '201', '3');
INSERT INTO `mny_address` VALUES ('2005', '卧龙区', '1', '0', '201', '3');
INSERT INTO `mny_address` VALUES ('2006', '南召县', '1', '0', '201', '3');
INSERT INTO `mny_address` VALUES ('2007', '方城县', '1', '0', '201', '3');
INSERT INTO `mny_address` VALUES ('2008', '西峡县', '1', '0', '201', '3');
INSERT INTO `mny_address` VALUES ('2009', '镇平县', '1', '0', '201', '3');
INSERT INTO `mny_address` VALUES ('2010', '内乡县', '1', '0', '201', '3');
INSERT INTO `mny_address` VALUES ('2011', '淅川县', '1', '0', '201', '3');
INSERT INTO `mny_address` VALUES ('2012', '社旗县', '1', '0', '201', '3');
INSERT INTO `mny_address` VALUES ('2013', '唐河县', '1', '0', '201', '3');
INSERT INTO `mny_address` VALUES ('2014', '新野县', '1', '0', '201', '3');
INSERT INTO `mny_address` VALUES ('2015', '桐柏县', '1', '0', '201', '3');
INSERT INTO `mny_address` VALUES ('2016', '邓州市', '1', '0', '201', '3');
INSERT INTO `mny_address` VALUES ('2017', '市辖区', '1', '0', '202', '3');
INSERT INTO `mny_address` VALUES ('2018', '梁园区', '1', '0', '202', '3');
INSERT INTO `mny_address` VALUES ('2019', '睢阳区', '1', '0', '202', '3');
INSERT INTO `mny_address` VALUES ('2020', '民权县', '1', '0', '202', '3');
INSERT INTO `mny_address` VALUES ('2021', '睢　县', '1', '0', '202', '3');
INSERT INTO `mny_address` VALUES ('2022', '宁陵县', '1', '0', '202', '3');
INSERT INTO `mny_address` VALUES ('2023', '柘城县', '1', '0', '202', '3');
INSERT INTO `mny_address` VALUES ('2024', '虞城县', '1', '0', '202', '3');
INSERT INTO `mny_address` VALUES ('2025', '夏邑县', '1', '0', '202', '3');
INSERT INTO `mny_address` VALUES ('2026', '永城市', '1', '0', '202', '3');
INSERT INTO `mny_address` VALUES ('2027', '市辖区', '1', '0', '203', '3');
INSERT INTO `mny_address` VALUES ('2028', '师河区', '1', '0', '203', '3');
INSERT INTO `mny_address` VALUES ('2029', '平桥区', '1', '0', '203', '3');
INSERT INTO `mny_address` VALUES ('2030', '罗山县', '1', '0', '203', '3');
INSERT INTO `mny_address` VALUES ('2031', '光山县', '1', '0', '203', '3');
INSERT INTO `mny_address` VALUES ('2032', '新　县', '1', '0', '203', '3');
INSERT INTO `mny_address` VALUES ('2033', '商城县', '1', '0', '203', '3');
INSERT INTO `mny_address` VALUES ('2034', '固始县', '1', '0', '203', '3');
INSERT INTO `mny_address` VALUES ('2035', '潢川县', '1', '0', '203', '3');
INSERT INTO `mny_address` VALUES ('2036', '淮滨县', '1', '0', '203', '3');
INSERT INTO `mny_address` VALUES ('2037', '息　县', '1', '0', '203', '3');
INSERT INTO `mny_address` VALUES ('2038', '市辖区', '1', '0', '204', '3');
INSERT INTO `mny_address` VALUES ('2039', '川汇区', '1', '0', '204', '3');
INSERT INTO `mny_address` VALUES ('2040', '扶沟县', '1', '0', '204', '3');
INSERT INTO `mny_address` VALUES ('2041', '西华县', '1', '0', '204', '3');
INSERT INTO `mny_address` VALUES ('2042', '商水县', '1', '0', '204', '3');
INSERT INTO `mny_address` VALUES ('2043', '沈丘县', '1', '0', '204', '3');
INSERT INTO `mny_address` VALUES ('2044', '郸城县', '1', '0', '204', '3');
INSERT INTO `mny_address` VALUES ('2045', '淮阳县', '1', '0', '204', '3');
INSERT INTO `mny_address` VALUES ('2046', '太康县', '1', '0', '204', '3');
INSERT INTO `mny_address` VALUES ('2047', '鹿邑县', '1', '0', '204', '3');
INSERT INTO `mny_address` VALUES ('2048', '项城市', '1', '0', '204', '3');
INSERT INTO `mny_address` VALUES ('2049', '市辖区', '1', '0', '205', '3');
INSERT INTO `mny_address` VALUES ('2050', '驿城区', '1', '0', '205', '3');
INSERT INTO `mny_address` VALUES ('2051', '西平县', '1', '0', '205', '3');
INSERT INTO `mny_address` VALUES ('2052', '上蔡县', '1', '0', '205', '3');
INSERT INTO `mny_address` VALUES ('2053', '平舆县', '1', '0', '205', '3');
INSERT INTO `mny_address` VALUES ('2054', '正阳县', '1', '0', '205', '3');
INSERT INTO `mny_address` VALUES ('2055', '确山县', '1', '0', '205', '3');
INSERT INTO `mny_address` VALUES ('2056', '泌阳县', '1', '0', '205', '3');
INSERT INTO `mny_address` VALUES ('2057', '汝南县', '1', '0', '205', '3');
INSERT INTO `mny_address` VALUES ('2058', '遂平县', '1', '0', '205', '3');
INSERT INTO `mny_address` VALUES ('2059', '新蔡县', '1', '0', '205', '3');
INSERT INTO `mny_address` VALUES ('2060', '市辖区', '1', '0', '206', '3');
INSERT INTO `mny_address` VALUES ('2061', '江岸区', '1', '0', '206', '3');
INSERT INTO `mny_address` VALUES ('2062', '江汉区', '1', '0', '206', '3');
INSERT INTO `mny_address` VALUES ('2063', '乔口区', '1', '0', '206', '3');
INSERT INTO `mny_address` VALUES ('2064', '汉阳区', '1', '0', '206', '3');
INSERT INTO `mny_address` VALUES ('2065', '武昌区', '1', '0', '206', '3');
INSERT INTO `mny_address` VALUES ('2066', '青山区', '1', '0', '206', '3');
INSERT INTO `mny_address` VALUES ('2067', '洪山区', '1', '0', '206', '3');
INSERT INTO `mny_address` VALUES ('2068', '东西湖区', '1', '0', '206', '3');
INSERT INTO `mny_address` VALUES ('2069', '汉南区', '1', '0', '206', '3');
INSERT INTO `mny_address` VALUES ('2070', '蔡甸区', '1', '0', '206', '3');
INSERT INTO `mny_address` VALUES ('2071', '江夏区', '1', '0', '206', '3');
INSERT INTO `mny_address` VALUES ('2072', '黄陂区', '1', '0', '206', '3');
INSERT INTO `mny_address` VALUES ('2073', '新洲区', '1', '0', '206', '3');
INSERT INTO `mny_address` VALUES ('2074', '市辖区', '1', '0', '207', '3');
INSERT INTO `mny_address` VALUES ('2075', '黄石港区', '1', '0', '207', '3');
INSERT INTO `mny_address` VALUES ('2076', '西塞山区', '1', '0', '207', '3');
INSERT INTO `mny_address` VALUES ('2077', '下陆区', '1', '0', '207', '3');
INSERT INTO `mny_address` VALUES ('2078', '铁山区', '1', '0', '207', '3');
INSERT INTO `mny_address` VALUES ('2079', '阳新县', '1', '0', '207', '3');
INSERT INTO `mny_address` VALUES ('2080', '大冶市', '1', '0', '207', '3');
INSERT INTO `mny_address` VALUES ('2081', '市辖区', '1', '0', '208', '3');
INSERT INTO `mny_address` VALUES ('2082', '茅箭区', '1', '0', '208', '3');
INSERT INTO `mny_address` VALUES ('2083', '张湾区', '1', '0', '208', '3');
INSERT INTO `mny_address` VALUES ('2084', '郧　县', '1', '0', '208', '3');
INSERT INTO `mny_address` VALUES ('2085', '郧西县', '1', '0', '208', '3');
INSERT INTO `mny_address` VALUES ('2086', '竹山县', '1', '0', '208', '3');
INSERT INTO `mny_address` VALUES ('2087', '竹溪县', '1', '0', '208', '3');
INSERT INTO `mny_address` VALUES ('2088', '房　县', '1', '0', '208', '3');
INSERT INTO `mny_address` VALUES ('2089', '丹江口市', '1', '0', '208', '3');
INSERT INTO `mny_address` VALUES ('2090', '市辖区', '1', '0', '209', '3');
INSERT INTO `mny_address` VALUES ('2091', '西陵区', '1', '0', '209', '3');
INSERT INTO `mny_address` VALUES ('2092', '伍家岗区', '1', '0', '209', '3');
INSERT INTO `mny_address` VALUES ('2093', '点军区', '1', '0', '209', '3');
INSERT INTO `mny_address` VALUES ('2094', '猇亭区', '1', '0', '209', '3');
INSERT INTO `mny_address` VALUES ('2095', '夷陵区', '1', '0', '209', '3');
INSERT INTO `mny_address` VALUES ('2096', '远安县', '1', '0', '209', '3');
INSERT INTO `mny_address` VALUES ('2097', '兴山县', '1', '0', '209', '3');
INSERT INTO `mny_address` VALUES ('2098', '秭归县', '1', '0', '209', '3');
INSERT INTO `mny_address` VALUES ('2099', '长阳土家族自治县', '1', '0', '209', '3');
INSERT INTO `mny_address` VALUES ('2100', '五峰土家族自治县', '1', '0', '209', '3');
INSERT INTO `mny_address` VALUES ('2101', '宜都市', '1', '0', '209', '3');
INSERT INTO `mny_address` VALUES ('2102', '当阳市', '1', '0', '209', '3');
INSERT INTO `mny_address` VALUES ('2103', '枝江市', '1', '0', '209', '3');
INSERT INTO `mny_address` VALUES ('2104', '市辖区', '1', '0', '210', '3');
INSERT INTO `mny_address` VALUES ('2105', '襄城区', '1', '0', '210', '3');
INSERT INTO `mny_address` VALUES ('2106', '樊城区', '1', '0', '210', '3');
INSERT INTO `mny_address` VALUES ('2107', '襄阳区', '1', '0', '210', '3');
INSERT INTO `mny_address` VALUES ('2108', '南漳县', '1', '0', '210', '3');
INSERT INTO `mny_address` VALUES ('2109', '谷城县', '1', '0', '210', '3');
INSERT INTO `mny_address` VALUES ('2110', '保康县', '1', '0', '210', '3');
INSERT INTO `mny_address` VALUES ('2111', '老河口市', '1', '0', '210', '3');
INSERT INTO `mny_address` VALUES ('2112', '枣阳市', '1', '0', '210', '3');
INSERT INTO `mny_address` VALUES ('2113', '宜城市', '1', '0', '210', '3');
INSERT INTO `mny_address` VALUES ('2114', '市辖区', '1', '0', '211', '3');
INSERT INTO `mny_address` VALUES ('2115', '梁子湖区', '1', '0', '211', '3');
INSERT INTO `mny_address` VALUES ('2116', '华容区', '1', '0', '211', '3');
INSERT INTO `mny_address` VALUES ('2117', '鄂城区', '1', '0', '211', '3');
INSERT INTO `mny_address` VALUES ('2118', '市辖区', '1', '0', '212', '3');
INSERT INTO `mny_address` VALUES ('2119', '东宝区', '1', '0', '212', '3');
INSERT INTO `mny_address` VALUES ('2120', '掇刀区', '1', '0', '212', '3');
INSERT INTO `mny_address` VALUES ('2121', '京山县', '1', '0', '212', '3');
INSERT INTO `mny_address` VALUES ('2122', '沙洋县', '1', '0', '212', '3');
INSERT INTO `mny_address` VALUES ('2123', '钟祥市', '1', '0', '212', '3');
INSERT INTO `mny_address` VALUES ('2124', '市辖区', '1', '0', '213', '3');
INSERT INTO `mny_address` VALUES ('2125', '孝南区', '1', '0', '213', '3');
INSERT INTO `mny_address` VALUES ('2126', '孝昌县', '1', '0', '213', '3');
INSERT INTO `mny_address` VALUES ('2127', '大悟县', '1', '0', '213', '3');
INSERT INTO `mny_address` VALUES ('2128', '云梦县', '1', '0', '213', '3');
INSERT INTO `mny_address` VALUES ('2129', '应城市', '1', '0', '213', '3');
INSERT INTO `mny_address` VALUES ('2130', '安陆市', '1', '0', '213', '3');
INSERT INTO `mny_address` VALUES ('2131', '汉川市', '1', '0', '213', '3');
INSERT INTO `mny_address` VALUES ('2132', '市辖区', '1', '0', '214', '3');
INSERT INTO `mny_address` VALUES ('2133', '沙市区', '1', '0', '214', '3');
INSERT INTO `mny_address` VALUES ('2134', '荆州区', '1', '0', '214', '3');
INSERT INTO `mny_address` VALUES ('2135', '公安县', '1', '0', '214', '3');
INSERT INTO `mny_address` VALUES ('2136', '监利县', '1', '0', '214', '3');
INSERT INTO `mny_address` VALUES ('2137', '江陵县', '1', '0', '214', '3');
INSERT INTO `mny_address` VALUES ('2138', '石首市', '1', '0', '214', '3');
INSERT INTO `mny_address` VALUES ('2139', '洪湖市', '1', '0', '214', '3');
INSERT INTO `mny_address` VALUES ('2140', '松滋市', '1', '0', '214', '3');
INSERT INTO `mny_address` VALUES ('2141', '市辖区', '1', '0', '215', '3');
INSERT INTO `mny_address` VALUES ('2142', '黄州区', '1', '0', '215', '3');
INSERT INTO `mny_address` VALUES ('2143', '团风县', '1', '0', '215', '3');
INSERT INTO `mny_address` VALUES ('2144', '红安县', '1', '0', '215', '3');
INSERT INTO `mny_address` VALUES ('2145', '罗田县', '1', '0', '215', '3');
INSERT INTO `mny_address` VALUES ('2146', '英山县', '1', '0', '215', '3');
INSERT INTO `mny_address` VALUES ('2147', '浠水县', '1', '0', '215', '3');
INSERT INTO `mny_address` VALUES ('2148', '蕲春县', '1', '0', '215', '3');
INSERT INTO `mny_address` VALUES ('2149', '黄梅县', '1', '0', '215', '3');
INSERT INTO `mny_address` VALUES ('2150', '麻城市', '1', '0', '215', '3');
INSERT INTO `mny_address` VALUES ('2151', '武穴市', '1', '0', '215', '3');
INSERT INTO `mny_address` VALUES ('2152', '市辖区', '1', '0', '216', '3');
INSERT INTO `mny_address` VALUES ('2153', '咸安区', '1', '0', '216', '3');
INSERT INTO `mny_address` VALUES ('2154', '嘉鱼县', '1', '0', '216', '3');
INSERT INTO `mny_address` VALUES ('2155', '通城县', '1', '0', '216', '3');
INSERT INTO `mny_address` VALUES ('2156', '崇阳县', '1', '0', '216', '3');
INSERT INTO `mny_address` VALUES ('2157', '通山县', '1', '0', '216', '3');
INSERT INTO `mny_address` VALUES ('2158', '赤壁市', '1', '0', '216', '3');
INSERT INTO `mny_address` VALUES ('2159', '市辖区', '1', '0', '217', '3');
INSERT INTO `mny_address` VALUES ('2160', '曾都区', '1', '0', '217', '3');
INSERT INTO `mny_address` VALUES ('2161', '广水市', '1', '0', '217', '3');
INSERT INTO `mny_address` VALUES ('2162', '恩施市', '1', '0', '218', '3');
INSERT INTO `mny_address` VALUES ('2163', '利川市', '1', '0', '218', '3');
INSERT INTO `mny_address` VALUES ('2164', '建始县', '1', '0', '218', '3');
INSERT INTO `mny_address` VALUES ('2165', '巴东县', '1', '0', '218', '3');
INSERT INTO `mny_address` VALUES ('2166', '宣恩县', '1', '0', '218', '3');
INSERT INTO `mny_address` VALUES ('2167', '咸丰县', '1', '0', '218', '3');
INSERT INTO `mny_address` VALUES ('2168', '来凤县', '1', '0', '218', '3');
INSERT INTO `mny_address` VALUES ('2169', '鹤峰县', '1', '0', '218', '3');
INSERT INTO `mny_address` VALUES ('2170', '仙桃市', '1', '0', '219', '3');
INSERT INTO `mny_address` VALUES ('2171', '潜江市', '1', '0', '219', '3');
INSERT INTO `mny_address` VALUES ('2172', '天门市', '1', '0', '219', '3');
INSERT INTO `mny_address` VALUES ('2173', '神农架林区', '1', '0', '219', '3');
INSERT INTO `mny_address` VALUES ('2174', '市辖区', '1', '0', '220', '3');
INSERT INTO `mny_address` VALUES ('2175', '芙蓉区', '1', '0', '220', '3');
INSERT INTO `mny_address` VALUES ('2176', '天心区', '1', '0', '220', '3');
INSERT INTO `mny_address` VALUES ('2177', '岳麓区', '1', '0', '220', '3');
INSERT INTO `mny_address` VALUES ('2178', '开福区', '1', '0', '220', '3');
INSERT INTO `mny_address` VALUES ('2179', '雨花区', '1', '0', '220', '3');
INSERT INTO `mny_address` VALUES ('2180', '长沙县', '1', '0', '220', '3');
INSERT INTO `mny_address` VALUES ('2181', '望城县', '1', '0', '220', '3');
INSERT INTO `mny_address` VALUES ('2182', '宁乡县', '1', '0', '220', '3');
INSERT INTO `mny_address` VALUES ('2183', '浏阳市', '1', '0', '220', '3');
INSERT INTO `mny_address` VALUES ('2184', '市辖区', '1', '0', '221', '3');
INSERT INTO `mny_address` VALUES ('2185', '荷塘区', '1', '0', '221', '3');
INSERT INTO `mny_address` VALUES ('2186', '芦淞区', '1', '0', '221', '3');
INSERT INTO `mny_address` VALUES ('2187', '石峰区', '1', '0', '221', '3');
INSERT INTO `mny_address` VALUES ('2188', '天元区', '1', '0', '221', '3');
INSERT INTO `mny_address` VALUES ('2189', '株洲县', '1', '0', '221', '3');
INSERT INTO `mny_address` VALUES ('2190', '攸　县', '1', '0', '221', '3');
INSERT INTO `mny_address` VALUES ('2191', '茶陵县', '1', '0', '221', '3');
INSERT INTO `mny_address` VALUES ('2192', '炎陵县', '1', '0', '221', '3');
INSERT INTO `mny_address` VALUES ('2193', '醴陵市', '1', '0', '221', '3');
INSERT INTO `mny_address` VALUES ('2194', '市辖区', '1', '0', '222', '3');
INSERT INTO `mny_address` VALUES ('2195', '雨湖区', '1', '0', '222', '3');
INSERT INTO `mny_address` VALUES ('2196', '岳塘区', '1', '0', '222', '3');
INSERT INTO `mny_address` VALUES ('2197', '湘潭县', '1', '0', '222', '3');
INSERT INTO `mny_address` VALUES ('2198', '湘乡市', '1', '0', '222', '3');
INSERT INTO `mny_address` VALUES ('2199', '韶山市', '1', '0', '222', '3');
INSERT INTO `mny_address` VALUES ('2200', '市辖区', '1', '0', '223', '3');
INSERT INTO `mny_address` VALUES ('2201', '珠晖区', '1', '0', '223', '3');
INSERT INTO `mny_address` VALUES ('2202', '雁峰区', '1', '0', '223', '3');
INSERT INTO `mny_address` VALUES ('2203', '石鼓区', '1', '0', '223', '3');
INSERT INTO `mny_address` VALUES ('2204', '蒸湘区', '1', '0', '223', '3');
INSERT INTO `mny_address` VALUES ('2205', '南岳区', '1', '0', '223', '3');
INSERT INTO `mny_address` VALUES ('2206', '衡阳县', '1', '0', '223', '3');
INSERT INTO `mny_address` VALUES ('2207', '衡南县', '1', '0', '223', '3');
INSERT INTO `mny_address` VALUES ('2208', '衡山县', '1', '0', '223', '3');
INSERT INTO `mny_address` VALUES ('2209', '衡东县', '1', '0', '223', '3');
INSERT INTO `mny_address` VALUES ('2210', '祁东县', '1', '0', '223', '3');
INSERT INTO `mny_address` VALUES ('2211', '耒阳市', '1', '0', '223', '3');
INSERT INTO `mny_address` VALUES ('2212', '常宁市', '1', '0', '223', '3');
INSERT INTO `mny_address` VALUES ('2213', '市辖区', '1', '0', '224', '3');
INSERT INTO `mny_address` VALUES ('2214', '双清区', '1', '0', '224', '3');
INSERT INTO `mny_address` VALUES ('2215', '大祥区', '1', '0', '224', '3');
INSERT INTO `mny_address` VALUES ('2216', '北塔区', '1', '0', '224', '3');
INSERT INTO `mny_address` VALUES ('2217', '邵东县', '1', '0', '224', '3');
INSERT INTO `mny_address` VALUES ('2218', '新邵县', '1', '0', '224', '3');
INSERT INTO `mny_address` VALUES ('2219', '邵阳县', '1', '0', '224', '3');
INSERT INTO `mny_address` VALUES ('2220', '隆回县', '1', '0', '224', '3');
INSERT INTO `mny_address` VALUES ('2221', '洞口县', '1', '0', '224', '3');
INSERT INTO `mny_address` VALUES ('2222', '绥宁县', '1', '0', '224', '3');
INSERT INTO `mny_address` VALUES ('2223', '新宁县', '1', '0', '224', '3');
INSERT INTO `mny_address` VALUES ('2224', '城步苗族自治县', '1', '0', '224', '3');
INSERT INTO `mny_address` VALUES ('2225', '武冈市', '1', '0', '224', '3');
INSERT INTO `mny_address` VALUES ('2226', '市辖区', '1', '0', '225', '3');
INSERT INTO `mny_address` VALUES ('2227', '岳阳楼区', '1', '0', '225', '3');
INSERT INTO `mny_address` VALUES ('2228', '云溪区', '1', '0', '225', '3');
INSERT INTO `mny_address` VALUES ('2229', '君山区', '1', '0', '225', '3');
INSERT INTO `mny_address` VALUES ('2230', '岳阳县', '1', '0', '225', '3');
INSERT INTO `mny_address` VALUES ('2231', '华容县', '1', '0', '225', '3');
INSERT INTO `mny_address` VALUES ('2232', '湘阴县', '1', '0', '225', '3');
INSERT INTO `mny_address` VALUES ('2233', '平江县', '1', '0', '225', '3');
INSERT INTO `mny_address` VALUES ('2234', '汨罗市', '1', '0', '225', '3');
INSERT INTO `mny_address` VALUES ('2235', '临湘市', '1', '0', '225', '3');
INSERT INTO `mny_address` VALUES ('2236', '市辖区', '1', '0', '226', '3');
INSERT INTO `mny_address` VALUES ('2237', '武陵区', '1', '0', '226', '3');
INSERT INTO `mny_address` VALUES ('2238', '鼎城区', '1', '0', '226', '3');
INSERT INTO `mny_address` VALUES ('2239', '安乡县', '1', '0', '226', '3');
INSERT INTO `mny_address` VALUES ('2240', '汉寿县', '1', '0', '226', '3');
INSERT INTO `mny_address` VALUES ('2241', '澧　县', '1', '0', '226', '3');
INSERT INTO `mny_address` VALUES ('2242', '临澧县', '1', '0', '226', '3');
INSERT INTO `mny_address` VALUES ('2243', '桃源县', '1', '0', '226', '3');
INSERT INTO `mny_address` VALUES ('2244', '石门县', '1', '0', '226', '3');
INSERT INTO `mny_address` VALUES ('2245', '津市市', '1', '0', '226', '3');
INSERT INTO `mny_address` VALUES ('2246', '市辖区', '1', '0', '227', '3');
INSERT INTO `mny_address` VALUES ('2247', '永定区', '1', '0', '227', '3');
INSERT INTO `mny_address` VALUES ('2248', '武陵源区', '1', '0', '227', '3');
INSERT INTO `mny_address` VALUES ('2249', '慈利县', '1', '0', '227', '3');
INSERT INTO `mny_address` VALUES ('2250', '桑植县', '1', '0', '227', '3');
INSERT INTO `mny_address` VALUES ('2251', '市辖区', '1', '0', '228', '3');
INSERT INTO `mny_address` VALUES ('2252', '资阳区', '1', '0', '228', '3');
INSERT INTO `mny_address` VALUES ('2253', '赫山区', '1', '0', '228', '3');
INSERT INTO `mny_address` VALUES ('2254', '南　县', '1', '0', '228', '3');
INSERT INTO `mny_address` VALUES ('2255', '桃江县', '1', '0', '228', '3');
INSERT INTO `mny_address` VALUES ('2256', '安化县', '1', '0', '228', '3');
INSERT INTO `mny_address` VALUES ('2257', '沅江市', '1', '0', '228', '3');
INSERT INTO `mny_address` VALUES ('2258', '市辖区', '1', '0', '229', '3');
INSERT INTO `mny_address` VALUES ('2259', '北湖区', '1', '0', '229', '3');
INSERT INTO `mny_address` VALUES ('2260', '苏仙区', '1', '0', '229', '3');
INSERT INTO `mny_address` VALUES ('2261', '桂阳县', '1', '0', '229', '3');
INSERT INTO `mny_address` VALUES ('2262', '宜章县', '1', '0', '229', '3');
INSERT INTO `mny_address` VALUES ('2263', '永兴县', '1', '0', '229', '3');
INSERT INTO `mny_address` VALUES ('2264', '嘉禾县', '1', '0', '229', '3');
INSERT INTO `mny_address` VALUES ('2265', '临武县', '1', '0', '229', '3');
INSERT INTO `mny_address` VALUES ('2266', '汝城县', '1', '0', '229', '3');
INSERT INTO `mny_address` VALUES ('2267', '桂东县', '1', '0', '229', '3');
INSERT INTO `mny_address` VALUES ('2268', '安仁县', '1', '0', '229', '3');
INSERT INTO `mny_address` VALUES ('2269', '资兴市', '1', '0', '229', '3');
INSERT INTO `mny_address` VALUES ('2270', '市辖区', '1', '0', '230', '3');
INSERT INTO `mny_address` VALUES ('2271', '芝山区', '1', '0', '230', '3');
INSERT INTO `mny_address` VALUES ('2272', '冷水滩区', '1', '0', '230', '3');
INSERT INTO `mny_address` VALUES ('2273', '祁阳县', '1', '0', '230', '3');
INSERT INTO `mny_address` VALUES ('2274', '东安县', '1', '0', '230', '3');
INSERT INTO `mny_address` VALUES ('2275', '双牌县', '1', '0', '230', '3');
INSERT INTO `mny_address` VALUES ('2276', '道　县', '1', '0', '230', '3');
INSERT INTO `mny_address` VALUES ('2277', '江永县', '1', '0', '230', '3');
INSERT INTO `mny_address` VALUES ('2278', '宁远县', '1', '0', '230', '3');
INSERT INTO `mny_address` VALUES ('2279', '蓝山县', '1', '0', '230', '3');
INSERT INTO `mny_address` VALUES ('2280', '新田县', '1', '0', '230', '3');
INSERT INTO `mny_address` VALUES ('2281', '江华瑶族自治县', '1', '0', '230', '3');
INSERT INTO `mny_address` VALUES ('2282', '市辖区', '1', '0', '231', '3');
INSERT INTO `mny_address` VALUES ('2283', '鹤城区', '1', '0', '231', '3');
INSERT INTO `mny_address` VALUES ('2284', '中方县', '1', '0', '231', '3');
INSERT INTO `mny_address` VALUES ('2285', '沅陵县', '1', '0', '231', '3');
INSERT INTO `mny_address` VALUES ('2286', '辰溪县', '1', '0', '231', '3');
INSERT INTO `mny_address` VALUES ('2287', '溆浦县', '1', '0', '231', '3');
INSERT INTO `mny_address` VALUES ('2288', '会同县', '1', '0', '231', '3');
INSERT INTO `mny_address` VALUES ('2289', '麻阳苗族自治县', '1', '0', '231', '3');
INSERT INTO `mny_address` VALUES ('2290', '新晃侗族自治县', '1', '0', '231', '3');
INSERT INTO `mny_address` VALUES ('2291', '芷江侗族自治县', '1', '0', '231', '3');
INSERT INTO `mny_address` VALUES ('2292', '靖州苗族侗族自治县', '1', '0', '231', '3');
INSERT INTO `mny_address` VALUES ('2293', '通道侗族自治县', '1', '0', '231', '3');
INSERT INTO `mny_address` VALUES ('2294', '洪江市', '1', '0', '231', '3');
INSERT INTO `mny_address` VALUES ('2295', '市辖区', '1', '0', '232', '3');
INSERT INTO `mny_address` VALUES ('2296', '娄星区', '1', '0', '232', '3');
INSERT INTO `mny_address` VALUES ('2297', '双峰县', '1', '0', '232', '3');
INSERT INTO `mny_address` VALUES ('2298', '新化县', '1', '0', '232', '3');
INSERT INTO `mny_address` VALUES ('2299', '冷水江市', '1', '0', '232', '3');
INSERT INTO `mny_address` VALUES ('2300', '涟源市', '1', '0', '232', '3');
INSERT INTO `mny_address` VALUES ('2301', '吉首市', '1', '0', '233', '3');
INSERT INTO `mny_address` VALUES ('2302', '泸溪县', '1', '0', '233', '3');
INSERT INTO `mny_address` VALUES ('2303', '凤凰县', '1', '0', '233', '3');
INSERT INTO `mny_address` VALUES ('2304', '花垣县', '1', '0', '233', '3');
INSERT INTO `mny_address` VALUES ('2305', '保靖县', '1', '0', '233', '3');
INSERT INTO `mny_address` VALUES ('2306', '古丈县', '1', '0', '233', '3');
INSERT INTO `mny_address` VALUES ('2307', '永顺县', '1', '0', '233', '3');
INSERT INTO `mny_address` VALUES ('2308', '龙山县', '1', '0', '233', '3');
INSERT INTO `mny_address` VALUES ('2309', '市辖区', '1', '0', '234', '3');
INSERT INTO `mny_address` VALUES ('2310', '东山区', '1', '0', '234', '3');
INSERT INTO `mny_address` VALUES ('2311', '荔湾区', '1', '0', '234', '3');
INSERT INTO `mny_address` VALUES ('2312', '越秀区', '1', '0', '234', '3');
INSERT INTO `mny_address` VALUES ('2313', '海珠区', '1', '0', '234', '3');
INSERT INTO `mny_address` VALUES ('2314', '天河区', '1', '0', '234', '3');
INSERT INTO `mny_address` VALUES ('2315', '芳村区', '1', '0', '234', '3');
INSERT INTO `mny_address` VALUES ('2316', '白云区', '1', '0', '234', '3');
INSERT INTO `mny_address` VALUES ('2317', '黄埔区', '1', '0', '234', '3');
INSERT INTO `mny_address` VALUES ('2318', '番禺区', '1', '0', '234', '3');
INSERT INTO `mny_address` VALUES ('2319', '花都区', '1', '0', '234', '3');
INSERT INTO `mny_address` VALUES ('2320', '增城市', '1', '0', '234', '3');
INSERT INTO `mny_address` VALUES ('2321', '从化市', '1', '0', '234', '3');
INSERT INTO `mny_address` VALUES ('2322', '市辖区', '1', '0', '235', '3');
INSERT INTO `mny_address` VALUES ('2323', '武江区', '1', '0', '235', '3');
INSERT INTO `mny_address` VALUES ('2324', '浈江区', '1', '0', '235', '3');
INSERT INTO `mny_address` VALUES ('2325', '曲江区', '1', '0', '235', '3');
INSERT INTO `mny_address` VALUES ('2326', '始兴县', '1', '0', '235', '3');
INSERT INTO `mny_address` VALUES ('2327', '仁化县', '1', '0', '235', '3');
INSERT INTO `mny_address` VALUES ('2328', '翁源县', '1', '0', '235', '3');
INSERT INTO `mny_address` VALUES ('2329', '乳源瑶族自治县', '1', '0', '235', '3');
INSERT INTO `mny_address` VALUES ('2330', '新丰县', '1', '0', '235', '3');
INSERT INTO `mny_address` VALUES ('2331', '乐昌市', '1', '0', '235', '3');
INSERT INTO `mny_address` VALUES ('2332', '南雄市', '1', '0', '235', '3');
INSERT INTO `mny_address` VALUES ('2333', '市辖区', '1', '0', '236', '3');
INSERT INTO `mny_address` VALUES ('2334', '罗湖区', '1', '0', '236', '3');
INSERT INTO `mny_address` VALUES ('2335', '福田区', '1', '0', '236', '3');
INSERT INTO `mny_address` VALUES ('2336', '南山区', '1', '0', '236', '3');
INSERT INTO `mny_address` VALUES ('2337', '宝安区', '1', '0', '236', '3');
INSERT INTO `mny_address` VALUES ('2338', '龙岗区', '1', '0', '236', '3');
INSERT INTO `mny_address` VALUES ('2339', '盐田区', '1', '0', '236', '3');
INSERT INTO `mny_address` VALUES ('2340', '市辖区', '1', '0', '237', '3');
INSERT INTO `mny_address` VALUES ('2341', '香洲区', '1', '0', '237', '3');
INSERT INTO `mny_address` VALUES ('2342', '斗门区', '1', '0', '237', '3');
INSERT INTO `mny_address` VALUES ('2343', '金湾区', '1', '0', '237', '3');
INSERT INTO `mny_address` VALUES ('2344', '市辖区', '1', '0', '238', '3');
INSERT INTO `mny_address` VALUES ('2345', '龙湖区', '1', '0', '238', '3');
INSERT INTO `mny_address` VALUES ('2346', '金平区', '1', '0', '238', '3');
INSERT INTO `mny_address` VALUES ('2347', '濠江区', '1', '0', '238', '3');
INSERT INTO `mny_address` VALUES ('2348', '潮阳区', '1', '0', '238', '3');
INSERT INTO `mny_address` VALUES ('2349', '潮南区', '1', '0', '238', '3');
INSERT INTO `mny_address` VALUES ('2350', '澄海区', '1', '0', '238', '3');
INSERT INTO `mny_address` VALUES ('2351', '南澳县', '1', '0', '238', '3');
INSERT INTO `mny_address` VALUES ('2352', '市辖区', '1', '0', '239', '3');
INSERT INTO `mny_address` VALUES ('2353', '禅城区', '1', '0', '239', '3');
INSERT INTO `mny_address` VALUES ('2354', '南海区', '1', '0', '239', '3');
INSERT INTO `mny_address` VALUES ('2355', '顺德区', '1', '0', '239', '3');
INSERT INTO `mny_address` VALUES ('2356', '三水区', '1', '0', '239', '3');
INSERT INTO `mny_address` VALUES ('2357', '高明区', '1', '0', '239', '3');
INSERT INTO `mny_address` VALUES ('2358', '市辖区', '1', '0', '240', '3');
INSERT INTO `mny_address` VALUES ('2359', '蓬江区', '1', '0', '240', '3');
INSERT INTO `mny_address` VALUES ('2360', '江海区', '1', '0', '240', '3');
INSERT INTO `mny_address` VALUES ('2361', '新会区', '1', '0', '240', '3');
INSERT INTO `mny_address` VALUES ('2362', '台山市', '1', '0', '240', '3');
INSERT INTO `mny_address` VALUES ('2363', '开平市', '1', '0', '240', '3');
INSERT INTO `mny_address` VALUES ('2364', '鹤山市', '1', '0', '240', '3');
INSERT INTO `mny_address` VALUES ('2365', '恩平市', '1', '0', '240', '3');
INSERT INTO `mny_address` VALUES ('2366', '市辖区', '1', '0', '241', '3');
INSERT INTO `mny_address` VALUES ('2367', '赤坎区', '1', '0', '241', '3');
INSERT INTO `mny_address` VALUES ('2368', '霞山区', '1', '0', '241', '3');
INSERT INTO `mny_address` VALUES ('2369', '坡头区', '1', '0', '241', '3');
INSERT INTO `mny_address` VALUES ('2370', '麻章区', '1', '0', '241', '3');
INSERT INTO `mny_address` VALUES ('2371', '遂溪县', '1', '0', '241', '3');
INSERT INTO `mny_address` VALUES ('2372', '徐闻县', '1', '0', '241', '3');
INSERT INTO `mny_address` VALUES ('2373', '廉江市', '1', '0', '241', '3');
INSERT INTO `mny_address` VALUES ('2374', '雷州市', '1', '0', '241', '3');
INSERT INTO `mny_address` VALUES ('2375', '吴川市', '1', '0', '241', '3');
INSERT INTO `mny_address` VALUES ('2376', '市辖区', '1', '0', '242', '3');
INSERT INTO `mny_address` VALUES ('2377', '茂南区', '1', '0', '242', '3');
INSERT INTO `mny_address` VALUES ('2378', '茂港区', '1', '0', '242', '3');
INSERT INTO `mny_address` VALUES ('2379', '电白县', '1', '0', '242', '3');
INSERT INTO `mny_address` VALUES ('2380', '高州市', '1', '0', '242', '3');
INSERT INTO `mny_address` VALUES ('2381', '化州市', '1', '0', '242', '3');
INSERT INTO `mny_address` VALUES ('2382', '信宜市', '1', '0', '242', '3');
INSERT INTO `mny_address` VALUES ('2383', '市辖区', '1', '0', '243', '3');
INSERT INTO `mny_address` VALUES ('2384', '端州区', '1', '0', '243', '3');
INSERT INTO `mny_address` VALUES ('2385', '鼎湖区', '1', '0', '243', '3');
INSERT INTO `mny_address` VALUES ('2386', '广宁县', '1', '0', '243', '3');
INSERT INTO `mny_address` VALUES ('2387', '怀集县', '1', '0', '243', '3');
INSERT INTO `mny_address` VALUES ('2388', '封开县', '1', '0', '243', '3');
INSERT INTO `mny_address` VALUES ('2389', '德庆县', '1', '0', '243', '3');
INSERT INTO `mny_address` VALUES ('2390', '高要市', '1', '0', '243', '3');
INSERT INTO `mny_address` VALUES ('2391', '四会市', '1', '0', '243', '3');
INSERT INTO `mny_address` VALUES ('2392', '市辖区', '1', '0', '244', '3');
INSERT INTO `mny_address` VALUES ('2393', '惠城区', '1', '0', '244', '3');
INSERT INTO `mny_address` VALUES ('2394', '惠阳区', '1', '0', '244', '3');
INSERT INTO `mny_address` VALUES ('2395', '博罗县', '1', '0', '244', '3');
INSERT INTO `mny_address` VALUES ('2396', '惠东县', '1', '0', '244', '3');
INSERT INTO `mny_address` VALUES ('2397', '龙门县', '1', '0', '244', '3');
INSERT INTO `mny_address` VALUES ('2398', '市辖区', '1', '0', '245', '3');
INSERT INTO `mny_address` VALUES ('2399', '梅江区', '1', '0', '245', '3');
INSERT INTO `mny_address` VALUES ('2400', '梅　县', '1', '0', '245', '3');
INSERT INTO `mny_address` VALUES ('2401', '大埔县', '1', '0', '245', '3');
INSERT INTO `mny_address` VALUES ('2402', '丰顺县', '1', '0', '245', '3');
INSERT INTO `mny_address` VALUES ('2403', '五华县', '1', '0', '245', '3');
INSERT INTO `mny_address` VALUES ('2404', '平远县', '1', '0', '245', '3');
INSERT INTO `mny_address` VALUES ('2405', '蕉岭县', '1', '0', '245', '3');
INSERT INTO `mny_address` VALUES ('2406', '兴宁市', '1', '0', '245', '3');
INSERT INTO `mny_address` VALUES ('2407', '市辖区', '1', '0', '246', '3');
INSERT INTO `mny_address` VALUES ('2408', '城　区', '1', '0', '246', '3');
INSERT INTO `mny_address` VALUES ('2409', '海丰县', '1', '0', '246', '3');
INSERT INTO `mny_address` VALUES ('2410', '陆河县', '1', '0', '246', '3');
INSERT INTO `mny_address` VALUES ('2411', '陆丰市', '1', '0', '246', '3');
INSERT INTO `mny_address` VALUES ('2412', '市辖区', '1', '0', '247', '3');
INSERT INTO `mny_address` VALUES ('2413', '源城区', '1', '0', '247', '3');
INSERT INTO `mny_address` VALUES ('2414', '紫金县', '1', '0', '247', '3');
INSERT INTO `mny_address` VALUES ('2415', '龙川县', '1', '0', '247', '3');
INSERT INTO `mny_address` VALUES ('2416', '连平县', '1', '0', '247', '3');
INSERT INTO `mny_address` VALUES ('2417', '和平县', '1', '0', '247', '3');
INSERT INTO `mny_address` VALUES ('2418', '东源县', '1', '0', '247', '3');
INSERT INTO `mny_address` VALUES ('2419', '市辖区', '1', '0', '248', '3');
INSERT INTO `mny_address` VALUES ('2420', '江城区', '1', '0', '248', '3');
INSERT INTO `mny_address` VALUES ('2421', '阳西县', '1', '0', '248', '3');
INSERT INTO `mny_address` VALUES ('2422', '阳东县', '1', '0', '248', '3');
INSERT INTO `mny_address` VALUES ('2423', '阳春市', '1', '0', '248', '3');
INSERT INTO `mny_address` VALUES ('2424', '市辖区', '1', '0', '249', '3');
INSERT INTO `mny_address` VALUES ('2425', '清城区', '1', '0', '249', '3');
INSERT INTO `mny_address` VALUES ('2426', '佛冈县', '1', '0', '249', '3');
INSERT INTO `mny_address` VALUES ('2427', '阳山县', '1', '0', '249', '3');
INSERT INTO `mny_address` VALUES ('2428', '连山壮族瑶族自治县', '1', '0', '249', '3');
INSERT INTO `mny_address` VALUES ('2429', '连南瑶族自治县', '1', '0', '249', '3');
INSERT INTO `mny_address` VALUES ('2430', '清新县', '1', '0', '249', '3');
INSERT INTO `mny_address` VALUES ('2431', '英德市', '1', '0', '249', '3');
INSERT INTO `mny_address` VALUES ('2432', '连州市', '1', '0', '249', '3');
INSERT INTO `mny_address` VALUES ('2433', '市辖区', '1', '0', '252', '3');
INSERT INTO `mny_address` VALUES ('2434', '湘桥区', '1', '0', '252', '3');
INSERT INTO `mny_address` VALUES ('2435', '潮安县', '1', '0', '252', '3');
INSERT INTO `mny_address` VALUES ('2436', '饶平县', '1', '0', '252', '3');
INSERT INTO `mny_address` VALUES ('2437', '市辖区', '1', '0', '253', '3');
INSERT INTO `mny_address` VALUES ('2438', '榕城区', '1', '0', '253', '3');
INSERT INTO `mny_address` VALUES ('2439', '揭东县', '1', '0', '253', '3');
INSERT INTO `mny_address` VALUES ('2440', '揭西县', '1', '0', '253', '3');
INSERT INTO `mny_address` VALUES ('2441', '惠来县', '1', '0', '253', '3');
INSERT INTO `mny_address` VALUES ('2442', '普宁市', '1', '0', '253', '3');
INSERT INTO `mny_address` VALUES ('2443', '市辖区', '1', '0', '254', '3');
INSERT INTO `mny_address` VALUES ('2444', '云城区', '1', '0', '254', '3');
INSERT INTO `mny_address` VALUES ('2445', '新兴县', '1', '0', '254', '3');
INSERT INTO `mny_address` VALUES ('2446', '郁南县', '1', '0', '254', '3');
INSERT INTO `mny_address` VALUES ('2447', '云安县', '1', '0', '254', '3');
INSERT INTO `mny_address` VALUES ('2448', '罗定市', '1', '0', '254', '3');
INSERT INTO `mny_address` VALUES ('2449', '市辖区', '1', '0', '255', '3');
INSERT INTO `mny_address` VALUES ('2450', '兴宁区', '1', '0', '255', '3');
INSERT INTO `mny_address` VALUES ('2451', '青秀区', '1', '0', '255', '3');
INSERT INTO `mny_address` VALUES ('2452', '江南区', '1', '0', '255', '3');
INSERT INTO `mny_address` VALUES ('2453', '西乡塘区', '1', '0', '255', '3');
INSERT INTO `mny_address` VALUES ('2454', '良庆区', '1', '0', '255', '3');
INSERT INTO `mny_address` VALUES ('2455', '邕宁区', '1', '0', '255', '3');
INSERT INTO `mny_address` VALUES ('2456', '武鸣县', '1', '0', '255', '3');
INSERT INTO `mny_address` VALUES ('2457', '隆安县', '1', '0', '255', '3');
INSERT INTO `mny_address` VALUES ('2458', '马山县', '1', '0', '255', '3');
INSERT INTO `mny_address` VALUES ('2459', '上林县', '1', '0', '255', '3');
INSERT INTO `mny_address` VALUES ('2460', '宾阳县', '1', '0', '255', '3');
INSERT INTO `mny_address` VALUES ('2461', '横　县', '1', '0', '255', '3');
INSERT INTO `mny_address` VALUES ('2462', '市辖区', '1', '0', '256', '3');
INSERT INTO `mny_address` VALUES ('2463', '城中区', '1', '0', '256', '3');
INSERT INTO `mny_address` VALUES ('2464', '鱼峰区', '1', '0', '256', '3');
INSERT INTO `mny_address` VALUES ('2465', '柳南区', '1', '0', '256', '3');
INSERT INTO `mny_address` VALUES ('2466', '柳北区', '1', '0', '256', '3');
INSERT INTO `mny_address` VALUES ('2467', '柳江县', '1', '0', '256', '3');
INSERT INTO `mny_address` VALUES ('2468', '柳城县', '1', '0', '256', '3');
INSERT INTO `mny_address` VALUES ('2469', '鹿寨县', '1', '0', '256', '3');
INSERT INTO `mny_address` VALUES ('2470', '融安县', '1', '0', '256', '3');
INSERT INTO `mny_address` VALUES ('2471', '融水苗族自治县', '1', '0', '256', '3');
INSERT INTO `mny_address` VALUES ('2472', '三江侗族自治县', '1', '0', '256', '3');
INSERT INTO `mny_address` VALUES ('2473', '市辖区', '1', '0', '257', '3');
INSERT INTO `mny_address` VALUES ('2474', '秀峰区', '1', '0', '257', '3');
INSERT INTO `mny_address` VALUES ('2475', '叠彩区', '1', '0', '257', '3');
INSERT INTO `mny_address` VALUES ('2476', '象山区', '1', '0', '257', '3');
INSERT INTO `mny_address` VALUES ('2477', '七星区', '1', '0', '257', '3');
INSERT INTO `mny_address` VALUES ('2478', '雁山区', '1', '0', '257', '3');
INSERT INTO `mny_address` VALUES ('2479', '阳朔县', '1', '0', '257', '3');
INSERT INTO `mny_address` VALUES ('2480', '临桂县', '1', '0', '257', '3');
INSERT INTO `mny_address` VALUES ('2481', '灵川县', '1', '0', '257', '3');
INSERT INTO `mny_address` VALUES ('2482', '全州县', '1', '0', '257', '3');
INSERT INTO `mny_address` VALUES ('2483', '兴安县', '1', '0', '257', '3');
INSERT INTO `mny_address` VALUES ('2484', '永福县', '1', '0', '257', '3');
INSERT INTO `mny_address` VALUES ('2485', '灌阳县', '1', '0', '257', '3');
INSERT INTO `mny_address` VALUES ('2486', '龙胜各族自治县', '1', '0', '257', '3');
INSERT INTO `mny_address` VALUES ('2487', '资源县', '1', '0', '257', '3');
INSERT INTO `mny_address` VALUES ('2488', '平乐县', '1', '0', '257', '3');
INSERT INTO `mny_address` VALUES ('2489', '荔蒲县', '1', '0', '257', '3');
INSERT INTO `mny_address` VALUES ('2490', '恭城瑶族自治县', '1', '0', '257', '3');
INSERT INTO `mny_address` VALUES ('2491', '市辖区', '1', '0', '258', '3');
INSERT INTO `mny_address` VALUES ('2492', '万秀区', '1', '0', '258', '3');
INSERT INTO `mny_address` VALUES ('2493', '蝶山区', '1', '0', '258', '3');
INSERT INTO `mny_address` VALUES ('2494', '长洲区', '1', '0', '258', '3');
INSERT INTO `mny_address` VALUES ('2495', '苍梧县', '1', '0', '258', '3');
INSERT INTO `mny_address` VALUES ('2496', '藤　县', '1', '0', '258', '3');
INSERT INTO `mny_address` VALUES ('2497', '蒙山县', '1', '0', '258', '3');
INSERT INTO `mny_address` VALUES ('2498', '岑溪市', '1', '0', '258', '3');
INSERT INTO `mny_address` VALUES ('2499', '市辖区', '1', '0', '259', '3');
INSERT INTO `mny_address` VALUES ('2500', '海城区', '1', '0', '259', '3');
INSERT INTO `mny_address` VALUES ('2501', '银海区', '1', '0', '259', '3');
INSERT INTO `mny_address` VALUES ('2502', '铁山港区', '1', '0', '259', '3');
INSERT INTO `mny_address` VALUES ('2503', '合浦县', '1', '0', '259', '3');
INSERT INTO `mny_address` VALUES ('2504', '市辖区', '1', '0', '260', '3');
INSERT INTO `mny_address` VALUES ('2505', '港口区', '1', '0', '260', '3');
INSERT INTO `mny_address` VALUES ('2506', '防城区', '1', '0', '260', '3');
INSERT INTO `mny_address` VALUES ('2507', '上思县', '1', '0', '260', '3');
INSERT INTO `mny_address` VALUES ('2508', '东兴市', '1', '0', '260', '3');
INSERT INTO `mny_address` VALUES ('2509', '市辖区', '1', '0', '261', '3');
INSERT INTO `mny_address` VALUES ('2510', '钦南区', '1', '0', '261', '3');
INSERT INTO `mny_address` VALUES ('2511', '钦北区', '1', '0', '261', '3');
INSERT INTO `mny_address` VALUES ('2512', '灵山县', '1', '0', '261', '3');
INSERT INTO `mny_address` VALUES ('2513', '浦北县', '1', '0', '261', '3');
INSERT INTO `mny_address` VALUES ('2514', '市辖区', '1', '0', '262', '3');
INSERT INTO `mny_address` VALUES ('2515', '港北区', '1', '0', '262', '3');
INSERT INTO `mny_address` VALUES ('2516', '港南区', '1', '0', '262', '3');
INSERT INTO `mny_address` VALUES ('2517', '覃塘区', '1', '0', '262', '3');
INSERT INTO `mny_address` VALUES ('2518', '平南县', '1', '0', '262', '3');
INSERT INTO `mny_address` VALUES ('2519', '桂平市', '1', '0', '262', '3');
INSERT INTO `mny_address` VALUES ('2520', '市辖区', '1', '0', '263', '3');
INSERT INTO `mny_address` VALUES ('2521', '玉州区', '1', '0', '263', '3');
INSERT INTO `mny_address` VALUES ('2522', '容　县', '1', '0', '263', '3');
INSERT INTO `mny_address` VALUES ('2523', '陆川县', '1', '0', '263', '3');
INSERT INTO `mny_address` VALUES ('2524', '博白县', '1', '0', '263', '3');
INSERT INTO `mny_address` VALUES ('2525', '兴业县', '1', '0', '263', '3');
INSERT INTO `mny_address` VALUES ('2526', '北流市', '1', '0', '263', '3');
INSERT INTO `mny_address` VALUES ('2527', '市辖区', '1', '0', '264', '3');
INSERT INTO `mny_address` VALUES ('2528', '右江区', '1', '0', '264', '3');
INSERT INTO `mny_address` VALUES ('2529', '田阳县', '1', '0', '264', '3');
INSERT INTO `mny_address` VALUES ('2530', '田东县', '1', '0', '264', '3');
INSERT INTO `mny_address` VALUES ('2531', '平果县', '1', '0', '264', '3');
INSERT INTO `mny_address` VALUES ('2532', '德保县', '1', '0', '264', '3');
INSERT INTO `mny_address` VALUES ('2533', '靖西县', '1', '0', '264', '3');
INSERT INTO `mny_address` VALUES ('2534', '那坡县', '1', '0', '264', '3');
INSERT INTO `mny_address` VALUES ('2535', '凌云县', '1', '0', '264', '3');
INSERT INTO `mny_address` VALUES ('2536', '乐业县', '1', '0', '264', '3');
INSERT INTO `mny_address` VALUES ('2537', '田林县', '1', '0', '264', '3');
INSERT INTO `mny_address` VALUES ('2538', '西林县', '1', '0', '264', '3');
INSERT INTO `mny_address` VALUES ('2539', '隆林各族自治县', '1', '0', '264', '3');
INSERT INTO `mny_address` VALUES ('2540', '市辖区', '1', '0', '265', '3');
INSERT INTO `mny_address` VALUES ('2541', '八步区', '1', '0', '265', '3');
INSERT INTO `mny_address` VALUES ('2542', '昭平县', '1', '0', '265', '3');
INSERT INTO `mny_address` VALUES ('2543', '钟山县', '1', '0', '265', '3');
INSERT INTO `mny_address` VALUES ('2544', '富川瑶族自治县', '1', '0', '265', '3');
INSERT INTO `mny_address` VALUES ('2545', '市辖区', '1', '0', '266', '3');
INSERT INTO `mny_address` VALUES ('2546', '金城江区', '1', '0', '266', '3');
INSERT INTO `mny_address` VALUES ('2547', '南丹县', '1', '0', '266', '3');
INSERT INTO `mny_address` VALUES ('2548', '天峨县', '1', '0', '266', '3');
INSERT INTO `mny_address` VALUES ('2549', '凤山县', '1', '0', '266', '3');
INSERT INTO `mny_address` VALUES ('2550', '东兰县', '1', '0', '266', '3');
INSERT INTO `mny_address` VALUES ('2551', '罗城仫佬族自治县', '1', '0', '266', '3');
INSERT INTO `mny_address` VALUES ('2552', '环江毛南族自治县', '1', '0', '266', '3');
INSERT INTO `mny_address` VALUES ('2553', '巴马瑶族自治县', '1', '0', '266', '3');
INSERT INTO `mny_address` VALUES ('2554', '都安瑶族自治县', '1', '0', '266', '3');
INSERT INTO `mny_address` VALUES ('2555', '大化瑶族自治县', '1', '0', '266', '3');
INSERT INTO `mny_address` VALUES ('2556', '宜州市', '1', '0', '266', '3');
INSERT INTO `mny_address` VALUES ('2557', '市辖区', '1', '0', '267', '3');
INSERT INTO `mny_address` VALUES ('2558', '兴宾区', '1', '0', '267', '3');
INSERT INTO `mny_address` VALUES ('2559', '忻城县', '1', '0', '267', '3');
INSERT INTO `mny_address` VALUES ('2560', '象州县', '1', '0', '267', '3');
INSERT INTO `mny_address` VALUES ('2561', '武宣县', '1', '0', '267', '3');
INSERT INTO `mny_address` VALUES ('2562', '金秀瑶族自治县', '1', '0', '267', '3');
INSERT INTO `mny_address` VALUES ('2563', '合山市', '1', '0', '267', '3');
INSERT INTO `mny_address` VALUES ('2564', '市辖区', '1', '0', '268', '3');
INSERT INTO `mny_address` VALUES ('2565', '江洲区', '1', '0', '268', '3');
INSERT INTO `mny_address` VALUES ('2566', '扶绥县', '1', '0', '268', '3');
INSERT INTO `mny_address` VALUES ('2567', '宁明县', '1', '0', '268', '3');
INSERT INTO `mny_address` VALUES ('2568', '龙州县', '1', '0', '268', '3');
INSERT INTO `mny_address` VALUES ('2569', '大新县', '1', '0', '268', '3');
INSERT INTO `mny_address` VALUES ('2570', '天等县', '1', '0', '268', '3');
INSERT INTO `mny_address` VALUES ('2571', '凭祥市', '1', '0', '268', '3');
INSERT INTO `mny_address` VALUES ('2572', '市辖区', '1', '0', '269', '3');
INSERT INTO `mny_address` VALUES ('2573', '秀英区', '1', '0', '269', '3');
INSERT INTO `mny_address` VALUES ('2574', '龙华区', '1', '0', '269', '3');
INSERT INTO `mny_address` VALUES ('2575', '琼山区', '1', '0', '269', '3');
INSERT INTO `mny_address` VALUES ('2576', '美兰区', '1', '0', '269', '3');
INSERT INTO `mny_address` VALUES ('2577', '市辖区', '1', '0', '270', '3');
INSERT INTO `mny_address` VALUES ('2578', '五指山市', '1', '0', '271', '3');
INSERT INTO `mny_address` VALUES ('2579', '琼海市', '1', '0', '271', '3');
INSERT INTO `mny_address` VALUES ('2580', '儋州市', '1', '0', '271', '3');
INSERT INTO `mny_address` VALUES ('2581', '文昌市', '1', '0', '271', '3');
INSERT INTO `mny_address` VALUES ('2582', '万宁市', '1', '0', '271', '3');
INSERT INTO `mny_address` VALUES ('2583', '东方市', '1', '0', '271', '3');
INSERT INTO `mny_address` VALUES ('2584', '定安县', '1', '0', '271', '3');
INSERT INTO `mny_address` VALUES ('2585', '屯昌县', '1', '0', '271', '3');
INSERT INTO `mny_address` VALUES ('2586', '澄迈县', '1', '0', '271', '3');
INSERT INTO `mny_address` VALUES ('2587', '临高县', '1', '0', '271', '3');
INSERT INTO `mny_address` VALUES ('2588', '白沙黎族自治县', '1', '0', '271', '3');
INSERT INTO `mny_address` VALUES ('2589', '昌江黎族自治县', '1', '0', '271', '3');
INSERT INTO `mny_address` VALUES ('2590', '乐东黎族自治县', '1', '0', '271', '3');
INSERT INTO `mny_address` VALUES ('2591', '陵水黎族自治县', '1', '0', '271', '3');
INSERT INTO `mny_address` VALUES ('2592', '保亭黎族苗族自治县', '1', '0', '271', '3');
INSERT INTO `mny_address` VALUES ('2593', '琼中黎族苗族自治县', '1', '0', '271', '3');
INSERT INTO `mny_address` VALUES ('2594', '西沙群岛', '1', '0', '271', '3');
INSERT INTO `mny_address` VALUES ('2595', '南沙群岛', '1', '0', '271', '3');
INSERT INTO `mny_address` VALUES ('2596', '中沙群岛的岛礁及其海域', '1', '0', '271', '3');
INSERT INTO `mny_address` VALUES ('2597', '万州区', '1', '0', '272', '3');
INSERT INTO `mny_address` VALUES ('2598', '涪陵区', '1', '0', '272', '3');
INSERT INTO `mny_address` VALUES ('2599', '渝中区', '1', '0', '272', '3');
INSERT INTO `mny_address` VALUES ('2600', '大渡口区', '1', '0', '272', '3');
INSERT INTO `mny_address` VALUES ('2601', '江北区', '1', '0', '272', '3');
INSERT INTO `mny_address` VALUES ('2602', '沙坪坝区', '1', '0', '272', '3');
INSERT INTO `mny_address` VALUES ('2603', '九龙坡区', '1', '0', '272', '3');
INSERT INTO `mny_address` VALUES ('2604', '南岸区', '1', '0', '272', '3');
INSERT INTO `mny_address` VALUES ('2605', '北碚区', '1', '0', '272', '3');
INSERT INTO `mny_address` VALUES ('2606', '万盛区', '1', '0', '272', '3');
INSERT INTO `mny_address` VALUES ('2607', '双桥区', '1', '0', '272', '3');
INSERT INTO `mny_address` VALUES ('2608', '渝北区', '1', '0', '272', '3');
INSERT INTO `mny_address` VALUES ('2609', '巴南区', '1', '0', '272', '3');
INSERT INTO `mny_address` VALUES ('2610', '黔江区', '1', '0', '272', '3');
INSERT INTO `mny_address` VALUES ('2611', '长寿区', '1', '0', '272', '3');
INSERT INTO `mny_address` VALUES ('2612', '綦江县', '1', '0', '273', '3');
INSERT INTO `mny_address` VALUES ('2613', '潼南县', '1', '0', '273', '3');
INSERT INTO `mny_address` VALUES ('2614', '铜梁县', '1', '0', '273', '3');
INSERT INTO `mny_address` VALUES ('2615', '大足县', '1', '0', '273', '3');
INSERT INTO `mny_address` VALUES ('2616', '荣昌县', '1', '0', '273', '3');
INSERT INTO `mny_address` VALUES ('2617', '璧山县', '1', '0', '273', '3');
INSERT INTO `mny_address` VALUES ('2618', '梁平县', '1', '0', '273', '3');
INSERT INTO `mny_address` VALUES ('2619', '城口县', '1', '0', '273', '3');
INSERT INTO `mny_address` VALUES ('2620', '丰都县', '1', '0', '273', '3');
INSERT INTO `mny_address` VALUES ('2621', '垫江县', '1', '0', '273', '3');
INSERT INTO `mny_address` VALUES ('2622', '武隆县', '1', '0', '273', '3');
INSERT INTO `mny_address` VALUES ('2623', '忠　县', '1', '0', '273', '3');
INSERT INTO `mny_address` VALUES ('2624', '开　县', '1', '0', '273', '3');
INSERT INTO `mny_address` VALUES ('2625', '云阳县', '1', '0', '273', '3');
INSERT INTO `mny_address` VALUES ('2626', '奉节县', '1', '0', '273', '3');
INSERT INTO `mny_address` VALUES ('2627', '巫山县', '1', '0', '273', '3');
INSERT INTO `mny_address` VALUES ('2628', '巫溪县', '1', '0', '273', '3');
INSERT INTO `mny_address` VALUES ('2629', '石柱土家族自治县', '1', '0', '273', '3');
INSERT INTO `mny_address` VALUES ('2630', '秀山土家族苗族自治县', '1', '0', '273', '3');
INSERT INTO `mny_address` VALUES ('2631', '酉阳土家族苗族自治县', '1', '0', '273', '3');
INSERT INTO `mny_address` VALUES ('2632', '彭水苗族土家族自治县', '1', '0', '273', '3');
INSERT INTO `mny_address` VALUES ('2633', '江津市', '1', '0', '274', '3');
INSERT INTO `mny_address` VALUES ('2634', '合川市', '1', '0', '274', '3');
INSERT INTO `mny_address` VALUES ('2635', '永川市', '1', '0', '274', '3');
INSERT INTO `mny_address` VALUES ('2636', '南川市', '1', '0', '274', '3');
INSERT INTO `mny_address` VALUES ('2637', '市辖区', '1', '0', '275', '3');
INSERT INTO `mny_address` VALUES ('2638', '锦江区', '1', '0', '275', '3');
INSERT INTO `mny_address` VALUES ('2639', '青羊区', '1', '0', '275', '3');
INSERT INTO `mny_address` VALUES ('2640', '金牛区', '1', '0', '275', '3');
INSERT INTO `mny_address` VALUES ('2641', '武侯区', '1', '0', '275', '3');
INSERT INTO `mny_address` VALUES ('2642', '成华区', '1', '0', '275', '3');
INSERT INTO `mny_address` VALUES ('2643', '龙泉驿区', '1', '0', '275', '3');
INSERT INTO `mny_address` VALUES ('2644', '青白江区', '1', '0', '275', '3');
INSERT INTO `mny_address` VALUES ('2645', '新都区', '1', '0', '275', '3');
INSERT INTO `mny_address` VALUES ('2646', '温江区', '1', '0', '275', '3');
INSERT INTO `mny_address` VALUES ('2647', '金堂县', '1', '0', '275', '3');
INSERT INTO `mny_address` VALUES ('2648', '双流县', '1', '0', '275', '3');
INSERT INTO `mny_address` VALUES ('2649', '郫　县', '1', '0', '275', '3');
INSERT INTO `mny_address` VALUES ('2650', '大邑县', '1', '0', '275', '3');
INSERT INTO `mny_address` VALUES ('2651', '蒲江县', '1', '0', '275', '3');
INSERT INTO `mny_address` VALUES ('2652', '新津县', '1', '0', '275', '3');
INSERT INTO `mny_address` VALUES ('2653', '都江堰市', '1', '0', '275', '3');
INSERT INTO `mny_address` VALUES ('2654', '彭州市', '1', '0', '275', '3');
INSERT INTO `mny_address` VALUES ('2655', '邛崃市', '1', '0', '275', '3');
INSERT INTO `mny_address` VALUES ('2656', '崇州市', '1', '0', '275', '3');
INSERT INTO `mny_address` VALUES ('2657', '市辖区', '1', '0', '276', '3');
INSERT INTO `mny_address` VALUES ('2658', '自流井区', '1', '0', '276', '3');
INSERT INTO `mny_address` VALUES ('2659', '贡井区', '1', '0', '276', '3');
INSERT INTO `mny_address` VALUES ('2660', '大安区', '1', '0', '276', '3');
INSERT INTO `mny_address` VALUES ('2661', '沿滩区', '1', '0', '276', '3');
INSERT INTO `mny_address` VALUES ('2662', '荣　县', '1', '0', '276', '3');
INSERT INTO `mny_address` VALUES ('2663', '富顺县', '1', '0', '276', '3');
INSERT INTO `mny_address` VALUES ('2664', '市辖区', '1', '0', '277', '3');
INSERT INTO `mny_address` VALUES ('2665', '东　区', '1', '0', '277', '3');
INSERT INTO `mny_address` VALUES ('2666', '西　区', '1', '0', '277', '3');
INSERT INTO `mny_address` VALUES ('2667', '仁和区', '1', '0', '277', '3');
INSERT INTO `mny_address` VALUES ('2668', '米易县', '1', '0', '277', '3');
INSERT INTO `mny_address` VALUES ('2669', '盐边县', '1', '0', '277', '3');
INSERT INTO `mny_address` VALUES ('2670', '市辖区', '1', '0', '278', '3');
INSERT INTO `mny_address` VALUES ('2671', '江阳区', '1', '0', '278', '3');
INSERT INTO `mny_address` VALUES ('2672', '纳溪区', '1', '0', '278', '3');
INSERT INTO `mny_address` VALUES ('2673', '龙马潭区', '1', '0', '278', '3');
INSERT INTO `mny_address` VALUES ('2674', '泸　县', '1', '0', '278', '3');
INSERT INTO `mny_address` VALUES ('2675', '合江县', '1', '0', '278', '3');
INSERT INTO `mny_address` VALUES ('2676', '叙永县', '1', '0', '278', '3');
INSERT INTO `mny_address` VALUES ('2677', '古蔺县', '1', '0', '278', '3');
INSERT INTO `mny_address` VALUES ('2678', '市辖区', '1', '0', '279', '3');
INSERT INTO `mny_address` VALUES ('2679', '旌阳区', '1', '0', '279', '3');
INSERT INTO `mny_address` VALUES ('2680', '中江县', '1', '0', '279', '3');
INSERT INTO `mny_address` VALUES ('2681', '罗江县', '1', '0', '279', '3');
INSERT INTO `mny_address` VALUES ('2682', '广汉市', '1', '0', '279', '3');
INSERT INTO `mny_address` VALUES ('2683', '什邡市', '1', '0', '279', '3');
INSERT INTO `mny_address` VALUES ('2684', '绵竹市', '1', '0', '279', '3');
INSERT INTO `mny_address` VALUES ('2685', '市辖区', '1', '0', '280', '3');
INSERT INTO `mny_address` VALUES ('2686', '涪城区', '1', '0', '280', '3');
INSERT INTO `mny_address` VALUES ('2687', '游仙区', '1', '0', '280', '3');
INSERT INTO `mny_address` VALUES ('2688', '三台县', '1', '0', '280', '3');
INSERT INTO `mny_address` VALUES ('2689', '盐亭县', '1', '0', '280', '3');
INSERT INTO `mny_address` VALUES ('2690', '安　县', '1', '0', '280', '3');
INSERT INTO `mny_address` VALUES ('2691', '梓潼县', '1', '0', '280', '3');
INSERT INTO `mny_address` VALUES ('2692', '北川羌族自治县', '1', '0', '280', '3');
INSERT INTO `mny_address` VALUES ('2693', '平武县', '1', '0', '280', '3');
INSERT INTO `mny_address` VALUES ('2694', '江油市', '1', '0', '280', '3');
INSERT INTO `mny_address` VALUES ('2695', '市辖区', '1', '0', '281', '3');
INSERT INTO `mny_address` VALUES ('2696', '市中区', '1', '0', '281', '3');
INSERT INTO `mny_address` VALUES ('2697', '元坝区', '1', '0', '281', '3');
INSERT INTO `mny_address` VALUES ('2698', '朝天区', '1', '0', '281', '3');
INSERT INTO `mny_address` VALUES ('2699', '旺苍县', '1', '0', '281', '3');
INSERT INTO `mny_address` VALUES ('2700', '青川县', '1', '0', '281', '3');
INSERT INTO `mny_address` VALUES ('2701', '剑阁县', '1', '0', '281', '3');
INSERT INTO `mny_address` VALUES ('2702', '苍溪县', '1', '0', '281', '3');
INSERT INTO `mny_address` VALUES ('2703', '市辖区', '1', '0', '282', '3');
INSERT INTO `mny_address` VALUES ('2704', '船山区', '1', '0', '282', '3');
INSERT INTO `mny_address` VALUES ('2705', '安居区', '1', '0', '282', '3');
INSERT INTO `mny_address` VALUES ('2706', '蓬溪县', '1', '0', '282', '3');
INSERT INTO `mny_address` VALUES ('2707', '射洪县', '1', '0', '282', '3');
INSERT INTO `mny_address` VALUES ('2708', '大英县', '1', '0', '282', '3');
INSERT INTO `mny_address` VALUES ('2709', '市辖区', '1', '0', '283', '3');
INSERT INTO `mny_address` VALUES ('2710', '市中区', '1', '0', '283', '3');
INSERT INTO `mny_address` VALUES ('2711', '东兴区', '1', '0', '283', '3');
INSERT INTO `mny_address` VALUES ('2712', '威远县', '1', '0', '283', '3');
INSERT INTO `mny_address` VALUES ('2713', '资中县', '1', '0', '283', '3');
INSERT INTO `mny_address` VALUES ('2714', '隆昌县', '1', '0', '283', '3');
INSERT INTO `mny_address` VALUES ('2715', '市辖区', '1', '0', '284', '3');
INSERT INTO `mny_address` VALUES ('2716', '市中区', '1', '0', '284', '3');
INSERT INTO `mny_address` VALUES ('2717', '沙湾区', '1', '0', '284', '3');
INSERT INTO `mny_address` VALUES ('2718', '五通桥区', '1', '0', '284', '3');
INSERT INTO `mny_address` VALUES ('2719', '金口河区', '1', '0', '284', '3');
INSERT INTO `mny_address` VALUES ('2720', '犍为县', '1', '0', '284', '3');
INSERT INTO `mny_address` VALUES ('2721', '井研县', '1', '0', '284', '3');
INSERT INTO `mny_address` VALUES ('2722', '夹江县', '1', '0', '284', '3');
INSERT INTO `mny_address` VALUES ('2723', '沐川县', '1', '0', '284', '3');
INSERT INTO `mny_address` VALUES ('2724', '峨边彝族自治县', '1', '0', '284', '3');
INSERT INTO `mny_address` VALUES ('2725', '马边彝族自治县', '1', '0', '284', '3');
INSERT INTO `mny_address` VALUES ('2726', '峨眉山市', '1', '0', '284', '3');
INSERT INTO `mny_address` VALUES ('2727', '市辖区', '1', '0', '285', '3');
INSERT INTO `mny_address` VALUES ('2728', '顺庆区', '1', '0', '285', '3');
INSERT INTO `mny_address` VALUES ('2729', '高坪区', '1', '0', '285', '3');
INSERT INTO `mny_address` VALUES ('2730', '嘉陵区', '1', '0', '285', '3');
INSERT INTO `mny_address` VALUES ('2731', '南部县', '1', '0', '285', '3');
INSERT INTO `mny_address` VALUES ('2732', '营山县', '1', '0', '285', '3');
INSERT INTO `mny_address` VALUES ('2733', '蓬安县', '1', '0', '285', '3');
INSERT INTO `mny_address` VALUES ('2734', '仪陇县', '1', '0', '285', '3');
INSERT INTO `mny_address` VALUES ('2735', '西充县', '1', '0', '285', '3');
INSERT INTO `mny_address` VALUES ('2736', '阆中市', '1', '0', '285', '3');
INSERT INTO `mny_address` VALUES ('2737', '市辖区', '1', '0', '286', '3');
INSERT INTO `mny_address` VALUES ('2738', '东坡区', '1', '0', '286', '3');
INSERT INTO `mny_address` VALUES ('2739', '仁寿县', '1', '0', '286', '3');
INSERT INTO `mny_address` VALUES ('2740', '彭山县', '1', '0', '286', '3');
INSERT INTO `mny_address` VALUES ('2741', '洪雅县', '1', '0', '286', '3');
INSERT INTO `mny_address` VALUES ('2742', '丹棱县', '1', '0', '286', '3');
INSERT INTO `mny_address` VALUES ('2743', '青神县', '1', '0', '286', '3');
INSERT INTO `mny_address` VALUES ('2744', '市辖区', '1', '0', '287', '3');
INSERT INTO `mny_address` VALUES ('2745', '翠屏区', '1', '0', '287', '3');
INSERT INTO `mny_address` VALUES ('2746', '宜宾县', '1', '0', '287', '3');
INSERT INTO `mny_address` VALUES ('2747', '南溪县', '1', '0', '287', '3');
INSERT INTO `mny_address` VALUES ('2748', '江安县', '1', '0', '287', '3');
INSERT INTO `mny_address` VALUES ('2749', '长宁县', '1', '0', '287', '3');
INSERT INTO `mny_address` VALUES ('2750', '高　县', '1', '0', '287', '3');
INSERT INTO `mny_address` VALUES ('2751', '珙　县', '1', '0', '287', '3');
INSERT INTO `mny_address` VALUES ('2752', '筠连县', '1', '0', '287', '3');
INSERT INTO `mny_address` VALUES ('2753', '兴文县', '1', '0', '287', '3');
INSERT INTO `mny_address` VALUES ('2754', '屏山县', '1', '0', '287', '3');
INSERT INTO `mny_address` VALUES ('2755', '市辖区', '1', '0', '288', '3');
INSERT INTO `mny_address` VALUES ('2756', '广安区', '1', '0', '288', '3');
INSERT INTO `mny_address` VALUES ('2757', '岳池县', '1', '0', '288', '3');
INSERT INTO `mny_address` VALUES ('2758', '武胜县', '1', '0', '288', '3');
INSERT INTO `mny_address` VALUES ('2759', '邻水县', '1', '0', '288', '3');
INSERT INTO `mny_address` VALUES ('2760', '华莹市', '1', '0', '288', '3');
INSERT INTO `mny_address` VALUES ('2761', '市辖区', '1', '0', '289', '3');
INSERT INTO `mny_address` VALUES ('2762', '通川区', '1', '0', '289', '3');
INSERT INTO `mny_address` VALUES ('2763', '达　县', '1', '0', '289', '3');
INSERT INTO `mny_address` VALUES ('2764', '宣汉县', '1', '0', '289', '3');
INSERT INTO `mny_address` VALUES ('2765', '开江县', '1', '0', '289', '3');
INSERT INTO `mny_address` VALUES ('2766', '大竹县', '1', '0', '289', '3');
INSERT INTO `mny_address` VALUES ('2767', '渠　县', '1', '0', '289', '3');
INSERT INTO `mny_address` VALUES ('2768', '万源市', '1', '0', '289', '3');
INSERT INTO `mny_address` VALUES ('2769', '市辖区', '1', '0', '290', '3');
INSERT INTO `mny_address` VALUES ('2770', '雨城区', '1', '0', '290', '3');
INSERT INTO `mny_address` VALUES ('2771', '名山县', '1', '0', '290', '3');
INSERT INTO `mny_address` VALUES ('2772', '荥经县', '1', '0', '290', '3');
INSERT INTO `mny_address` VALUES ('2773', '汉源县', '1', '0', '290', '3');
INSERT INTO `mny_address` VALUES ('2774', '石棉县', '1', '0', '290', '3');
INSERT INTO `mny_address` VALUES ('2775', '天全县', '1', '0', '290', '3');
INSERT INTO `mny_address` VALUES ('2776', '芦山县', '1', '0', '290', '3');
INSERT INTO `mny_address` VALUES ('2777', '宝兴县', '1', '0', '290', '3');
INSERT INTO `mny_address` VALUES ('2778', '市辖区', '1', '0', '291', '3');
INSERT INTO `mny_address` VALUES ('2779', '巴州区', '1', '0', '291', '3');
INSERT INTO `mny_address` VALUES ('2780', '通江县', '1', '0', '291', '3');
INSERT INTO `mny_address` VALUES ('2781', '南江县', '1', '0', '291', '3');
INSERT INTO `mny_address` VALUES ('2782', '平昌县', '1', '0', '291', '3');
INSERT INTO `mny_address` VALUES ('2783', '市辖区', '1', '0', '292', '3');
INSERT INTO `mny_address` VALUES ('2784', '雁江区', '1', '0', '292', '3');
INSERT INTO `mny_address` VALUES ('2785', '安岳县', '1', '0', '292', '3');
INSERT INTO `mny_address` VALUES ('2786', '乐至县', '1', '0', '292', '3');
INSERT INTO `mny_address` VALUES ('2787', '简阳市', '1', '0', '292', '3');
INSERT INTO `mny_address` VALUES ('2788', '汶川县', '1', '0', '293', '3');
INSERT INTO `mny_address` VALUES ('2789', '理　县', '1', '0', '293', '3');
INSERT INTO `mny_address` VALUES ('2790', '茂　县', '1', '0', '293', '3');
INSERT INTO `mny_address` VALUES ('2791', '松潘县', '1', '0', '293', '3');
INSERT INTO `mny_address` VALUES ('2792', '九寨沟县', '1', '0', '293', '3');
INSERT INTO `mny_address` VALUES ('2793', '金川县', '1', '0', '293', '3');
INSERT INTO `mny_address` VALUES ('2794', '小金县', '1', '0', '293', '3');
INSERT INTO `mny_address` VALUES ('2795', '黑水县', '1', '0', '293', '3');
INSERT INTO `mny_address` VALUES ('2796', '马尔康县', '1', '0', '293', '3');
INSERT INTO `mny_address` VALUES ('2797', '壤塘县', '1', '0', '293', '3');
INSERT INTO `mny_address` VALUES ('2798', '阿坝县', '1', '0', '293', '3');
INSERT INTO `mny_address` VALUES ('2799', '若尔盖县', '1', '0', '293', '3');
INSERT INTO `mny_address` VALUES ('2800', '红原县', '1', '0', '293', '3');
INSERT INTO `mny_address` VALUES ('2801', '康定县', '1', '0', '294', '3');
INSERT INTO `mny_address` VALUES ('2802', '泸定县', '1', '0', '294', '3');
INSERT INTO `mny_address` VALUES ('2803', '丹巴县', '1', '0', '294', '3');
INSERT INTO `mny_address` VALUES ('2804', '九龙县', '1', '0', '294', '3');
INSERT INTO `mny_address` VALUES ('2805', '雅江县', '1', '0', '294', '3');
INSERT INTO `mny_address` VALUES ('2806', '道孚县', '1', '0', '294', '3');
INSERT INTO `mny_address` VALUES ('2807', '炉霍县', '1', '0', '294', '3');
INSERT INTO `mny_address` VALUES ('2808', '甘孜县', '1', '0', '294', '3');
INSERT INTO `mny_address` VALUES ('2809', '新龙县', '1', '0', '294', '3');
INSERT INTO `mny_address` VALUES ('2810', '德格县', '1', '0', '294', '3');
INSERT INTO `mny_address` VALUES ('2811', '白玉县', '1', '0', '294', '3');
INSERT INTO `mny_address` VALUES ('2812', '石渠县', '1', '0', '294', '3');
INSERT INTO `mny_address` VALUES ('2813', '色达县', '1', '0', '294', '3');
INSERT INTO `mny_address` VALUES ('2814', '理塘县', '1', '0', '294', '3');
INSERT INTO `mny_address` VALUES ('2815', '巴塘县', '1', '0', '294', '3');
INSERT INTO `mny_address` VALUES ('2816', '乡城县', '1', '0', '294', '3');
INSERT INTO `mny_address` VALUES ('2817', '稻城县', '1', '0', '294', '3');
INSERT INTO `mny_address` VALUES ('2818', '得荣县', '1', '0', '294', '3');
INSERT INTO `mny_address` VALUES ('2819', '西昌市', '1', '0', '295', '3');
INSERT INTO `mny_address` VALUES ('2820', '木里藏族自治县', '1', '0', '295', '3');
INSERT INTO `mny_address` VALUES ('2821', '盐源县', '1', '0', '295', '3');
INSERT INTO `mny_address` VALUES ('2822', '德昌县', '1', '0', '295', '3');
INSERT INTO `mny_address` VALUES ('2823', '会理县', '1', '0', '295', '3');
INSERT INTO `mny_address` VALUES ('2824', '会东县', '1', '0', '295', '3');
INSERT INTO `mny_address` VALUES ('2825', '宁南县', '1', '0', '295', '3');
INSERT INTO `mny_address` VALUES ('2826', '普格县', '1', '0', '295', '3');
INSERT INTO `mny_address` VALUES ('2827', '布拖县', '1', '0', '295', '3');
INSERT INTO `mny_address` VALUES ('2828', '金阳县', '1', '0', '295', '3');
INSERT INTO `mny_address` VALUES ('2829', '昭觉县', '1', '0', '295', '3');
INSERT INTO `mny_address` VALUES ('2830', '喜德县', '1', '0', '295', '3');
INSERT INTO `mny_address` VALUES ('2831', '冕宁县', '1', '0', '295', '3');
INSERT INTO `mny_address` VALUES ('2832', '越西县', '1', '0', '295', '3');
INSERT INTO `mny_address` VALUES ('2833', '甘洛县', '1', '0', '295', '3');
INSERT INTO `mny_address` VALUES ('2834', '美姑县', '1', '0', '295', '3');
INSERT INTO `mny_address` VALUES ('2835', '雷波县', '1', '0', '295', '3');
INSERT INTO `mny_address` VALUES ('2836', '市辖区', '1', '0', '296', '3');
INSERT INTO `mny_address` VALUES ('2837', '南明区', '1', '0', '296', '3');
INSERT INTO `mny_address` VALUES ('2838', '云岩区', '1', '0', '296', '3');
INSERT INTO `mny_address` VALUES ('2839', '花溪区', '1', '0', '296', '3');
INSERT INTO `mny_address` VALUES ('2840', '乌当区', '1', '0', '296', '3');
INSERT INTO `mny_address` VALUES ('2841', '白云区', '1', '0', '296', '3');
INSERT INTO `mny_address` VALUES ('2842', '小河区', '1', '0', '296', '3');
INSERT INTO `mny_address` VALUES ('2843', '开阳县', '1', '0', '296', '3');
INSERT INTO `mny_address` VALUES ('2844', '息烽县', '1', '0', '296', '3');
INSERT INTO `mny_address` VALUES ('2845', '修文县', '1', '0', '296', '3');
INSERT INTO `mny_address` VALUES ('2846', '清镇市', '1', '0', '296', '3');
INSERT INTO `mny_address` VALUES ('2847', '钟山区', '1', '0', '297', '3');
INSERT INTO `mny_address` VALUES ('2848', '六枝特区', '1', '0', '297', '3');
INSERT INTO `mny_address` VALUES ('2849', '水城县', '1', '0', '297', '3');
INSERT INTO `mny_address` VALUES ('2850', '盘　县', '1', '0', '297', '3');
INSERT INTO `mny_address` VALUES ('2851', '市辖区', '1', '0', '298', '3');
INSERT INTO `mny_address` VALUES ('2852', '红花岗区', '1', '0', '298', '3');
INSERT INTO `mny_address` VALUES ('2853', '汇川区', '1', '0', '298', '3');
INSERT INTO `mny_address` VALUES ('2854', '遵义县', '1', '0', '298', '3');
INSERT INTO `mny_address` VALUES ('2855', '桐梓县', '1', '0', '298', '3');
INSERT INTO `mny_address` VALUES ('2856', '绥阳县', '1', '0', '298', '3');
INSERT INTO `mny_address` VALUES ('2857', '正安县', '1', '0', '298', '3');
INSERT INTO `mny_address` VALUES ('2858', '道真仡佬族苗族自治县', '1', '0', '298', '3');
INSERT INTO `mny_address` VALUES ('2859', '务川仡佬族苗族自治县', '1', '0', '298', '3');
INSERT INTO `mny_address` VALUES ('2860', '凤冈县', '1', '0', '298', '3');
INSERT INTO `mny_address` VALUES ('2861', '湄潭县', '1', '0', '298', '3');
INSERT INTO `mny_address` VALUES ('2862', '余庆县', '1', '0', '298', '3');
INSERT INTO `mny_address` VALUES ('2863', '习水县', '1', '0', '298', '3');
INSERT INTO `mny_address` VALUES ('2864', '赤水市', '1', '0', '298', '3');
INSERT INTO `mny_address` VALUES ('2865', '仁怀市', '1', '0', '298', '3');
INSERT INTO `mny_address` VALUES ('2866', '市辖区', '1', '0', '299', '3');
INSERT INTO `mny_address` VALUES ('2867', '西秀区', '1', '0', '299', '3');
INSERT INTO `mny_address` VALUES ('2868', '平坝县', '1', '0', '299', '3');
INSERT INTO `mny_address` VALUES ('2869', '普定县', '1', '0', '299', '3');
INSERT INTO `mny_address` VALUES ('2870', '镇宁布依族苗族自治县', '1', '0', '299', '3');
INSERT INTO `mny_address` VALUES ('2871', '关岭布依族苗族自治县', '1', '0', '299', '3');
INSERT INTO `mny_address` VALUES ('2872', '紫云苗族布依族自治县', '1', '0', '299', '3');
INSERT INTO `mny_address` VALUES ('2873', '铜仁市', '1', '0', '300', '3');
INSERT INTO `mny_address` VALUES ('2874', '江口县', '1', '0', '300', '3');
INSERT INTO `mny_address` VALUES ('2875', '玉屏侗族自治县', '1', '0', '300', '3');
INSERT INTO `mny_address` VALUES ('2876', '石阡县', '1', '0', '300', '3');
INSERT INTO `mny_address` VALUES ('2877', '思南县', '1', '0', '300', '3');
INSERT INTO `mny_address` VALUES ('2878', '印江土家族苗族自治县', '1', '0', '300', '3');
INSERT INTO `mny_address` VALUES ('2879', '德江县', '1', '0', '300', '3');
INSERT INTO `mny_address` VALUES ('2880', '沿河土家族自治县', '1', '0', '300', '3');
INSERT INTO `mny_address` VALUES ('2881', '松桃苗族自治县', '1', '0', '300', '3');
INSERT INTO `mny_address` VALUES ('2882', '万山特区', '1', '0', '300', '3');
INSERT INTO `mny_address` VALUES ('2883', '兴义市', '1', '0', '301', '3');
INSERT INTO `mny_address` VALUES ('2884', '兴仁县', '1', '0', '301', '3');
INSERT INTO `mny_address` VALUES ('2885', '普安县', '1', '0', '301', '3');
INSERT INTO `mny_address` VALUES ('2886', '晴隆县', '1', '0', '301', '3');
INSERT INTO `mny_address` VALUES ('2887', '贞丰县', '1', '0', '301', '3');
INSERT INTO `mny_address` VALUES ('2888', '望谟县', '1', '0', '301', '3');
INSERT INTO `mny_address` VALUES ('2889', '册亨县', '1', '0', '301', '3');
INSERT INTO `mny_address` VALUES ('2890', '安龙县', '1', '0', '301', '3');
INSERT INTO `mny_address` VALUES ('2891', '毕节市', '1', '0', '302', '3');
INSERT INTO `mny_address` VALUES ('2892', '大方县', '1', '0', '302', '3');
INSERT INTO `mny_address` VALUES ('2893', '黔西县', '1', '0', '302', '3');
INSERT INTO `mny_address` VALUES ('2894', '金沙县', '1', '0', '302', '3');
INSERT INTO `mny_address` VALUES ('2895', '织金县', '1', '0', '302', '3');
INSERT INTO `mny_address` VALUES ('2896', '纳雍县', '1', '0', '302', '3');
INSERT INTO `mny_address` VALUES ('2897', '威宁彝族回族苗族自治县', '1', '0', '302', '3');
INSERT INTO `mny_address` VALUES ('2898', '赫章县', '1', '0', '302', '3');
INSERT INTO `mny_address` VALUES ('2899', '凯里市', '1', '0', '303', '3');
INSERT INTO `mny_address` VALUES ('2900', '黄平县', '1', '0', '303', '3');
INSERT INTO `mny_address` VALUES ('2901', '施秉县', '1', '0', '303', '3');
INSERT INTO `mny_address` VALUES ('2902', '三穗县', '1', '0', '303', '3');
INSERT INTO `mny_address` VALUES ('2903', '镇远县', '1', '0', '303', '3');
INSERT INTO `mny_address` VALUES ('2904', '岑巩县', '1', '0', '303', '3');
INSERT INTO `mny_address` VALUES ('2905', '天柱县', '1', '0', '303', '3');
INSERT INTO `mny_address` VALUES ('2906', '锦屏县', '1', '0', '303', '3');
INSERT INTO `mny_address` VALUES ('2907', '剑河县', '1', '0', '303', '3');
INSERT INTO `mny_address` VALUES ('2908', '台江县', '1', '0', '303', '3');
INSERT INTO `mny_address` VALUES ('2909', '黎平县', '1', '0', '303', '3');
INSERT INTO `mny_address` VALUES ('2910', '榕江县', '1', '0', '303', '3');
INSERT INTO `mny_address` VALUES ('2911', '从江县', '1', '0', '303', '3');
INSERT INTO `mny_address` VALUES ('2912', '雷山县', '1', '0', '303', '3');
INSERT INTO `mny_address` VALUES ('2913', '麻江县', '1', '0', '303', '3');
INSERT INTO `mny_address` VALUES ('2914', '丹寨县', '1', '0', '303', '3');
INSERT INTO `mny_address` VALUES ('2915', '都匀市', '1', '0', '304', '3');
INSERT INTO `mny_address` VALUES ('2916', '福泉市', '1', '0', '304', '3');
INSERT INTO `mny_address` VALUES ('2917', '荔波县', '1', '0', '304', '3');
INSERT INTO `mny_address` VALUES ('2918', '贵定县', '1', '0', '304', '3');
INSERT INTO `mny_address` VALUES ('2919', '瓮安县', '1', '0', '304', '3');
INSERT INTO `mny_address` VALUES ('2920', '独山县', '1', '0', '304', '3');
INSERT INTO `mny_address` VALUES ('2921', '平塘县', '1', '0', '304', '3');
INSERT INTO `mny_address` VALUES ('2922', '罗甸县', '1', '0', '304', '3');
INSERT INTO `mny_address` VALUES ('2923', '长顺县', '1', '0', '304', '3');
INSERT INTO `mny_address` VALUES ('2924', '龙里县', '1', '0', '304', '3');
INSERT INTO `mny_address` VALUES ('2925', '惠水县', '1', '0', '304', '3');
INSERT INTO `mny_address` VALUES ('2926', '三都水族自治县', '1', '0', '304', '3');
INSERT INTO `mny_address` VALUES ('2927', '市辖区', '1', '0', '305', '3');
INSERT INTO `mny_address` VALUES ('2928', '五华区', '1', '0', '305', '3');
INSERT INTO `mny_address` VALUES ('2929', '盘龙区', '1', '0', '305', '3');
INSERT INTO `mny_address` VALUES ('2930', '官渡区', '1', '0', '305', '3');
INSERT INTO `mny_address` VALUES ('2931', '西山区', '1', '0', '305', '3');
INSERT INTO `mny_address` VALUES ('2932', '东川区', '1', '0', '305', '3');
INSERT INTO `mny_address` VALUES ('2933', '呈贡县', '1', '0', '305', '3');
INSERT INTO `mny_address` VALUES ('2934', '晋宁县', '1', '0', '305', '3');
INSERT INTO `mny_address` VALUES ('2935', '富民县', '1', '0', '305', '3');
INSERT INTO `mny_address` VALUES ('2936', '宜良县', '1', '0', '305', '3');
INSERT INTO `mny_address` VALUES ('2937', '石林彝族自治县', '1', '0', '305', '3');
INSERT INTO `mny_address` VALUES ('2938', '嵩明县', '1', '0', '305', '3');
INSERT INTO `mny_address` VALUES ('2939', '禄劝彝族苗族自治县', '1', '0', '305', '3');
INSERT INTO `mny_address` VALUES ('2940', '寻甸回族彝族自治县', '1', '0', '305', '3');
INSERT INTO `mny_address` VALUES ('2941', '安宁市', '1', '0', '305', '3');
INSERT INTO `mny_address` VALUES ('2942', '市辖区', '1', '0', '306', '3');
INSERT INTO `mny_address` VALUES ('2943', '麒麟区', '1', '0', '306', '3');
INSERT INTO `mny_address` VALUES ('2944', '马龙县', '1', '0', '306', '3');
INSERT INTO `mny_address` VALUES ('2945', '陆良县', '1', '0', '306', '3');
INSERT INTO `mny_address` VALUES ('2946', '师宗县', '1', '0', '306', '3');
INSERT INTO `mny_address` VALUES ('2947', '罗平县', '1', '0', '306', '3');
INSERT INTO `mny_address` VALUES ('2948', '富源县', '1', '0', '306', '3');
INSERT INTO `mny_address` VALUES ('2949', '会泽县', '1', '0', '306', '3');
INSERT INTO `mny_address` VALUES ('2950', '沾益县', '1', '0', '306', '3');
INSERT INTO `mny_address` VALUES ('2951', '宣威市', '1', '0', '306', '3');
INSERT INTO `mny_address` VALUES ('2952', '市辖区', '1', '0', '307', '3');
INSERT INTO `mny_address` VALUES ('2953', '红塔区', '1', '0', '307', '3');
INSERT INTO `mny_address` VALUES ('2954', '江川县', '1', '0', '307', '3');
INSERT INTO `mny_address` VALUES ('2955', '澄江县', '1', '0', '307', '3');
INSERT INTO `mny_address` VALUES ('2956', '通海县', '1', '0', '307', '3');
INSERT INTO `mny_address` VALUES ('2957', '华宁县', '1', '0', '307', '3');
INSERT INTO `mny_address` VALUES ('2958', '易门县', '1', '0', '307', '3');
INSERT INTO `mny_address` VALUES ('2959', '峨山彝族自治县', '1', '0', '307', '3');
INSERT INTO `mny_address` VALUES ('2960', '新平彝族傣族自治县', '1', '0', '307', '3');
INSERT INTO `mny_address` VALUES ('2961', '元江哈尼族彝族傣族自治县', '1', '0', '307', '3');
INSERT INTO `mny_address` VALUES ('2962', '市辖区', '1', '0', '308', '3');
INSERT INTO `mny_address` VALUES ('2963', '隆阳区', '1', '0', '308', '3');
INSERT INTO `mny_address` VALUES ('2964', '施甸县', '1', '0', '308', '3');
INSERT INTO `mny_address` VALUES ('2965', '腾冲县', '1', '0', '308', '3');
INSERT INTO `mny_address` VALUES ('2966', '龙陵县', '1', '0', '308', '3');
INSERT INTO `mny_address` VALUES ('2967', '昌宁县', '1', '0', '308', '3');
INSERT INTO `mny_address` VALUES ('2968', '市辖区', '1', '0', '309', '3');
INSERT INTO `mny_address` VALUES ('2969', '昭阳区', '1', '0', '309', '3');
INSERT INTO `mny_address` VALUES ('2970', '鲁甸县', '1', '0', '309', '3');
INSERT INTO `mny_address` VALUES ('2971', '巧家县', '1', '0', '309', '3');
INSERT INTO `mny_address` VALUES ('2972', '盐津县', '1', '0', '309', '3');
INSERT INTO `mny_address` VALUES ('2973', '大关县', '1', '0', '309', '3');
INSERT INTO `mny_address` VALUES ('2974', '永善县', '1', '0', '309', '3');
INSERT INTO `mny_address` VALUES ('2975', '绥江县', '1', '0', '309', '3');
INSERT INTO `mny_address` VALUES ('2976', '镇雄县', '1', '0', '309', '3');
INSERT INTO `mny_address` VALUES ('2977', '彝良县', '1', '0', '309', '3');
INSERT INTO `mny_address` VALUES ('2978', '威信县', '1', '0', '309', '3');
INSERT INTO `mny_address` VALUES ('2979', '水富县', '1', '0', '309', '3');
INSERT INTO `mny_address` VALUES ('2980', '市辖区', '1', '0', '310', '3');
INSERT INTO `mny_address` VALUES ('2981', '古城区', '1', '0', '310', '3');
INSERT INTO `mny_address` VALUES ('2982', '玉龙纳西族自治县', '1', '0', '310', '3');
INSERT INTO `mny_address` VALUES ('2983', '永胜县', '1', '0', '310', '3');
INSERT INTO `mny_address` VALUES ('2984', '华坪县', '1', '0', '310', '3');
INSERT INTO `mny_address` VALUES ('2985', '宁蒗彝族自治县', '1', '0', '310', '3');
INSERT INTO `mny_address` VALUES ('2986', '市辖区', '1', '0', '311', '3');
INSERT INTO `mny_address` VALUES ('2987', '翠云区', '1', '0', '311', '3');
INSERT INTO `mny_address` VALUES ('2988', '普洱哈尼族彝族自治县', '1', '0', '311', '3');
INSERT INTO `mny_address` VALUES ('2989', '墨江哈尼族自治县', '1', '0', '311', '3');
INSERT INTO `mny_address` VALUES ('2990', '景东彝族自治县', '1', '0', '311', '3');
INSERT INTO `mny_address` VALUES ('2991', '景谷傣族彝族自治县', '1', '0', '311', '3');
INSERT INTO `mny_address` VALUES ('2992', '镇沅彝族哈尼族拉祜族自治县', '1', '0', '311', '3');
INSERT INTO `mny_address` VALUES ('2993', '江城哈尼族彝族自治县', '1', '0', '311', '3');
INSERT INTO `mny_address` VALUES ('2994', '孟连傣族拉祜族佤族自治县', '1', '0', '311', '3');
INSERT INTO `mny_address` VALUES ('2995', '澜沧拉祜族自治县', '1', '0', '311', '3');
INSERT INTO `mny_address` VALUES ('2996', '西盟佤族自治县', '1', '0', '311', '3');
INSERT INTO `mny_address` VALUES ('2997', '市辖区', '1', '0', '312', '3');
INSERT INTO `mny_address` VALUES ('2998', '临翔区', '1', '0', '312', '3');
INSERT INTO `mny_address` VALUES ('2999', '凤庆县', '1', '0', '312', '3');
INSERT INTO `mny_address` VALUES ('3000', '云　县', '1', '0', '312', '3');
INSERT INTO `mny_address` VALUES ('3001', '永德县', '1', '0', '312', '3');
INSERT INTO `mny_address` VALUES ('3002', '镇康县', '1', '0', '312', '3');
INSERT INTO `mny_address` VALUES ('3003', '双江拉祜族佤族布朗族傣族自治县', '1', '0', '312', '3');
INSERT INTO `mny_address` VALUES ('3004', '耿马傣族佤族自治县', '1', '0', '312', '3');
INSERT INTO `mny_address` VALUES ('3005', '沧源佤族自治县', '1', '0', '312', '3');
INSERT INTO `mny_address` VALUES ('3006', '楚雄市', '1', '0', '313', '3');
INSERT INTO `mny_address` VALUES ('3007', '双柏县', '1', '0', '313', '3');
INSERT INTO `mny_address` VALUES ('3008', '牟定县', '1', '0', '313', '3');
INSERT INTO `mny_address` VALUES ('3009', '南华县', '1', '0', '313', '3');
INSERT INTO `mny_address` VALUES ('3010', '姚安县', '1', '0', '313', '3');
INSERT INTO `mny_address` VALUES ('3011', '大姚县', '1', '0', '313', '3');
INSERT INTO `mny_address` VALUES ('3012', '永仁县', '1', '0', '313', '3');
INSERT INTO `mny_address` VALUES ('3013', '元谋县', '1', '0', '313', '3');
INSERT INTO `mny_address` VALUES ('3014', '武定县', '1', '0', '313', '3');
INSERT INTO `mny_address` VALUES ('3015', '禄丰县', '1', '0', '313', '3');
INSERT INTO `mny_address` VALUES ('3016', '个旧市', '1', '0', '314', '3');
INSERT INTO `mny_address` VALUES ('3017', '开远市', '1', '0', '314', '3');
INSERT INTO `mny_address` VALUES ('3018', '蒙自县', '1', '0', '314', '3');
INSERT INTO `mny_address` VALUES ('3019', '屏边苗族自治县', '1', '0', '314', '3');
INSERT INTO `mny_address` VALUES ('3020', '建水县', '1', '0', '314', '3');
INSERT INTO `mny_address` VALUES ('3021', '石屏县', '1', '0', '314', '3');
INSERT INTO `mny_address` VALUES ('3022', '弥勒县', '1', '0', '314', '3');
INSERT INTO `mny_address` VALUES ('3023', '泸西县', '1', '0', '314', '3');
INSERT INTO `mny_address` VALUES ('3024', '元阳县', '1', '0', '314', '3');
INSERT INTO `mny_address` VALUES ('3025', '红河县', '1', '0', '314', '3');
INSERT INTO `mny_address` VALUES ('3026', '金平苗族瑶族傣族自治县', '1', '0', '314', '3');
INSERT INTO `mny_address` VALUES ('3027', '绿春县', '1', '0', '314', '3');
INSERT INTO `mny_address` VALUES ('3028', '河口瑶族自治县', '1', '0', '314', '3');
INSERT INTO `mny_address` VALUES ('3029', '文山县', '1', '0', '315', '3');
INSERT INTO `mny_address` VALUES ('3030', '砚山县', '1', '0', '315', '3');
INSERT INTO `mny_address` VALUES ('3031', '西畴县', '1', '0', '315', '3');
INSERT INTO `mny_address` VALUES ('3032', '麻栗坡县', '1', '0', '315', '3');
INSERT INTO `mny_address` VALUES ('3033', '马关县', '1', '0', '315', '3');
INSERT INTO `mny_address` VALUES ('3034', '丘北县', '1', '0', '315', '3');
INSERT INTO `mny_address` VALUES ('3035', '广南县', '1', '0', '315', '3');
INSERT INTO `mny_address` VALUES ('3036', '富宁县', '1', '0', '315', '3');
INSERT INTO `mny_address` VALUES ('3037', '景洪市', '1', '0', '316', '3');
INSERT INTO `mny_address` VALUES ('3038', '勐海县', '1', '0', '316', '3');
INSERT INTO `mny_address` VALUES ('3039', '勐腊县', '1', '0', '316', '3');
INSERT INTO `mny_address` VALUES ('3040', '大理市', '1', '0', '317', '3');
INSERT INTO `mny_address` VALUES ('3041', '漾濞彝族自治县', '1', '0', '317', '3');
INSERT INTO `mny_address` VALUES ('3042', '祥云县', '1', '0', '317', '3');
INSERT INTO `mny_address` VALUES ('3043', '宾川县', '1', '0', '317', '3');
INSERT INTO `mny_address` VALUES ('3044', '弥渡县', '1', '0', '317', '3');
INSERT INTO `mny_address` VALUES ('3045', '南涧彝族自治县', '1', '0', '317', '3');
INSERT INTO `mny_address` VALUES ('3046', '巍山彝族回族自治县', '1', '0', '317', '3');
INSERT INTO `mny_address` VALUES ('3047', '永平县', '1', '0', '317', '3');
INSERT INTO `mny_address` VALUES ('3048', '云龙县', '1', '0', '317', '3');
INSERT INTO `mny_address` VALUES ('3049', '洱源县', '1', '0', '317', '3');
INSERT INTO `mny_address` VALUES ('3050', '剑川县', '1', '0', '317', '3');
INSERT INTO `mny_address` VALUES ('3051', '鹤庆县', '1', '0', '317', '3');
INSERT INTO `mny_address` VALUES ('3052', '瑞丽市', '1', '0', '318', '3');
INSERT INTO `mny_address` VALUES ('3053', '潞西市', '1', '0', '318', '3');
INSERT INTO `mny_address` VALUES ('3054', '梁河县', '1', '0', '318', '3');
INSERT INTO `mny_address` VALUES ('3055', '盈江县', '1', '0', '318', '3');
INSERT INTO `mny_address` VALUES ('3056', '陇川县', '1', '0', '318', '3');
INSERT INTO `mny_address` VALUES ('3057', '泸水县', '1', '0', '319', '3');
INSERT INTO `mny_address` VALUES ('3058', '福贡县', '1', '0', '319', '3');
INSERT INTO `mny_address` VALUES ('3059', '贡山独龙族怒族自治县', '1', '0', '319', '3');
INSERT INTO `mny_address` VALUES ('3060', '兰坪白族普米族自治县', '1', '0', '319', '3');
INSERT INTO `mny_address` VALUES ('3061', '香格里拉县', '1', '0', '320', '3');
INSERT INTO `mny_address` VALUES ('3062', '德钦县', '1', '0', '320', '3');
INSERT INTO `mny_address` VALUES ('3063', '维西傈僳族自治县', '1', '0', '320', '3');
INSERT INTO `mny_address` VALUES ('3064', '市辖区', '1', '0', '321', '3');
INSERT INTO `mny_address` VALUES ('3065', '城关区', '1', '0', '321', '3');
INSERT INTO `mny_address` VALUES ('3066', '林周县', '1', '0', '321', '3');
INSERT INTO `mny_address` VALUES ('3067', '当雄县', '1', '0', '321', '3');
INSERT INTO `mny_address` VALUES ('3068', '尼木县', '1', '0', '321', '3');
INSERT INTO `mny_address` VALUES ('3069', '曲水县', '1', '0', '321', '3');
INSERT INTO `mny_address` VALUES ('3070', '堆龙德庆县', '1', '0', '321', '3');
INSERT INTO `mny_address` VALUES ('3071', '达孜县', '1', '0', '321', '3');
INSERT INTO `mny_address` VALUES ('3072', '墨竹工卡县', '1', '0', '321', '3');
INSERT INTO `mny_address` VALUES ('3073', '昌都县', '1', '0', '322', '3');
INSERT INTO `mny_address` VALUES ('3074', '江达县', '1', '0', '322', '3');
INSERT INTO `mny_address` VALUES ('3075', '贡觉县', '1', '0', '322', '3');
INSERT INTO `mny_address` VALUES ('3076', '类乌齐县', '1', '0', '322', '3');
INSERT INTO `mny_address` VALUES ('3077', '丁青县', '1', '0', '322', '3');
INSERT INTO `mny_address` VALUES ('3078', '察雅县', '1', '0', '322', '3');
INSERT INTO `mny_address` VALUES ('3079', '八宿县', '1', '0', '322', '3');
INSERT INTO `mny_address` VALUES ('3080', '左贡县', '1', '0', '322', '3');
INSERT INTO `mny_address` VALUES ('3081', '芒康县', '1', '0', '322', '3');
INSERT INTO `mny_address` VALUES ('3082', '洛隆县', '1', '0', '322', '3');
INSERT INTO `mny_address` VALUES ('3083', '边坝县', '1', '0', '322', '3');
INSERT INTO `mny_address` VALUES ('3084', '乃东县', '1', '0', '323', '3');
INSERT INTO `mny_address` VALUES ('3085', '扎囊县', '1', '0', '323', '3');
INSERT INTO `mny_address` VALUES ('3086', '贡嘎县', '1', '0', '323', '3');
INSERT INTO `mny_address` VALUES ('3087', '桑日县', '1', '0', '323', '3');
INSERT INTO `mny_address` VALUES ('3088', '琼结县', '1', '0', '323', '3');
INSERT INTO `mny_address` VALUES ('3089', '曲松县', '1', '0', '323', '3');
INSERT INTO `mny_address` VALUES ('3090', '措美县', '1', '0', '323', '3');
INSERT INTO `mny_address` VALUES ('3091', '洛扎县', '1', '0', '323', '3');
INSERT INTO `mny_address` VALUES ('3092', '加查县', '1', '0', '323', '3');
INSERT INTO `mny_address` VALUES ('3093', '隆子县', '1', '0', '323', '3');
INSERT INTO `mny_address` VALUES ('3094', '错那县', '1', '0', '323', '3');
INSERT INTO `mny_address` VALUES ('3095', '浪卡子县', '1', '0', '323', '3');
INSERT INTO `mny_address` VALUES ('3096', '日喀则市', '1', '0', '324', '3');
INSERT INTO `mny_address` VALUES ('3097', '南木林县', '1', '0', '324', '3');
INSERT INTO `mny_address` VALUES ('3098', '江孜县', '1', '0', '324', '3');
INSERT INTO `mny_address` VALUES ('3099', '定日县', '1', '0', '324', '3');
INSERT INTO `mny_address` VALUES ('3100', '萨迦县', '1', '0', '324', '3');
INSERT INTO `mny_address` VALUES ('3101', '拉孜县', '1', '0', '324', '3');
INSERT INTO `mny_address` VALUES ('3102', '昂仁县', '1', '0', '324', '3');
INSERT INTO `mny_address` VALUES ('3103', '谢通门县', '1', '0', '324', '3');
INSERT INTO `mny_address` VALUES ('3104', '白朗县', '1', '0', '324', '3');
INSERT INTO `mny_address` VALUES ('3105', '仁布县', '1', '0', '324', '3');
INSERT INTO `mny_address` VALUES ('3106', '康马县', '1', '0', '324', '3');
INSERT INTO `mny_address` VALUES ('3107', '定结县', '1', '0', '324', '3');
INSERT INTO `mny_address` VALUES ('3108', '仲巴县', '1', '0', '324', '3');
INSERT INTO `mny_address` VALUES ('3109', '亚东县', '1', '0', '324', '3');
INSERT INTO `mny_address` VALUES ('3110', '吉隆县', '1', '0', '324', '3');
INSERT INTO `mny_address` VALUES ('3111', '聂拉木县', '1', '0', '324', '3');
INSERT INTO `mny_address` VALUES ('3112', '萨嘎县', '1', '0', '324', '3');
INSERT INTO `mny_address` VALUES ('3113', '岗巴县', '1', '0', '324', '3');
INSERT INTO `mny_address` VALUES ('3114', '那曲县', '1', '0', '325', '3');
INSERT INTO `mny_address` VALUES ('3115', '嘉黎县', '1', '0', '325', '3');
INSERT INTO `mny_address` VALUES ('3116', '比如县', '1', '0', '325', '3');
INSERT INTO `mny_address` VALUES ('3117', '聂荣县', '1', '0', '325', '3');
INSERT INTO `mny_address` VALUES ('3118', '安多县', '1', '0', '325', '3');
INSERT INTO `mny_address` VALUES ('3119', '申扎县', '1', '0', '325', '3');
INSERT INTO `mny_address` VALUES ('3120', '索　县', '1', '0', '325', '3');
INSERT INTO `mny_address` VALUES ('3121', '班戈县', '1', '0', '325', '3');
INSERT INTO `mny_address` VALUES ('3122', '巴青县', '1', '0', '325', '3');
INSERT INTO `mny_address` VALUES ('3123', '尼玛县', '1', '0', '325', '3');
INSERT INTO `mny_address` VALUES ('3124', '普兰县', '1', '0', '326', '3');
INSERT INTO `mny_address` VALUES ('3125', '札达县', '1', '0', '326', '3');
INSERT INTO `mny_address` VALUES ('3126', '噶尔县', '1', '0', '326', '3');
INSERT INTO `mny_address` VALUES ('3127', '日土县', '1', '0', '326', '3');
INSERT INTO `mny_address` VALUES ('3128', '革吉县', '1', '0', '326', '3');
INSERT INTO `mny_address` VALUES ('3129', '改则县', '1', '0', '326', '3');
INSERT INTO `mny_address` VALUES ('3130', '措勤县', '1', '0', '326', '3');
INSERT INTO `mny_address` VALUES ('3131', '林芝县', '1', '0', '327', '3');
INSERT INTO `mny_address` VALUES ('3132', '工布江达县', '1', '0', '327', '3');
INSERT INTO `mny_address` VALUES ('3133', '米林县', '1', '0', '327', '3');
INSERT INTO `mny_address` VALUES ('3134', '墨脱县', '1', '0', '327', '3');
INSERT INTO `mny_address` VALUES ('3135', '波密县', '1', '0', '327', '3');
INSERT INTO `mny_address` VALUES ('3136', '察隅县', '1', '0', '327', '3');
INSERT INTO `mny_address` VALUES ('3137', '朗　县', '1', '0', '327', '3');
INSERT INTO `mny_address` VALUES ('3138', '市辖区', '1', '0', '328', '3');
INSERT INTO `mny_address` VALUES ('3139', '新城区', '1', '0', '328', '3');
INSERT INTO `mny_address` VALUES ('3140', '碑林区', '1', '0', '328', '3');
INSERT INTO `mny_address` VALUES ('3141', '莲湖区', '1', '0', '328', '3');
INSERT INTO `mny_address` VALUES ('3142', '灞桥区', '1', '0', '328', '3');
INSERT INTO `mny_address` VALUES ('3143', '未央区', '1', '0', '328', '3');
INSERT INTO `mny_address` VALUES ('3144', '雁塔区', '1', '0', '328', '3');
INSERT INTO `mny_address` VALUES ('3145', '阎良区', '1', '0', '328', '3');
INSERT INTO `mny_address` VALUES ('3146', '临潼区', '1', '0', '328', '3');
INSERT INTO `mny_address` VALUES ('3147', '长安区', '1', '0', '328', '3');
INSERT INTO `mny_address` VALUES ('3148', '蓝田县', '1', '0', '328', '3');
INSERT INTO `mny_address` VALUES ('3149', '周至县', '1', '0', '328', '3');
INSERT INTO `mny_address` VALUES ('3150', '户　县', '1', '0', '328', '3');
INSERT INTO `mny_address` VALUES ('3151', '高陵县', '1', '0', '328', '3');
INSERT INTO `mny_address` VALUES ('3152', '市辖区', '1', '0', '329', '3');
INSERT INTO `mny_address` VALUES ('3153', '王益区', '1', '0', '329', '3');
INSERT INTO `mny_address` VALUES ('3154', '印台区', '1', '0', '329', '3');
INSERT INTO `mny_address` VALUES ('3155', '耀州区', '1', '0', '329', '3');
INSERT INTO `mny_address` VALUES ('3156', '宜君县', '1', '0', '329', '3');
INSERT INTO `mny_address` VALUES ('3157', '市辖区', '1', '0', '330', '3');
INSERT INTO `mny_address` VALUES ('3158', '渭滨区', '1', '0', '330', '3');
INSERT INTO `mny_address` VALUES ('3159', '金台区', '1', '0', '330', '3');
INSERT INTO `mny_address` VALUES ('3160', '陈仓区', '1', '0', '330', '3');
INSERT INTO `mny_address` VALUES ('3161', '凤翔县', '1', '0', '330', '3');
INSERT INTO `mny_address` VALUES ('3162', '岐山县', '1', '0', '330', '3');
INSERT INTO `mny_address` VALUES ('3163', '扶风县', '1', '0', '330', '3');
INSERT INTO `mny_address` VALUES ('3164', '眉　县', '1', '0', '330', '3');
INSERT INTO `mny_address` VALUES ('3165', '陇　县', '1', '0', '330', '3');
INSERT INTO `mny_address` VALUES ('3166', '千阳县', '1', '0', '330', '3');
INSERT INTO `mny_address` VALUES ('3167', '麟游县', '1', '0', '330', '3');
INSERT INTO `mny_address` VALUES ('3168', '凤　县', '1', '0', '330', '3');
INSERT INTO `mny_address` VALUES ('3169', '太白县', '1', '0', '330', '3');
INSERT INTO `mny_address` VALUES ('3170', '市辖区', '1', '0', '331', '3');
INSERT INTO `mny_address` VALUES ('3171', '秦都区', '1', '0', '331', '3');
INSERT INTO `mny_address` VALUES ('3172', '杨凌区', '1', '0', '331', '3');
INSERT INTO `mny_address` VALUES ('3173', '渭城区', '1', '0', '331', '3');
INSERT INTO `mny_address` VALUES ('3174', '三原县', '1', '0', '331', '3');
INSERT INTO `mny_address` VALUES ('3175', '泾阳县', '1', '0', '331', '3');
INSERT INTO `mny_address` VALUES ('3176', '乾　县', '1', '0', '331', '3');
INSERT INTO `mny_address` VALUES ('3177', '礼泉县', '1', '0', '331', '3');
INSERT INTO `mny_address` VALUES ('3178', '永寿县', '1', '0', '331', '3');
INSERT INTO `mny_address` VALUES ('3179', '彬　县', '1', '0', '331', '3');
INSERT INTO `mny_address` VALUES ('3180', '长武县', '1', '0', '331', '3');
INSERT INTO `mny_address` VALUES ('3181', '旬邑县', '1', '0', '331', '3');
INSERT INTO `mny_address` VALUES ('3182', '淳化县', '1', '0', '331', '3');
INSERT INTO `mny_address` VALUES ('3183', '武功县', '1', '0', '331', '3');
INSERT INTO `mny_address` VALUES ('3184', '兴平市', '1', '0', '331', '3');
INSERT INTO `mny_address` VALUES ('3185', '市辖区', '1', '0', '332', '3');
INSERT INTO `mny_address` VALUES ('3186', '临渭区', '1', '0', '332', '3');
INSERT INTO `mny_address` VALUES ('3187', '华　县', '1', '0', '332', '3');
INSERT INTO `mny_address` VALUES ('3188', '潼关县', '1', '0', '332', '3');
INSERT INTO `mny_address` VALUES ('3189', '大荔县', '1', '0', '332', '3');
INSERT INTO `mny_address` VALUES ('3190', '合阳县', '1', '0', '332', '3');
INSERT INTO `mny_address` VALUES ('3191', '澄城县', '1', '0', '332', '3');
INSERT INTO `mny_address` VALUES ('3192', '蒲城县', '1', '0', '332', '3');
INSERT INTO `mny_address` VALUES ('3193', '白水县', '1', '0', '332', '3');
INSERT INTO `mny_address` VALUES ('3194', '富平县', '1', '0', '332', '3');
INSERT INTO `mny_address` VALUES ('3195', '韩城市', '1', '0', '332', '3');
INSERT INTO `mny_address` VALUES ('3196', '华阴市', '1', '0', '332', '3');
INSERT INTO `mny_address` VALUES ('3197', '市辖区', '1', '0', '333', '3');
INSERT INTO `mny_address` VALUES ('3198', '宝塔区', '1', '0', '333', '3');
INSERT INTO `mny_address` VALUES ('3199', '延长县', '1', '0', '333', '3');
INSERT INTO `mny_address` VALUES ('3200', '延川县', '1', '0', '333', '3');
INSERT INTO `mny_address` VALUES ('3201', '子长县', '1', '0', '333', '3');
INSERT INTO `mny_address` VALUES ('3202', '安塞县', '1', '0', '333', '3');
INSERT INTO `mny_address` VALUES ('3203', '志丹县', '1', '0', '333', '3');
INSERT INTO `mny_address` VALUES ('3204', '吴旗县', '1', '0', '333', '3');
INSERT INTO `mny_address` VALUES ('3205', '甘泉县', '1', '0', '333', '3');
INSERT INTO `mny_address` VALUES ('3206', '富　县', '1', '0', '333', '3');
INSERT INTO `mny_address` VALUES ('3207', '洛川县', '1', '0', '333', '3');
INSERT INTO `mny_address` VALUES ('3208', '宜川县', '1', '0', '333', '3');
INSERT INTO `mny_address` VALUES ('3209', '黄龙县', '1', '0', '333', '3');
INSERT INTO `mny_address` VALUES ('3210', '黄陵县', '1', '0', '333', '3');
INSERT INTO `mny_address` VALUES ('3211', '市辖区', '1', '0', '334', '3');
INSERT INTO `mny_address` VALUES ('3212', '汉台区', '1', '0', '334', '3');
INSERT INTO `mny_address` VALUES ('3213', '南郑县', '1', '0', '334', '3');
INSERT INTO `mny_address` VALUES ('3214', '城固县', '1', '0', '334', '3');
INSERT INTO `mny_address` VALUES ('3215', '洋　县', '1', '0', '334', '3');
INSERT INTO `mny_address` VALUES ('3216', '西乡县', '1', '0', '334', '3');
INSERT INTO `mny_address` VALUES ('3217', '勉　县', '1', '0', '334', '3');
INSERT INTO `mny_address` VALUES ('3218', '宁强县', '1', '0', '334', '3');
INSERT INTO `mny_address` VALUES ('3219', '略阳县', '1', '0', '334', '3');
INSERT INTO `mny_address` VALUES ('3220', '镇巴县', '1', '0', '334', '3');
INSERT INTO `mny_address` VALUES ('3221', '留坝县', '1', '0', '334', '3');
INSERT INTO `mny_address` VALUES ('3222', '佛坪县', '1', '0', '334', '3');
INSERT INTO `mny_address` VALUES ('3223', '市辖区', '1', '0', '335', '3');
INSERT INTO `mny_address` VALUES ('3224', '榆阳区', '1', '0', '335', '3');
INSERT INTO `mny_address` VALUES ('3225', '神木县', '1', '0', '335', '3');
INSERT INTO `mny_address` VALUES ('3226', '府谷县', '1', '0', '335', '3');
INSERT INTO `mny_address` VALUES ('3227', '横山县', '1', '0', '335', '3');
INSERT INTO `mny_address` VALUES ('3228', '靖边县', '1', '0', '335', '3');
INSERT INTO `mny_address` VALUES ('3229', '定边县', '1', '0', '335', '3');
INSERT INTO `mny_address` VALUES ('3230', '绥德县', '1', '0', '335', '3');
INSERT INTO `mny_address` VALUES ('3231', '米脂县', '1', '0', '335', '3');
INSERT INTO `mny_address` VALUES ('3232', '佳　县', '1', '0', '335', '3');
INSERT INTO `mny_address` VALUES ('3233', '吴堡县', '1', '0', '335', '3');
INSERT INTO `mny_address` VALUES ('3234', '清涧县', '1', '0', '335', '3');
INSERT INTO `mny_address` VALUES ('3235', '子洲县', '1', '0', '335', '3');
INSERT INTO `mny_address` VALUES ('3236', '市辖区', '1', '0', '336', '3');
INSERT INTO `mny_address` VALUES ('3237', '汉滨区', '1', '0', '336', '3');
INSERT INTO `mny_address` VALUES ('3238', '汉阴县', '1', '0', '336', '3');
INSERT INTO `mny_address` VALUES ('3239', '石泉县', '1', '0', '336', '3');
INSERT INTO `mny_address` VALUES ('3240', '宁陕县', '1', '0', '336', '3');
INSERT INTO `mny_address` VALUES ('3241', '紫阳县', '1', '0', '336', '3');
INSERT INTO `mny_address` VALUES ('3242', '岚皋县', '1', '0', '336', '3');
INSERT INTO `mny_address` VALUES ('3243', '平利县', '1', '0', '336', '3');
INSERT INTO `mny_address` VALUES ('3244', '镇坪县', '1', '0', '336', '3');
INSERT INTO `mny_address` VALUES ('3245', '旬阳县', '1', '0', '336', '3');
INSERT INTO `mny_address` VALUES ('3246', '白河县', '1', '0', '336', '3');
INSERT INTO `mny_address` VALUES ('3247', '市辖区', '1', '0', '337', '3');
INSERT INTO `mny_address` VALUES ('3248', '商州区', '1', '0', '337', '3');
INSERT INTO `mny_address` VALUES ('3249', '洛南县', '1', '0', '337', '3');
INSERT INTO `mny_address` VALUES ('3250', '丹凤县', '1', '0', '337', '3');
INSERT INTO `mny_address` VALUES ('3251', '商南县', '1', '0', '337', '3');
INSERT INTO `mny_address` VALUES ('3252', '山阳县', '1', '0', '337', '3');
INSERT INTO `mny_address` VALUES ('3253', '镇安县', '1', '0', '337', '3');
INSERT INTO `mny_address` VALUES ('3254', '柞水县', '1', '0', '337', '3');
INSERT INTO `mny_address` VALUES ('3255', '市辖区', '1', '0', '338', '3');
INSERT INTO `mny_address` VALUES ('3256', '城关区', '1', '0', '338', '3');
INSERT INTO `mny_address` VALUES ('3257', '七里河区', '1', '0', '338', '3');
INSERT INTO `mny_address` VALUES ('3258', '西固区', '1', '0', '338', '3');
INSERT INTO `mny_address` VALUES ('3259', '安宁区', '1', '0', '338', '3');
INSERT INTO `mny_address` VALUES ('3260', '红古区', '1', '0', '338', '3');
INSERT INTO `mny_address` VALUES ('3261', '永登县', '1', '0', '338', '3');
INSERT INTO `mny_address` VALUES ('3262', '皋兰县', '1', '0', '338', '3');
INSERT INTO `mny_address` VALUES ('3263', '榆中县', '1', '0', '338', '3');
INSERT INTO `mny_address` VALUES ('3264', '市辖区', '1', '0', '339', '3');
INSERT INTO `mny_address` VALUES ('3265', '市辖区', '1', '0', '340', '3');
INSERT INTO `mny_address` VALUES ('3266', '金川区', '1', '0', '340', '3');
INSERT INTO `mny_address` VALUES ('3267', '永昌县', '1', '0', '340', '3');
INSERT INTO `mny_address` VALUES ('3268', '市辖区', '1', '0', '341', '3');
INSERT INTO `mny_address` VALUES ('3269', '白银区', '1', '0', '341', '3');
INSERT INTO `mny_address` VALUES ('3270', '平川区', '1', '0', '341', '3');
INSERT INTO `mny_address` VALUES ('3271', '靖远县', '1', '0', '341', '3');
INSERT INTO `mny_address` VALUES ('3272', '会宁县', '1', '0', '341', '3');
INSERT INTO `mny_address` VALUES ('3273', '景泰县', '1', '0', '341', '3');
INSERT INTO `mny_address` VALUES ('3274', '市辖区', '1', '0', '342', '3');
INSERT INTO `mny_address` VALUES ('3275', '秦城区', '1', '0', '342', '3');
INSERT INTO `mny_address` VALUES ('3276', '北道区', '1', '0', '342', '3');
INSERT INTO `mny_address` VALUES ('3277', '清水县', '1', '0', '342', '3');
INSERT INTO `mny_address` VALUES ('3278', '秦安县', '1', '0', '342', '3');
INSERT INTO `mny_address` VALUES ('3279', '甘谷县', '1', '0', '342', '3');
INSERT INTO `mny_address` VALUES ('3280', '武山县', '1', '0', '342', '3');
INSERT INTO `mny_address` VALUES ('3281', '张家川回族自治县', '1', '0', '342', '3');
INSERT INTO `mny_address` VALUES ('3282', '市辖区', '1', '0', '343', '3');
INSERT INTO `mny_address` VALUES ('3283', '凉州区', '1', '0', '343', '3');
INSERT INTO `mny_address` VALUES ('3284', '民勤县', '1', '0', '343', '3');
INSERT INTO `mny_address` VALUES ('3285', '古浪县', '1', '0', '343', '3');
INSERT INTO `mny_address` VALUES ('3286', '天祝藏族自治县', '1', '0', '343', '3');
INSERT INTO `mny_address` VALUES ('3287', '市辖区', '1', '0', '344', '3');
INSERT INTO `mny_address` VALUES ('3288', '甘州区', '1', '0', '344', '3');
INSERT INTO `mny_address` VALUES ('3289', '肃南裕固族自治县', '1', '0', '344', '3');
INSERT INTO `mny_address` VALUES ('3290', '民乐县', '1', '0', '344', '3');
INSERT INTO `mny_address` VALUES ('3291', '临泽县', '1', '0', '344', '3');
INSERT INTO `mny_address` VALUES ('3292', '高台县', '1', '0', '344', '3');
INSERT INTO `mny_address` VALUES ('3293', '山丹县', '1', '0', '344', '3');
INSERT INTO `mny_address` VALUES ('3294', '市辖区', '1', '0', '345', '3');
INSERT INTO `mny_address` VALUES ('3295', '崆峒区', '1', '0', '345', '3');
INSERT INTO `mny_address` VALUES ('3296', '泾川县', '1', '0', '345', '3');
INSERT INTO `mny_address` VALUES ('3297', '灵台县', '1', '0', '345', '3');
INSERT INTO `mny_address` VALUES ('3298', '崇信县', '1', '0', '345', '3');
INSERT INTO `mny_address` VALUES ('3299', '华亭县', '1', '0', '345', '3');
INSERT INTO `mny_address` VALUES ('3300', '庄浪县', '1', '0', '345', '3');
INSERT INTO `mny_address` VALUES ('3301', '静宁县', '1', '0', '345', '3');
INSERT INTO `mny_address` VALUES ('3302', '市辖区', '1', '0', '346', '3');
INSERT INTO `mny_address` VALUES ('3303', '肃州区', '1', '0', '346', '3');
INSERT INTO `mny_address` VALUES ('3304', '金塔县', '1', '0', '346', '3');
INSERT INTO `mny_address` VALUES ('3305', '安西县', '1', '0', '346', '3');
INSERT INTO `mny_address` VALUES ('3306', '肃北蒙古族自治县', '1', '0', '346', '3');
INSERT INTO `mny_address` VALUES ('3307', '阿克塞哈萨克族自治县', '1', '0', '346', '3');
INSERT INTO `mny_address` VALUES ('3308', '玉门市', '1', '0', '346', '3');
INSERT INTO `mny_address` VALUES ('3309', '敦煌市', '1', '0', '346', '3');
INSERT INTO `mny_address` VALUES ('3310', '市辖区', '1', '0', '347', '3');
INSERT INTO `mny_address` VALUES ('3311', '西峰区', '1', '0', '347', '3');
INSERT INTO `mny_address` VALUES ('3312', '庆城县', '1', '0', '347', '3');
INSERT INTO `mny_address` VALUES ('3313', '环　县', '1', '0', '347', '3');
INSERT INTO `mny_address` VALUES ('3314', '华池县', '1', '0', '347', '3');
INSERT INTO `mny_address` VALUES ('3315', '合水县', '1', '0', '347', '3');
INSERT INTO `mny_address` VALUES ('3316', '正宁县', '1', '0', '347', '3');
INSERT INTO `mny_address` VALUES ('3317', '宁　县', '1', '0', '347', '3');
INSERT INTO `mny_address` VALUES ('3318', '镇原县', '1', '0', '347', '3');
INSERT INTO `mny_address` VALUES ('3319', '市辖区', '1', '0', '348', '3');
INSERT INTO `mny_address` VALUES ('3320', '安定区', '1', '0', '348', '3');
INSERT INTO `mny_address` VALUES ('3321', '通渭县', '1', '0', '348', '3');
INSERT INTO `mny_address` VALUES ('3322', '陇西县', '1', '0', '348', '3');
INSERT INTO `mny_address` VALUES ('3323', '渭源县', '1', '0', '348', '3');
INSERT INTO `mny_address` VALUES ('3324', '临洮县', '1', '0', '348', '3');
INSERT INTO `mny_address` VALUES ('3325', '漳　县', '1', '0', '348', '3');
INSERT INTO `mny_address` VALUES ('3326', '岷　县', '1', '0', '348', '3');
INSERT INTO `mny_address` VALUES ('3327', '市辖区', '1', '0', '349', '3');
INSERT INTO `mny_address` VALUES ('3328', '武都区', '1', '0', '349', '3');
INSERT INTO `mny_address` VALUES ('3329', '成　县', '1', '0', '349', '3');
INSERT INTO `mny_address` VALUES ('3330', '文　县', '1', '0', '349', '3');
INSERT INTO `mny_address` VALUES ('3331', '宕昌县', '1', '0', '349', '3');
INSERT INTO `mny_address` VALUES ('3332', '康　县', '1', '0', '349', '3');
INSERT INTO `mny_address` VALUES ('3333', '西和县', '1', '0', '349', '3');
INSERT INTO `mny_address` VALUES ('3334', '礼　县', '1', '0', '349', '3');
INSERT INTO `mny_address` VALUES ('3335', '徽　县', '1', '0', '349', '3');
INSERT INTO `mny_address` VALUES ('3336', '两当县', '1', '0', '349', '3');
INSERT INTO `mny_address` VALUES ('3337', '临夏市', '1', '0', '350', '3');
INSERT INTO `mny_address` VALUES ('3338', '临夏县', '1', '0', '350', '3');
INSERT INTO `mny_address` VALUES ('3339', '康乐县', '1', '0', '350', '3');
INSERT INTO `mny_address` VALUES ('3340', '永靖县', '1', '0', '350', '3');
INSERT INTO `mny_address` VALUES ('3341', '广河县', '1', '0', '350', '3');
INSERT INTO `mny_address` VALUES ('3342', '和政县', '1', '0', '350', '3');
INSERT INTO `mny_address` VALUES ('3343', '东乡族自治县', '1', '0', '350', '3');
INSERT INTO `mny_address` VALUES ('3344', '积石山保安族东乡族撒拉族自治县', '1', '0', '350', '3');
INSERT INTO `mny_address` VALUES ('3345', '合作市', '1', '0', '351', '3');
INSERT INTO `mny_address` VALUES ('3346', '临潭县', '1', '0', '351', '3');
INSERT INTO `mny_address` VALUES ('3347', '卓尼县', '1', '0', '351', '3');
INSERT INTO `mny_address` VALUES ('3348', '舟曲县', '1', '0', '351', '3');
INSERT INTO `mny_address` VALUES ('3349', '迭部县', '1', '0', '351', '3');
INSERT INTO `mny_address` VALUES ('3350', '玛曲县', '1', '0', '351', '3');
INSERT INTO `mny_address` VALUES ('3351', '碌曲县', '1', '0', '351', '3');
INSERT INTO `mny_address` VALUES ('3352', '夏河县', '1', '0', '351', '3');
INSERT INTO `mny_address` VALUES ('3353', '市辖区', '1', '0', '352', '3');
INSERT INTO `mny_address` VALUES ('3354', '城东区', '1', '0', '352', '3');
INSERT INTO `mny_address` VALUES ('3355', '城中区', '1', '0', '352', '3');
INSERT INTO `mny_address` VALUES ('3356', '城西区', '1', '0', '352', '3');
INSERT INTO `mny_address` VALUES ('3357', '城北区', '1', '0', '352', '3');
INSERT INTO `mny_address` VALUES ('3358', '大通回族土族自治县', '1', '0', '352', '3');
INSERT INTO `mny_address` VALUES ('3359', '湟中县', '1', '0', '352', '3');
INSERT INTO `mny_address` VALUES ('3360', '湟源县', '1', '0', '352', '3');
INSERT INTO `mny_address` VALUES ('3361', '平安县', '1', '0', '353', '3');
INSERT INTO `mny_address` VALUES ('3362', '民和回族土族自治县', '1', '0', '353', '3');
INSERT INTO `mny_address` VALUES ('3363', '乐都县', '1', '0', '353', '3');
INSERT INTO `mny_address` VALUES ('3364', '互助土族自治县', '1', '0', '353', '3');
INSERT INTO `mny_address` VALUES ('3365', '化隆回族自治县', '1', '0', '353', '3');
INSERT INTO `mny_address` VALUES ('3366', '循化撒拉族自治县', '1', '0', '353', '3');
INSERT INTO `mny_address` VALUES ('3367', '门源回族自治县', '1', '0', '354', '3');
INSERT INTO `mny_address` VALUES ('3368', '祁连县', '1', '0', '354', '3');
INSERT INTO `mny_address` VALUES ('3369', '海晏县', '1', '0', '354', '3');
INSERT INTO `mny_address` VALUES ('3370', '刚察县', '1', '0', '354', '3');
INSERT INTO `mny_address` VALUES ('3371', '同仁县', '1', '0', '355', '3');
INSERT INTO `mny_address` VALUES ('3372', '尖扎县', '1', '0', '355', '3');
INSERT INTO `mny_address` VALUES ('3373', '泽库县', '1', '0', '355', '3');
INSERT INTO `mny_address` VALUES ('3374', '河南蒙古族自治县', '1', '0', '355', '3');
INSERT INTO `mny_address` VALUES ('3375', '共和县', '1', '0', '356', '3');
INSERT INTO `mny_address` VALUES ('3376', '同德县', '1', '0', '356', '3');
INSERT INTO `mny_address` VALUES ('3377', '贵德县', '1', '0', '356', '3');
INSERT INTO `mny_address` VALUES ('3378', '兴海县', '1', '0', '356', '3');
INSERT INTO `mny_address` VALUES ('3379', '贵南县', '1', '0', '356', '3');
INSERT INTO `mny_address` VALUES ('3380', '玛沁县', '1', '0', '357', '3');
INSERT INTO `mny_address` VALUES ('3381', '班玛县', '1', '0', '357', '3');
INSERT INTO `mny_address` VALUES ('3382', '甘德县', '1', '0', '357', '3');
INSERT INTO `mny_address` VALUES ('3383', '达日县', '1', '0', '357', '3');
INSERT INTO `mny_address` VALUES ('3384', '久治县', '1', '0', '357', '3');
INSERT INTO `mny_address` VALUES ('3385', '玛多县', '1', '0', '357', '3');
INSERT INTO `mny_address` VALUES ('3386', '玉树县', '1', '0', '358', '3');
INSERT INTO `mny_address` VALUES ('3387', '杂多县', '1', '0', '358', '3');
INSERT INTO `mny_address` VALUES ('3388', '称多县', '1', '0', '358', '3');
INSERT INTO `mny_address` VALUES ('3389', '治多县', '1', '0', '358', '3');
INSERT INTO `mny_address` VALUES ('3390', '囊谦县', '1', '0', '358', '3');
INSERT INTO `mny_address` VALUES ('3391', '曲麻莱县', '1', '0', '358', '3');
INSERT INTO `mny_address` VALUES ('3392', '格尔木市', '1', '0', '359', '3');
INSERT INTO `mny_address` VALUES ('3393', '德令哈市', '1', '0', '359', '3');
INSERT INTO `mny_address` VALUES ('3394', '乌兰县', '1', '0', '359', '3');
INSERT INTO `mny_address` VALUES ('3395', '都兰县', '1', '0', '359', '3');
INSERT INTO `mny_address` VALUES ('3396', '天峻县', '1', '0', '359', '3');
INSERT INTO `mny_address` VALUES ('3397', '市辖区', '1', '0', '360', '3');
INSERT INTO `mny_address` VALUES ('3398', '兴庆区', '1', '0', '360', '3');
INSERT INTO `mny_address` VALUES ('3399', '西夏区', '1', '0', '360', '3');
INSERT INTO `mny_address` VALUES ('3400', '金凤区', '1', '0', '360', '3');
INSERT INTO `mny_address` VALUES ('3401', '永宁县', '1', '0', '360', '3');
INSERT INTO `mny_address` VALUES ('3402', '贺兰县', '1', '0', '360', '3');
INSERT INTO `mny_address` VALUES ('3403', '灵武市', '1', '0', '360', '3');
INSERT INTO `mny_address` VALUES ('3404', '市辖区', '1', '0', '361', '3');
INSERT INTO `mny_address` VALUES ('3405', '大武口区', '1', '0', '361', '3');
INSERT INTO `mny_address` VALUES ('3406', '惠农区', '1', '0', '361', '3');
INSERT INTO `mny_address` VALUES ('3407', '平罗县', '1', '0', '361', '3');
INSERT INTO `mny_address` VALUES ('3408', '市辖区', '1', '0', '362', '3');
INSERT INTO `mny_address` VALUES ('3409', '利通区', '1', '0', '362', '3');
INSERT INTO `mny_address` VALUES ('3410', '盐池县', '1', '0', '362', '3');
INSERT INTO `mny_address` VALUES ('3411', '同心县', '1', '0', '362', '3');
INSERT INTO `mny_address` VALUES ('3412', '青铜峡市', '1', '0', '362', '3');
INSERT INTO `mny_address` VALUES ('3413', '市辖区', '1', '0', '363', '3');
INSERT INTO `mny_address` VALUES ('3414', '原州区', '1', '0', '363', '3');
INSERT INTO `mny_address` VALUES ('3415', '西吉县', '1', '0', '363', '3');
INSERT INTO `mny_address` VALUES ('3416', '隆德县', '1', '0', '363', '3');
INSERT INTO `mny_address` VALUES ('3417', '泾源县', '1', '0', '363', '3');
INSERT INTO `mny_address` VALUES ('3418', '彭阳县', '1', '0', '363', '3');
INSERT INTO `mny_address` VALUES ('3419', '市辖区', '1', '0', '364', '3');
INSERT INTO `mny_address` VALUES ('3420', '沙坡头区', '1', '0', '364', '3');
INSERT INTO `mny_address` VALUES ('3421', '中宁县', '1', '0', '364', '3');
INSERT INTO `mny_address` VALUES ('3422', '海原县', '1', '0', '364', '3');
INSERT INTO `mny_address` VALUES ('3423', '市辖区', '1', '0', '365', '3');
INSERT INTO `mny_address` VALUES ('3424', '天山区', '1', '0', '365', '3');
INSERT INTO `mny_address` VALUES ('3425', '沙依巴克区', '1', '0', '365', '3');
INSERT INTO `mny_address` VALUES ('3426', '新市区', '1', '0', '365', '3');
INSERT INTO `mny_address` VALUES ('3427', '水磨沟区', '1', '0', '365', '3');
INSERT INTO `mny_address` VALUES ('3428', '头屯河区', '1', '0', '365', '3');
INSERT INTO `mny_address` VALUES ('3429', '达坂城区', '1', '0', '365', '3');
INSERT INTO `mny_address` VALUES ('3430', '东山区', '1', '0', '365', '3');
INSERT INTO `mny_address` VALUES ('3431', '乌鲁木齐县', '1', '0', '365', '3');
INSERT INTO `mny_address` VALUES ('3432', '市辖区', '1', '0', '366', '3');
INSERT INTO `mny_address` VALUES ('3433', '独山子区', '1', '0', '366', '3');
INSERT INTO `mny_address` VALUES ('3434', '克拉玛依区', '1', '0', '366', '3');
INSERT INTO `mny_address` VALUES ('3435', '白碱滩区', '1', '0', '366', '3');
INSERT INTO `mny_address` VALUES ('3436', '乌尔禾区', '1', '0', '366', '3');
INSERT INTO `mny_address` VALUES ('3437', '吐鲁番市', '1', '0', '367', '3');
INSERT INTO `mny_address` VALUES ('3438', '鄯善县', '1', '0', '367', '3');
INSERT INTO `mny_address` VALUES ('3439', '托克逊县', '1', '0', '367', '3');
INSERT INTO `mny_address` VALUES ('3440', '哈密市', '1', '0', '368', '3');
INSERT INTO `mny_address` VALUES ('3441', '巴里坤哈萨克自治县', '1', '0', '368', '3');
INSERT INTO `mny_address` VALUES ('3442', '伊吾县', '1', '0', '368', '3');
INSERT INTO `mny_address` VALUES ('3443', '昌吉市', '1', '0', '369', '3');
INSERT INTO `mny_address` VALUES ('3444', '阜康市', '1', '0', '369', '3');
INSERT INTO `mny_address` VALUES ('3445', '米泉市', '1', '0', '369', '3');
INSERT INTO `mny_address` VALUES ('3446', '呼图壁县', '1', '0', '369', '3');
INSERT INTO `mny_address` VALUES ('3447', '玛纳斯县', '1', '0', '369', '3');
INSERT INTO `mny_address` VALUES ('3448', '奇台县', '1', '0', '369', '3');
INSERT INTO `mny_address` VALUES ('3449', '吉木萨尔县', '1', '0', '369', '3');
INSERT INTO `mny_address` VALUES ('3450', '木垒哈萨克自治县', '1', '0', '369', '3');
INSERT INTO `mny_address` VALUES ('3451', '博乐市', '1', '0', '370', '3');
INSERT INTO `mny_address` VALUES ('3452', '精河县', '1', '0', '370', '3');
INSERT INTO `mny_address` VALUES ('3453', '温泉县', '1', '0', '370', '3');
INSERT INTO `mny_address` VALUES ('3454', '库尔勒市', '1', '0', '371', '3');
INSERT INTO `mny_address` VALUES ('3455', '轮台县', '1', '0', '371', '3');
INSERT INTO `mny_address` VALUES ('3456', '尉犁县', '1', '0', '371', '3');
INSERT INTO `mny_address` VALUES ('3457', '若羌县', '1', '0', '371', '3');
INSERT INTO `mny_address` VALUES ('3458', '且末县', '1', '0', '371', '3');
INSERT INTO `mny_address` VALUES ('3459', '焉耆回族自治县', '1', '0', '371', '3');
INSERT INTO `mny_address` VALUES ('3460', '和静县', '1', '0', '371', '3');
INSERT INTO `mny_address` VALUES ('3461', '和硕县', '1', '0', '371', '3');
INSERT INTO `mny_address` VALUES ('3462', '博湖县', '1', '0', '371', '3');
INSERT INTO `mny_address` VALUES ('3463', '阿克苏市', '1', '0', '372', '3');
INSERT INTO `mny_address` VALUES ('3464', '温宿县', '1', '0', '372', '3');
INSERT INTO `mny_address` VALUES ('3465', '库车县', '1', '0', '372', '3');
INSERT INTO `mny_address` VALUES ('3466', '沙雅县', '1', '0', '372', '3');
INSERT INTO `mny_address` VALUES ('3467', '新和县', '1', '0', '372', '3');
INSERT INTO `mny_address` VALUES ('3468', '拜城县', '1', '0', '372', '3');
INSERT INTO `mny_address` VALUES ('3469', '乌什县', '1', '0', '372', '3');
INSERT INTO `mny_address` VALUES ('3470', '阿瓦提县', '1', '0', '372', '3');
INSERT INTO `mny_address` VALUES ('3471', '柯坪县', '1', '0', '372', '3');
INSERT INTO `mny_address` VALUES ('3472', '阿图什市', '1', '0', '373', '3');
INSERT INTO `mny_address` VALUES ('3473', '阿克陶县', '1', '0', '373', '3');
INSERT INTO `mny_address` VALUES ('3474', '阿合奇县', '1', '0', '373', '3');
INSERT INTO `mny_address` VALUES ('3475', '乌恰县', '1', '0', '373', '3');
INSERT INTO `mny_address` VALUES ('3476', '喀什市', '1', '0', '374', '3');
INSERT INTO `mny_address` VALUES ('3477', '疏附县', '1', '0', '374', '3');
INSERT INTO `mny_address` VALUES ('3478', '疏勒县', '1', '0', '374', '3');
INSERT INTO `mny_address` VALUES ('3479', '英吉沙县', '1', '0', '374', '3');
INSERT INTO `mny_address` VALUES ('3480', '泽普县', '1', '0', '374', '3');
INSERT INTO `mny_address` VALUES ('3481', '莎车县', '1', '0', '374', '3');
INSERT INTO `mny_address` VALUES ('3482', '叶城县', '1', '0', '374', '3');
INSERT INTO `mny_address` VALUES ('3483', '麦盖提县', '1', '0', '374', '3');
INSERT INTO `mny_address` VALUES ('3484', '岳普湖县', '1', '0', '374', '3');
INSERT INTO `mny_address` VALUES ('3485', '伽师县', '1', '0', '374', '3');
INSERT INTO `mny_address` VALUES ('3486', '巴楚县', '1', '0', '374', '3');
INSERT INTO `mny_address` VALUES ('3487', '塔什库尔干塔吉克自治县', '1', '0', '374', '3');
INSERT INTO `mny_address` VALUES ('3488', '和田市', '1', '0', '375', '3');
INSERT INTO `mny_address` VALUES ('3489', '和田县', '1', '0', '375', '3');
INSERT INTO `mny_address` VALUES ('3490', '墨玉县', '1', '0', '375', '3');
INSERT INTO `mny_address` VALUES ('3491', '皮山县', '1', '0', '375', '3');
INSERT INTO `mny_address` VALUES ('3492', '洛浦县', '1', '0', '375', '3');
INSERT INTO `mny_address` VALUES ('3493', '策勒县', '1', '0', '375', '3');
INSERT INTO `mny_address` VALUES ('3494', '于田县', '1', '0', '375', '3');
INSERT INTO `mny_address` VALUES ('3495', '民丰县', '1', '0', '375', '3');
INSERT INTO `mny_address` VALUES ('3496', '伊宁市', '1', '0', '376', '3');
INSERT INTO `mny_address` VALUES ('3497', '奎屯市', '1', '0', '376', '3');
INSERT INTO `mny_address` VALUES ('3498', '伊宁县', '1', '0', '376', '3');
INSERT INTO `mny_address` VALUES ('3499', '察布查尔锡伯自治县', '1', '0', '376', '3');
INSERT INTO `mny_address` VALUES ('3500', '霍城县', '1', '0', '376', '3');
INSERT INTO `mny_address` VALUES ('3501', '巩留县', '1', '0', '376', '3');
INSERT INTO `mny_address` VALUES ('3502', '新源县', '1', '0', '376', '3');
INSERT INTO `mny_address` VALUES ('3503', '昭苏县', '1', '0', '376', '3');
INSERT INTO `mny_address` VALUES ('3504', '特克斯县', '1', '0', '376', '3');
INSERT INTO `mny_address` VALUES ('3505', '尼勒克县', '1', '0', '376', '3');
INSERT INTO `mny_address` VALUES ('3506', '塔城市', '1', '0', '377', '3');
INSERT INTO `mny_address` VALUES ('3507', '乌苏市', '1', '0', '377', '3');
INSERT INTO `mny_address` VALUES ('3508', '额敏县', '1', '0', '377', '3');
INSERT INTO `mny_address` VALUES ('3509', '沙湾县', '1', '0', '377', '3');
INSERT INTO `mny_address` VALUES ('3510', '托里县', '1', '0', '377', '3');
INSERT INTO `mny_address` VALUES ('3511', '裕民县', '1', '0', '377', '3');
INSERT INTO `mny_address` VALUES ('3512', '和布克赛尔蒙古自治县', '1', '0', '377', '3');
INSERT INTO `mny_address` VALUES ('3513', '阿勒泰市', '1', '0', '378', '3');
INSERT INTO `mny_address` VALUES ('3514', '布尔津县', '1', '0', '378', '3');
INSERT INTO `mny_address` VALUES ('3515', '富蕴县', '1', '0', '378', '3');
INSERT INTO `mny_address` VALUES ('3516', '福海县', '1', '0', '378', '3');
INSERT INTO `mny_address` VALUES ('3517', '哈巴河县', '1', '0', '378', '3');
INSERT INTO `mny_address` VALUES ('3518', '青河县', '1', '0', '378', '3');
INSERT INTO `mny_address` VALUES ('3519', '吉木乃县', '1', '0', '378', '3');
INSERT INTO `mny_address` VALUES ('3520', '石河子市', '1', '0', '379', '3');
INSERT INTO `mny_address` VALUES ('3521', '阿拉尔市', '1', '0', '379', '3');
INSERT INTO `mny_address` VALUES ('3522', '图木舒克市', '1', '0', '379', '3');
INSERT INTO `mny_address` VALUES ('3523', '五家渠市', '1', '0', '379', '3');

-- -----------------------------
-- Table structure for `mny_admin`
-- -----------------------------
DROP TABLE IF EXISTS `mny_admin`;
CREATE TABLE `mny_admin` (
  `id` smallint unsigned NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `username` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '管理账号',
  `password` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '管理密码',
  `roleid` tinyint unsigned DEFAULT '0',
  `encrypt` varchar(6) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '加密因子',
  `nickname` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '昵称',
  `last_login_time` int unsigned DEFAULT '0' COMMENT '最后登录时间',
  `last_login_ip` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '最后登录IP',
  `email` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `token` varchar(60) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'Session标识',
  `status` tinyint NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `username` (`username`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='管理员表';

-- -----------------------------
-- Records of `mny_admin`
-- -----------------------------
INSERT INTO `mny_admin` VALUES ('1', 'admin', '594c25e037c44cd31e2f27a1ff4f87d8', '1', '6e5351', '八级天', '1663991160', '127.0.0.1', 'admin@admin.com', '4a658ec0-f95a-4605-b48e-5bc060cff815', '1');

-- -----------------------------
-- Table structure for `mny_admin_log`
-- -----------------------------
DROP TABLE IF EXISTS `mny_admin_log`;
CREATE TABLE `mny_admin_log` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '日志ID',
  `status` tinyint NOT NULL DEFAULT '0' COMMENT '状态',
  `uid` smallint NOT NULL DEFAULT '0' COMMENT '操作者ID',
  `info` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '说明',
  `create_time` int unsigned NOT NULL DEFAULT '0',
  `ip` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '操作IP',
  `get` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=352 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='操作日志';

-- -----------------------------
-- Records of `mny_admin_log`
-- -----------------------------
INSERT INTO `mny_admin_log` VALUES ('1', '0', '0', '提示语:请先登陆', '1660202951', '127.0.0.1', '/admin');
INSERT INTO `mny_admin_log` VALUES ('2', '0', '0', '提示语:验证码错误!', '1660202966', '127.0.0.1', '/admin/index/login.html');
INSERT INTO `mny_admin_log` VALUES ('3', '1', '1', '提示语:恭喜您，登陆成功', '1660202977', '127.0.0.1', '/admin/index/login.html');
INSERT INTO `mny_admin_log` VALUES ('4', '1', '1', '提示语:模块安装成功！一键清理缓存后生效！', '1660202995', '127.0.0.1', '/admin/module/install.html?module=member&dialog=1');
INSERT INTO `mny_admin_log` VALUES ('5', '1', '1', '提示语:清理缓存', '1660203001', '127.0.0.1', '/admin/index/cache.html?type=all&_=1660202977680');
INSERT INTO `mny_admin_log` VALUES ('6', '1', '1', '提示语:模块安装成功！一键清理缓存后生效！', '1660203009', '127.0.0.1', '/admin/module/install.html?module=links&dialog=1');
INSERT INTO `mny_admin_log` VALUES ('7', '1', '1', '提示语:模块安装成功！一键清理缓存后生效！', '1660203026', '127.0.0.1', '/admin/module/install.html?module=cms&dialog=1');
INSERT INTO `mny_admin_log` VALUES ('8', '1', '1', '提示语:模块安装成功！一键清理缓存后生效！', '1660203032', '127.0.0.1', '/admin/module/install.html?module=apidoc&dialog=1');
INSERT INTO `mny_admin_log` VALUES ('9', '1', '1', '提示语:模块安装成功！一键清理缓存后生效！', '1660203038', '127.0.0.1', '/admin/module/install.html?module=collection&dialog=1');
INSERT INTO `mny_admin_log` VALUES ('10', '1', '1', '提示语:模块安装成功！一键清理缓存后生效！', '1660203042', '127.0.0.1', '/admin/module/install.html?module=formguide&dialog=1');
INSERT INTO `mny_admin_log` VALUES ('11', '1', '1', '提示语:模块安装成功！一键清理缓存后生效！', '1660203054', '127.0.0.1', '/admin/module/install.html?module=message&dialog=1');
INSERT INTO `mny_admin_log` VALUES ('12', '1', '1', '提示语:模块安装成功！一键清理缓存后生效！', '1660203059', '127.0.0.1', '/admin/module/install.html?module=pay&dialog=1');
INSERT INTO `mny_admin_log` VALUES ('13', '1', '1', '提示语:清理缓存', '1660203067', '127.0.0.1', '/admin/index/cache.html?type=all&_=1660202977681');
INSERT INTO `mny_admin_log` VALUES ('14', '1', '1', '提示语:插件安装成功！清除浏览器缓存和框架缓存后生效！', '1660203082', '127.0.0.1', '/addons/addons/install.html?name=address');
INSERT INTO `mny_admin_log` VALUES ('15', '1', '1', '提示语:清理缓存', '1660203089', '127.0.0.1', '/admin/index/cache.html?type=all&_=1660203087120');
INSERT INTO `mny_admin_log` VALUES ('16', '1', '1', '提示语:插件安装成功！清除浏览器缓存和框架缓存后生效！', '1660203111', '127.0.0.1', '/addons/addons/install.html?name=loginbg');
INSERT INTO `mny_admin_log` VALUES ('17', '1', '1', '提示语:清理缓存', '1660203114', '127.0.0.1', '/admin/index/cache.html?type=all&_=1660203101382');
INSERT INTO `mny_admin_log` VALUES ('18', '0', '0', '提示语:请先登陆', '1660221784', '127.0.0.1', '/admin/index/index.html');
INSERT INTO `mny_admin_log` VALUES ('19', '0', '0', '提示语:请先登陆', '1660267856', '127.0.0.1', '/admin/index/index.html');
INSERT INTO `mny_admin_log` VALUES ('20', '1', '1', '提示语:更新成功！', '1660268055', '127.0.0.1', '/cms/setting/index/menuid/110.html');
INSERT INTO `mny_admin_log` VALUES ('21', '1', '1', '提示语:清理缓存', '1660268122', '127.0.0.1', '/admin/index/cache.html?type=all&_=1660267860671');
INSERT INTO `mny_admin_log` VALUES ('22', '0', '0', '提示语:请先登陆', '1660352997', '127.0.0.1', '/admin/index/index.html');
INSERT INTO `mny_admin_log` VALUES ('23', '1', '1', '提示语:恭喜您，登陆成功', '1660531960', '127.0.0.1', '/admin/index/login.html');
INSERT INTO `mny_admin_log` VALUES ('24', '0', '0', '提示语:请先登陆', '1660550344', '127.0.0.1', '/cms/cms/index/menuid/85.html');
INSERT INTO `mny_admin_log` VALUES ('25', '0', '0', '提示语:请先登陆', '1660550344', '127.0.0.1', '/cms/category/index/menuid/111.html');
INSERT INTO `mny_admin_log` VALUES ('26', '1', '1', '提示语:恭喜您，登陆成功', '1660550356', '127.0.0.1', '/admin/index/login.html');
INSERT INTO `mny_admin_log` VALUES ('27', '0', '0', '提示语:请先登陆', '1660613996', '127.0.0.1', '/admin/index/index.html');
INSERT INTO `mny_admin_log` VALUES ('28', '1', '1', '提示语:恭喜您，登陆成功', '1660699096', '127.0.0.1', '/admin/index/login.html');
INSERT INTO `mny_admin_log` VALUES ('29', '0', '0', '提示语:请先登陆', '1660731906', '127.0.0.1', '/admin/config/setting/menuid/13.html');
INSERT INTO `mny_admin_log` VALUES ('30', '0', '0', '提示语:请先登陆', '1660731924', '127.0.0.1', '/admin/index/index.html');
INSERT INTO `mny_admin_log` VALUES ('31', '0', '0', '提示语:验证码错误!', '1660731938', '127.0.0.1', '/admin/index/login.html');
INSERT INTO `mny_admin_log` VALUES ('32', '1', '1', '提示语:恭喜您，登陆成功', '1660731944', '127.0.0.1', '/admin/index/login.html');
INSERT INTO `mny_admin_log` VALUES ('33', '0', '0', '提示语:请先登陆', '1660868246', '127.0.0.1', '/admin/index/index.html');
INSERT INTO `mny_admin_log` VALUES ('34', '1', '1', '提示语:恭喜您，登陆成功', '1660868324', '127.0.0.1', '/admin/index/login.html');
INSERT INTO `mny_admin_log` VALUES ('35', '0', '0', '提示语:请先登陆', '1661064976', '127.0.0.1', '/admin/index/index.html');
INSERT INTO `mny_admin_log` VALUES ('36', '0', '0', '提示语:验证码错误!', '1661078043', '127.0.0.1', '/admin/index/login.html');
INSERT INTO `mny_admin_log` VALUES ('37', '1', '1', '提示语:恭喜您，登陆成功', '1661078052', '127.0.0.1', '/admin/index/login.html');
INSERT INTO `mny_admin_log` VALUES ('38', '1', '1', '提示语:操作成功!', '1661078065', '127.0.0.1', '/admin/auth_manager/writegroup.html');
INSERT INTO `mny_admin_log` VALUES ('39', '1', '1', '提示语:添加成功！', '1661078090', '127.0.0.1', '/admin/manager/add.html?dialog=1');
INSERT INTO `mny_admin_log` VALUES ('40', '1', '0', '提示语:注销成功！', '1661078098', '127.0.0.1', '/admin/index/logout.html');
INSERT INTO `mny_admin_log` VALUES ('41', '1', '1', '提示语:恭喜您，登陆成功', '1661078110', '127.0.0.1', '/admin/index/login.html');
INSERT INTO `mny_admin_log` VALUES ('42', '1', '0', '提示语:注销成功！', '1661078118', '127.0.0.1', '/admin/index/logout.html');
INSERT INTO `mny_admin_log` VALUES ('43', '0', '0', '提示语:验证码错误!', '1661078126', '127.0.0.1', '/admin/index/login.html');
INSERT INTO `mny_admin_log` VALUES ('44', '1', '1', '提示语:恭喜您，登陆成功', '1661078136', '127.0.0.1', '/admin/index/login.html');
INSERT INTO `mny_admin_log` VALUES ('45', '1', '1', '提示语:操作成功!', '1661078148', '127.0.0.1', '/admin/auth_manager/writegroup.html');
INSERT INTO `mny_admin_log` VALUES ('46', '1', '0', '提示语:注销成功！', '1661078152', '127.0.0.1', '/admin/index/logout.html');
INSERT INTO `mny_admin_log` VALUES ('47', '1', '0', '提示语:注销成功！', '1661078165', '127.0.0.1', '/admin/index/logout.html');
INSERT INTO `mny_admin_log` VALUES ('48', '0', '0', '提示语:请先登陆', '1661078168', '127.0.0.1', '/admin/');
INSERT INTO `mny_admin_log` VALUES ('49', '0', '0', '提示语:验证码错误!', '1661078181', '127.0.0.1', '/admin/index/login.html');
INSERT INTO `mny_admin_log` VALUES ('50', '1', '1', '提示语:恭喜您，登陆成功', '1661078189', '127.0.0.1', '/admin/index/login.html');
INSERT INTO `mny_admin_log` VALUES ('51', '1', '1', '提示语:操作成功!', '1661078203', '127.0.0.1', '/admin/auth_manager/writegroup.html');
INSERT INTO `mny_admin_log` VALUES ('52', '0', '0', '提示语:请先登陆', '1661095918', '127.0.0.1', '/admin/index/index.html');
INSERT INTO `mny_admin_log` VALUES ('53', '1', '1', '提示语:恭喜您，登陆成功', '1661130936', '127.0.0.1', '/admin/index/login.html');
INSERT INTO `mny_admin_log` VALUES ('54', '1', '1', '提示语:新增成功', '1661157240', '127.0.0.1', '/cms/field/add/modelid/1.html?dialog=1');
INSERT INTO `mny_admin_log` VALUES ('55', '1', '1', '提示语:菜单排序成功！', '1661157251', '127.0.0.1', '/cms/field/listorder.html');
INSERT INTO `mny_admin_log` VALUES ('56', '1', '1', '提示语:操作成功！', '1661157281', '127.0.0.1', '/cms/cms/add/catid/6.html?dialog=1');
INSERT INTO `mny_admin_log` VALUES ('57', '1', '1', '提示语:编辑成功！', '1661157563', '127.0.0.1', '/cms/cms/edit/catid/6.html?id=7&dialog=1');
INSERT INTO `mny_admin_log` VALUES ('58', '1', '1', '提示语:编辑成功！', '1661157572', '127.0.0.1', '/cms/cms/edit/catid/6.html?id=7&dialog=1');
INSERT INTO `mny_admin_log` VALUES ('59', '0', '1', '提示语:\'标题\'必须填写~', '1661157745', '127.0.0.1', '/cms/cms/add/catid/6.html?dialog=1');
INSERT INTO `mny_admin_log` VALUES ('60', '0', '0', '提示语:请先登陆', '1661193031', '127.0.0.1', '/admin/index/index.html');
INSERT INTO `mny_admin_log` VALUES ('61', '1', '1', '提示语:恭喜您，登陆成功', '1661193059', '127.0.0.1', '/admin/index/login.html');
INSERT INTO `mny_admin_log` VALUES ('62', '1', '1', '提示语:设置更新成功', '1661193074', '127.0.0.1', '/admin/config/setting/group/system.html');
INSERT INTO `mny_admin_log` VALUES ('63', '1', '1', '提示语:编辑成功！', '1661193106', '127.0.0.1', '/cms/cms/edit/catid/6.html?id=7&dialog=1');
INSERT INTO `mny_admin_log` VALUES ('64', '1', '1', '提示语:编辑成功！', '1661193133', '127.0.0.1', '/cms/cms/edit/catid/6.html?id=7&dialog=1');
INSERT INTO `mny_admin_log` VALUES ('65', '0', '0', '提示语:请先登陆', '1661222999', '127.0.0.1', '/admin/index/index.html');
INSERT INTO `mny_admin_log` VALUES ('66', '0', '0', '提示语:请先登陆', '1661595297', '127.0.0.1', '/admin');
INSERT INTO `mny_admin_log` VALUES ('67', '1', '1', '提示语:恭喜您，登陆成功', '1661595318', '127.0.0.1', '/admin/index/login.html');
INSERT INTO `mny_admin_log` VALUES ('68', '0', '1', '提示语:用户不存在！', '1661595341', '127.0.0.1', '/pay/payment/modify_deposit.html?dialog=1');
INSERT INTO `mny_admin_log` VALUES ('69', '1', '1', '提示语:充值成功！', '1661595436', '127.0.0.1', '/pay/payment/modify_deposit.html?dialog=1');
INSERT INTO `mny_admin_log` VALUES ('70', '1', '1', '提示语:充值成功！', '1661595482', '127.0.0.1', '/pay/payment/modify_deposit.html?dialog=1');
INSERT INTO `mny_admin_log` VALUES ('71', '1', '1', '提示语:更新成功！', '1661599325', '127.0.0.1', '/pay/payment/edit.html?id=2&dialog=1');
INSERT INTO `mny_admin_log` VALUES ('72', '0', '0', '提示语:请先登陆', '1663470114', '127.0.0.1', '/admin');
INSERT INTO `mny_admin_log` VALUES ('73', '0', '0', '提示语:请先登陆', '1663470207', '127.0.0.1', '/admin/');
INSERT INTO `mny_admin_log` VALUES ('74', '0', '0', '提示语:请先登陆', '1663470215', '127.0.0.1', '/admin/');
INSERT INTO `mny_admin_log` VALUES ('75', '0', '0', '提示语:请先登陆', '1663472373', '127.0.0.1', '/admin/');
INSERT INTO `mny_admin_log` VALUES ('76', '0', '0', '提示语:请先登陆', '1663472380', '127.0.0.1', '/admin');
INSERT INTO `mny_admin_log` VALUES ('77', '0', '0', '提示语:请先登陆', '1663472386', '127.0.0.1', '/admin/');
INSERT INTO `mny_admin_log` VALUES ('78', '0', '0', '提示语:请先登陆', '1663472445', '127.0.0.1', '/admin');
INSERT INTO `mny_admin_log` VALUES ('79', '0', '0', '提示语:请先登陆', '1663472859', '127.0.0.1', '/admin');
INSERT INTO `mny_admin_log` VALUES ('80', '0', '0', '提示语:请先登陆', '1663472861', '127.0.0.1', '/admin');
INSERT INTO `mny_admin_log` VALUES ('81', '0', '0', '提示语:请先登陆', '1663472861', '127.0.0.1', '/admin');
INSERT INTO `mny_admin_log` VALUES ('82', '0', '0', '提示语:请先登陆', '1663472865', '127.0.0.1', '/admin');
INSERT INTO `mny_admin_log` VALUES ('83', '0', '0', '提示语:请先登陆', '1663472865', '127.0.0.1', '/admin');
INSERT INTO `mny_admin_log` VALUES ('84', '0', '0', '提示语:请先登陆', '1663472865', '127.0.0.1', '/admin');
INSERT INTO `mny_admin_log` VALUES ('85', '0', '0', '提示语:请先登陆', '1663472954', '127.0.0.1', '/admin');
INSERT INTO `mny_admin_log` VALUES ('86', '0', '0', '提示语:请先登陆', '1663472957', '127.0.0.1', '/admin');
INSERT INTO `mny_admin_log` VALUES ('87', '0', '0', '提示语:请先登陆', '1663473007', '127.0.0.1', '/admin');
INSERT INTO `mny_admin_log` VALUES ('88', '0', '0', '提示语:请先登陆', '1663473007', '127.0.0.1', '/admin');
INSERT INTO `mny_admin_log` VALUES ('89', '0', '0', '提示语:请先登陆', '1663473007', '127.0.0.1', '/admin');
INSERT INTO `mny_admin_log` VALUES ('90', '0', '0', '提示语:请先登陆', '1663473077', '127.0.0.1', '/admin');
INSERT INTO `mny_admin_log` VALUES ('91', '0', '0', '提示语:请先登陆', '1663473206', '127.0.0.1', '/admin');
INSERT INTO `mny_admin_log` VALUES ('92', '0', '0', '提示语:请先登陆', '1663473224', '127.0.0.1', '/admin');
INSERT INTO `mny_admin_log` VALUES ('93', '0', '0', '提示语:请先登陆', '1663473292', '127.0.0.1', '/admin');
INSERT INTO `mny_admin_log` VALUES ('94', '0', '0', '提示语:请先登陆', '1663473297', '127.0.0.1', '/admin');
INSERT INTO `mny_admin_log` VALUES ('95', '0', '0', '提示语:请先登陆', '1663473310', '127.0.0.1', '/admin');
INSERT INTO `mny_admin_log` VALUES ('96', '0', '0', '提示语:请先登陆', '1663473317', '127.0.0.1', '/admin');
INSERT INTO `mny_admin_log` VALUES ('97', '0', '0', '提示语:请先登陆', '1663473322', '127.0.0.1', '/admin/');
INSERT INTO `mny_admin_log` VALUES ('98', '0', '0', '提示语:验证码错误!', '1663474687', '127.0.0.1', '/admin/index/login.html');
INSERT INTO `mny_admin_log` VALUES ('99', '0', '0', '提示语:验证码错误!', '1663474704', '127.0.0.1', '/admin/index/login.html');
INSERT INTO `mny_admin_log` VALUES ('100', '0', '0', '提示语:验证码错误!', '1663474830', '127.0.0.1', '/admin/index/login.html');
INSERT INTO `mny_admin_log` VALUES ('101', '0', '0', '提示语:请先登陆', '1663475171', '127.0.0.1', '/admin/index/index.html');
INSERT INTO `mny_admin_log` VALUES ('102', '0', '0', '提示语:用户名不正确', '1663475692', '127.0.0.1', '/admin/index/login.html');
INSERT INTO `mny_admin_log` VALUES ('103', '0', '0', '提示语:密码不正确', '1663489137', '127.0.0.1', '/admin/index/login.html');
INSERT INTO `mny_admin_log` VALUES ('104', '1', '0', '提示语:恭喜您，登陆成功', '1663489232', '127.0.0.1', '/admin/index/login.html');
INSERT INTO `mny_admin_log` VALUES ('105', '0', '0', '提示语:请先登陆', '1663489233', '127.0.0.1', '/admin/index/index.html');
INSERT INTO `mny_admin_log` VALUES ('106', '1', '0', '提示语:恭喜您，登陆成功', '1663489757', '127.0.0.1', '/admin/index/login.html');
INSERT INTO `mny_admin_log` VALUES ('107', '0', '0', '提示语:请先登陆', '1663489759', '127.0.0.1', '/admin/index/index.html');
INSERT INTO `mny_admin_log` VALUES ('108', '1', '0', '提示语:恭喜您，登陆成功', '1663489866', '127.0.0.1', '/admin/index/login.html');
INSERT INTO `mny_admin_log` VALUES ('109', '0', '0', '提示语:请先登陆', '1663489867', '127.0.0.1', '/admin/index/index.html');
INSERT INTO `mny_admin_log` VALUES ('110', '1', '1', '提示语:恭喜您，登陆成功', '1663491315', '127.0.0.1', '/admin/index/login');
INSERT INTO `mny_admin_log` VALUES ('111', '1', '0', '提示语:注销成功！', '1663491456', '127.0.0.1', '/admin/index/logout.html');
INSERT INTO `mny_admin_log` VALUES ('112', '0', '0', '提示语:密码不正确', '1663491540', '127.0.0.1', '/admin/index/login.html');
INSERT INTO `mny_admin_log` VALUES ('113', '1', '1', '提示语:恭喜您，登陆成功', '1663491552', '127.0.0.1', '/admin/index/login.html');
INSERT INTO `mny_admin_log` VALUES ('114', '1', '1', '提示语:设置更新成功', '1663492561', '127.0.0.1', '/admin/config/setting/menuid/13.html');
INSERT INTO `mny_admin_log` VALUES ('115', '0', '1', '提示语:class not exists:app\\common\\validate\\Config', '1663492680', '127.0.0.1', '/admin/config/edit.html?id=1&dialog=1');
INSERT INTO `mny_admin_log` VALUES ('116', '0', '1', '提示语:class not exists:app\\common\\validate\\Config', '1663492685', '127.0.0.1', '/admin/config/edit.html?id=1&dialog=1');
INSERT INTO `mny_admin_log` VALUES ('117', '1', '1', '提示语:修改成功', '1663492764', '127.0.0.1', '/admin/config/edit.html?id=1&dialog=1');
INSERT INTO `mny_admin_log` VALUES ('118', '1', '0', '提示语:注销成功！', '1663492838', '127.0.0.1', '/admin/index/logout.html');
INSERT INTO `mny_admin_log` VALUES ('119', '1', '1', '提示语:恭喜您，登陆成功。', '1663492867', '127.0.0.1', '/admin/index/login.html');
INSERT INTO `mny_admin_log` VALUES ('120', '1', '1', '提示语:设置更新成功', '1663493045', '127.0.0.1', '/admin/config/setting/menuid/13.html');
INSERT INTO `mny_admin_log` VALUES ('121', '1', '1', '提示语:设置更新成功', '1663493074', '127.0.0.1', '/admin/config/setting/group/system.html');
INSERT INTO `mny_admin_log` VALUES ('122', '1', '1', '提示语:操作成功！', '1663493083', '127.0.0.1', '/admin/config/del.html?id=2');
INSERT INTO `mny_admin_log` VALUES ('123', '1', '1', '提示语:操作成功！', '1663493100', '127.0.0.1', '/admin/config/del.html?id=4');
INSERT INTO `mny_admin_log` VALUES ('124', '1', '1', '提示语:操作成功！', '1663493222', '127.0.0.1', '/admin/config/multi.html');
INSERT INTO `mny_admin_log` VALUES ('125', '1', '1', '提示语:设置更新成功', '1663493277', '127.0.0.1', '/admin/config/setting/group/system.html');
INSERT INTO `mny_admin_log` VALUES ('126', '1', '1', '提示语:操作成功！', '1663495769', '127.0.0.1', '/admin/menu/multi.html');
INSERT INTO `mny_admin_log` VALUES ('127', '1', '1', '提示语:操作成功！', '1663495769', '127.0.0.1', '/admin/menu/multi.html');
INSERT INTO `mny_admin_log` VALUES ('128', '1', '1', '提示语:操作成功！', '1663495776', '127.0.0.1', '/admin/menu/multi.html');
INSERT INTO `mny_admin_log` VALUES ('129', '1', '1', '提示语:文件删除成功~', '1663496131', '127.0.0.1', '/attachment/attachments/del.html?id=2');
INSERT INTO `mny_admin_log` VALUES ('130', '1', '1', '提示语:删除成功！', '1663496260', '127.0.0.1', '/admin/manager/del.html?id=2');
INSERT INTO `mny_admin_log` VALUES ('131', '1', '1', '提示语:删除成功！', '1663496401', '127.0.0.1', '/admin/auth_manager/deletegroup.html?id=4');
INSERT INTO `mny_admin_log` VALUES ('132', '1', '1', '提示语:删除成功！', '1663496404', '127.0.0.1', '/admin/auth_manager/deletegroup.html?id=3');
INSERT INTO `mny_admin_log` VALUES ('133', '0', '1', '提示语:class not exists:app\\common\\validate\\Menu', '1663496523', '127.0.0.1', '/admin/menu/edit.html?id=20&dialog=1');
INSERT INTO `mny_admin_log` VALUES ('134', '0', '1', '提示语:class not exists:app\\common\\validate\\Menu', '1663496557', '127.0.0.1', '/admin/menu/edit.html?id=20&dialog=1');
INSERT INTO `mny_admin_log` VALUES ('135', '1', '1', '提示语:修改成功', '1663496611', '127.0.0.1', '/admin/menu/edit.html?id=20&dialog=1');
INSERT INTO `mny_admin_log` VALUES ('136', '0', '1', '提示语:Use of undefined constant DS - assumed \'DS\' (this will throw an Error in a future version of PHP)', '1663496619', '127.0.0.1', '/admin/index/cache.html?type=all&_=1663496617212');
INSERT INTO `mny_admin_log` VALUES ('137', '1', '1', '提示语:清理缓存', '1663496851', '127.0.0.1', '/admin/index/cache.html?type=all&_=1663496617213');
INSERT INTO `mny_admin_log` VALUES ('138', '1', '1', '提示语:清理缓存', '1663496869', '127.0.0.1', '/admin/index/cache.html?type=all&_=1663496867779');
INSERT INTO `mny_admin_log` VALUES ('139', '1', '1', '提示语:操作成功!', '1663497509', '127.0.0.1', '/admin/auth_manager/writegroup.html');
INSERT INTO `mny_admin_log` VALUES ('140', '1', '1', '提示语:修改成功', '1663498271', '127.0.0.1', '/admin/menu/edit.html?id=60&dialog=1');
INSERT INTO `mny_admin_log` VALUES ('141', '1', '1', '提示语:操作成功！', '1663498327', '127.0.0.1', '/admin/menu/multi.html');
INSERT INTO `mny_admin_log` VALUES ('142', '1', '1', '提示语:操作成功！', '1663498336', '127.0.0.1', '/admin/menu/multi.html');
INSERT INTO `mny_admin_log` VALUES ('143', '1', '1', '提示语:修改成功', '1663498347', '127.0.0.1', '/admin/menu/edit.html?id=61&dialog=1');
INSERT INTO `mny_admin_log` VALUES ('144', '1', '1', '提示语:修改成功', '1663498411', '127.0.0.1', '/admin/menu/edit.html?id=63&dialog=1');
INSERT INTO `mny_admin_log` VALUES ('145', '1', '1', '提示语:修改成功', '1663498424', '127.0.0.1', '/admin/menu/edit.html?id=62&dialog=1');
INSERT INTO `mny_admin_log` VALUES ('146', '1', '1', '提示语:修改成功', '1663498449', '127.0.0.1', '/admin/menu/edit.html?id=83&dialog=1');
INSERT INTO `mny_admin_log` VALUES ('147', '1', '1', '提示语:操作成功！', '1663498458', '127.0.0.1', '/admin/menu/multi.html');
INSERT INTO `mny_admin_log` VALUES ('148', '1', '1', '提示语:清理缓存', '1663498463', '127.0.0.1', '/admin/index/cache.html?type=all&_=1663498459211');
INSERT INTO `mny_admin_log` VALUES ('149', '1', '1', '提示语:清理缓存', '1663498471', '127.0.0.1', '/admin/index/cache.html?type=data&_=1663498465761');
INSERT INTO `mny_admin_log` VALUES ('150', '1', '1', '提示语:清理缓存', '1663498475', '127.0.0.1', '/admin/index/cache.html?type=template&_=1663498465762');
INSERT INTO `mny_admin_log` VALUES ('151', '1', '1', '提示语:操作成功！', '1663499037', '127.0.0.1', '/admin/menu/multi.html');
INSERT INTO `mny_admin_log` VALUES ('152', '1', '1', '提示语:操作成功！', '1663499109', '127.0.0.1', '/admin/menu/multi.html');
INSERT INTO `mny_admin_log` VALUES ('153', '1', '1', '提示语:修改成功', '1663499124', '127.0.0.1', '/admin/menu/edit.html?id=45&dialog=1');
INSERT INTO `mny_admin_log` VALUES ('154', '1', '1', '提示语:操作成功！', '1663499131', '127.0.0.1', '/admin/menu/multi.html');
INSERT INTO `mny_admin_log` VALUES ('155', '1', '1', '提示语:操作成功！', '1663499138', '127.0.0.1', '/admin/menu/multi.html');
INSERT INTO `mny_admin_log` VALUES ('156', '1', '1', '提示语:操作成功！', '1663499140', '127.0.0.1', '/admin/menu/multi.html');
INSERT INTO `mny_admin_log` VALUES ('157', '1', '1', '提示语:新增成功', '1663499382', '127.0.0.1', '/admin/menu/add.html?parentid=45&dialog=1');
INSERT INTO `mny_admin_log` VALUES ('158', '1', '0', '提示语:注销成功！', '1663500305', '127.0.0.1', '/admin/index/logout.html');
INSERT INTO `mny_admin_log` VALUES ('159', '1', '1', '提示语:恭喜您，登陆成功。', '1663500319', '127.0.0.1', '/admin/index/login.html');
INSERT INTO `mny_admin_log` VALUES ('160', '1', '0', '提示语:注销成功！', '1663500871', '127.0.0.1', '/admin/index/logout.html');
INSERT INTO `mny_admin_log` VALUES ('161', '0', '0', '提示语:验证码错误!', '1663500883', '127.0.0.1', '/admin/index/login.html');
INSERT INTO `mny_admin_log` VALUES ('162', '1', '1', '提示语:恭喜您，登陆成功。', '1663500899', '127.0.0.1', '/admin/index/login.html');
INSERT INTO `mny_admin_log` VALUES ('163', '1', '1', '提示语:更新成功！', '1663501287', '127.0.0.1', '/member/setting/setting/menuid/62.html');
INSERT INTO `mny_admin_log` VALUES ('164', '1', '1', '提示语:清理缓存', '1663501330', '127.0.0.1', '/admin/index/cache.html?type=template&_=1663500900900');
INSERT INTO `mny_admin_log` VALUES ('165', '1', '1', '提示语:新增成功', '1663501525', '127.0.0.1', '/admin/menu/add.html?parentid=61&dialog=1');
INSERT INTO `mny_admin_log` VALUES ('166', '1', '1', '提示语:更新成功！', '1663501552', '127.0.0.1', '/member/setting/setting/menuid/62.html');
INSERT INTO `mny_admin_log` VALUES ('167', '0', '1', '提示语:该页面不存在！', '1663501578', '127.0.0.1', '/member/member/hongbao/menuid/158.html');
INSERT INTO `mny_admin_log` VALUES ('168', '0', '1', '提示语:该页面不存在！', '1663501580', '127.0.0.1', '/member/member/hongbao/menuid/158.html');
INSERT INTO `mny_admin_log` VALUES ('169', '0', '1', '提示语:该页面不存在！', '1663501587', '127.0.0.1', '/member/member/hongbao/menuid/158.html');
INSERT INTO `mny_admin_log` VALUES ('170', '0', '1', '提示语:该页面不存在！', '1663501595', '127.0.0.1', '/member/member/hongbao/menuid/158.html');
INSERT INTO `mny_admin_log` VALUES ('171', '0', '1', '提示语:该页面不存在！', '1663501625', '127.0.0.1', '/member/member/hongbao/menuid/158.html');
INSERT INTO `mny_admin_log` VALUES ('172', '0', '1', '提示语:该页面不存在！', '1663501650', '127.0.0.1', '/member/member/hongbao/menuid/158.html');
INSERT INTO `mny_admin_log` VALUES ('173', '1', '0', '提示语:注销成功！', '1663501654', '127.0.0.1', '/admin/index/logout.html');
INSERT INTO `mny_admin_log` VALUES ('174', '0', '0', '提示语:验证码错误!', '1663501677', '127.0.0.1', '/admin/index/login.html');
INSERT INTO `mny_admin_log` VALUES ('175', '0', '0', '提示语:验证码错误!', '1663501685', '127.0.0.1', '/admin/index/login.html');
INSERT INTO `mny_admin_log` VALUES ('176', '1', '1', '提示语:恭喜您，登陆成功。', '1663501704', '127.0.0.1', '/admin/index/login.html');
INSERT INTO `mny_admin_log` VALUES ('177', '0', '1', '提示语:该页面不存在！', '1663501708', '127.0.0.1', '/member/member/hongbao/menuid/158.html');
INSERT INTO `mny_admin_log` VALUES ('178', '0', '1', '提示语:该页面不存在！', '1663501719', '127.0.0.1', '/member/member/hongbao/menuid/158.html');
INSERT INTO `mny_admin_log` VALUES ('179', '1', '0', '提示语:注销成功！', '1663501722', '127.0.0.1', '/admin/index/logout.html');
INSERT INTO `mny_admin_log` VALUES ('180', '1', '1', '提示语:恭喜您，登陆成功。', '1663501852', '127.0.0.1', '/admin/index/login.html');
INSERT INTO `mny_admin_log` VALUES ('181', '0', '1', '提示语:该页面不存在！', '1663501856', '127.0.0.1', '/member/member/hongbao/menuid/158.html');
INSERT INTO `mny_admin_log` VALUES ('182', '0', '1', '提示语:该页面不存在！', '1663501862', '127.0.0.1', '/member/member/hongbao/menuid/158.html');
INSERT INTO `mny_admin_log` VALUES ('183', '1', '0', '提示语:注销成功！', '1663501865', '127.0.0.1', '/admin/index/logout.html');
INSERT INTO `mny_admin_log` VALUES ('184', '1', '1', '提示语:恭喜您，登陆成功。', '1663501911', '127.0.0.1', '/admin/index/login.html');
INSERT INTO `mny_admin_log` VALUES ('185', '0', '1', '提示语:该页面不存在！', '1663501956', '127.0.0.1', '/member/member/hongbao/menuid/158.html');
INSERT INTO `mny_admin_log` VALUES ('186', '1', '1', '提示语:清理缓存', '1663502380', '127.0.0.1', '/admin/index/cache.html?type=all&_=1663502228804');
INSERT INTO `mny_admin_log` VALUES ('187', '0', '1', '提示语:该页面不存在！', '1663504172', '127.0.0.1', '/member/member/hongbao/menuid/158.html');
INSERT INTO `mny_admin_log` VALUES ('188', '1', '1', '提示语:修改成功', '1663507908', '127.0.0.1', '/admin/menu/edit.html?id=110&dialog=1');
INSERT INTO `mny_admin_log` VALUES ('189', '1', '1', '提示语:更新成功！', '1663508155', '127.0.0.1', '/shop/setting/index/menuid/110.html');
INSERT INTO `mny_admin_log` VALUES ('190', '1', '1', '提示语:更新成功！', '1663508244', '127.0.0.1', '/shop/setting/index/menuid/110.html');
INSERT INTO `mny_admin_log` VALUES ('191', '0', '1', '提示语:该页面不存在！', '1663508828', '127.0.0.1', '/member/member/hongbao/menuid/158.html');
INSERT INTO `mny_admin_log` VALUES ('192', '1', '1', '提示语:修改成功', '1663508925', '127.0.0.1', '/admin/menu/edit.html?id=111&dialog=1');
INSERT INTO `mny_admin_log` VALUES ('193', '1', '1', '提示语:修改成功', '1663509255', '127.0.0.1', '/admin/menu/edit.html?id=102&dialog=1');
INSERT INTO `mny_admin_log` VALUES ('194', '1', '1', '提示语:操作成功！', '1663510154', '127.0.0.1', '/shop/region/multi.html');
INSERT INTO `mny_admin_log` VALUES ('195', '1', '1', '提示语:操作成功！', '1663510155', '127.0.0.1', '/shop/region/multi.html');
INSERT INTO `mny_admin_log` VALUES ('196', '1', '1', '提示语:操作成功！', '1663510428', '127.0.0.1', '/shop/region/multi.html');
INSERT INTO `mny_admin_log` VALUES ('197', '1', '1', '提示语:操作成功！', '1663510429', '127.0.0.1', '/shop/region/multi.html');
INSERT INTO `mny_admin_log` VALUES ('198', '1', '1', '提示语:操作成功！', '1663510433', '127.0.0.1', '/shop/region/multi.html');
INSERT INTO `mny_admin_log` VALUES ('199', '1', '1', '提示语:新增成功', '1663511040', '127.0.0.1', '/admin/menu/add.html?parentid=10&dialog=1');
INSERT INTO `mny_admin_log` VALUES ('200', '0', '0', '提示语:请先登陆', '1663550652', '127.0.0.1', '/admin');
INSERT INTO `mny_admin_log` VALUES ('201', '0', '0', '提示语:密码不正确', '1663550673', '127.0.0.1', '/admin/index/login.html');
INSERT INTO `mny_admin_log` VALUES ('202', '1', '1', '提示语:恭喜您，登陆成功。', '1663550686', '127.0.0.1', '/admin/index/login.html');
INSERT INTO `mny_admin_log` VALUES ('203', '0', '0', '提示语:请先登陆', '1663552409', '192.168.103.12', '/admin');
INSERT INTO `mny_admin_log` VALUES ('204', '1', '1', '提示语:恭喜您，登陆成功。', '1663552430', '192.168.103.12', '/admin/index/login.html');
INSERT INTO `mny_admin_log` VALUES ('205', '0', '0', '提示语:请先登陆', '1663556547', '192.168.103.29', '/admin');
INSERT INTO `mny_admin_log` VALUES ('206', '1', '1', '提示语:恭喜您，登陆成功。', '1663556565', '192.168.103.29', '/admin/index/login.html');
INSERT INTO `mny_admin_log` VALUES ('207', '1', '1', '提示语:操作成功！', '1663556615', '192.168.103.29', '/shop/region/multi.html');
INSERT INTO `mny_admin_log` VALUES ('208', '0', '1', '提示语:该页面不存在！', '1663557578', '192.168.103.12', '/member/member/hongbao/menuid/158.html');
INSERT INTO `mny_admin_log` VALUES ('209', '1', '1', '提示语:新增成功', '1663559180', '192.168.103.12', '/admin/menu/add.html?parentid=60&dialog=1');
INSERT INTO `mny_admin_log` VALUES ('210', '1', '1', '提示语:新增成功', '1663559217', '192.168.103.12', '/admin/menu/add.html?parentid=160&dialog=1');
INSERT INTO `mny_admin_log` VALUES ('211', '1', '1', '提示语:清理缓存', '1663559227', '192.168.103.12', '/admin/index/cache.html?type=all&_=1663559222884');
INSERT INTO `mny_admin_log` VALUES ('212', '0', '1', '提示语:该页面不存在！', '1663559230', '192.168.103.12', '/member/member/agreement/menuid/161.html');
INSERT INTO `mny_admin_log` VALUES ('213', '0', '1', '提示语:该页面不存在！', '1663559624', '192.168.103.12', '/member/member/agreement/menuid/161.html');
INSERT INTO `mny_admin_log` VALUES ('214', '0', '1', '提示语:该页面不存在！', '1663559626', '192.168.103.12', '/member/member/hongbao/menuid/158.html');
INSERT INTO `mny_admin_log` VALUES ('215', '0', '1', '提示语:内容包含违禁词！', '1663566356', '127.0.0.1', '/admin/ajax/filterWord');
INSERT INTO `mny_admin_log` VALUES ('216', '1', '1', '提示语:内容没有违禁词！', '1663566375', '127.0.0.1', '/admin/ajax/filterWord');
INSERT INTO `mny_admin_log` VALUES ('217', '1', '1', '提示语:清理缓存', '1663566723', '127.0.0.1', '/admin/index/cache.html?type=all&_=1663559627483');
INSERT INTO `mny_admin_log` VALUES ('218', '1', '1', '提示语:清理缓存', '1663566907', '127.0.0.1', '/admin/index/cache.html?type=all&_=1663559627484');
INSERT INTO `mny_admin_log` VALUES ('219', '0', '1', '提示语:该页面不存在！', '1663567112', '192.168.103.12', '/attachment/attachments/abe1eea3ca79fc28-c577ebdcb0f3dbcc-90cbe8be11bdc6dc3b1edaffdec65ac5.jpg');
INSERT INTO `mny_admin_log` VALUES ('220', '0', '1', '提示语:该页面不存在！', '1663567114', '192.168.103.12', '/attachment/attachments/abe1eea3ca79fc28-c577ebdcb0f3dbcc-90cbe8be11bdc6dc3b1edaffdec65ac5.jpg');
INSERT INTO `mny_admin_log` VALUES ('221', '1', '1', '提示语:清理缓存', '1663567271', '192.168.103.12', '/admin/index/cache.html?type=all&_=1663567060657');
INSERT INTO `mny_admin_log` VALUES ('222', '1', '1', '提示语:更新成功！', '1663569256', '192.168.103.12', '/member/setting/setting/menuid/62.html');
INSERT INTO `mny_admin_log` VALUES ('223', '1', '1', '提示语:更新成功！', '1663569453', '192.168.103.12', '/member/setting/setting/menuid/62.html');
INSERT INTO `mny_admin_log` VALUES ('224', '0', '1', '提示语:该页面不存在！', '1663571706', '192.168.103.12', '/shop/region/delivery.html?id=1');
INSERT INTO `mny_admin_log` VALUES ('225', '1', '1', '提示语:清理缓存', '1663572852', '192.168.103.12', '/admin/index/cache.html?type=all&_=1663567273602');
INSERT INTO `mny_admin_log` VALUES ('226', '0', '0', '提示语:请先登陆', '1663593866', '223.88.87.73', '/admin');
INSERT INTO `mny_admin_log` VALUES ('227', '1', '1', '提示语:恭喜您，登陆成功。', '1663593912', '127.0.0.1', '/admin/index/login');
INSERT INTO `mny_admin_log` VALUES ('228', '1', '1', '提示语:恭喜您，登陆成功。', '1663593969', '223.88.87.73', '/admin/index/login.html');
INSERT INTO `mny_admin_log` VALUES ('229', '0', '0', '提示语:请先登陆', '1663594052', '42.236.10.75', '/admin');
INSERT INTO `mny_admin_log` VALUES ('230', '0', '0', '提示语:请先登陆', '1663594485', '42.192.6.124', '/admin/main/index.html');
INSERT INTO `mny_admin_log` VALUES ('231', '0', '0', '提示语:请先登陆', '1663594753', '42.192.6.124', '/admin/menu/index/menuid/14.html');
INSERT INTO `mny_admin_log` VALUES ('232', '0', '0', '提示语:请先登陆', '1663594759', '42.192.6.124', '/admin');
INSERT INTO `mny_admin_log` VALUES ('233', '0', '0', '提示语:请先登陆', '1663594768', '42.192.6.124', '/admin/menu/index.html?page=1&limit=10&filterRules=%5B%5D&sort=%5B%5D');
INSERT INTO `mny_admin_log` VALUES ('234', '0', '0', '提示语:请先登陆', '1663599697', '42.192.6.124', '/admin/index/index.html');
INSERT INTO `mny_admin_log` VALUES ('235', '1', '1', '提示语:更新成功！', '1663638075', '192.168.103.12', '/shop/setting/index/menuid/110.html');
INSERT INTO `mny_admin_log` VALUES ('236', '1', '1', '提示语:更新成功！', '1663638099', '192.168.103.12', '/shop/setting/index/menuid/110.html');
INSERT INTO `mny_admin_log` VALUES ('237', '1', '1', '提示语:更新成功！', '1663639257', '192.168.103.12', '/shop/setting/index/menuid/110.html');
INSERT INTO `mny_admin_log` VALUES ('238', '1', '1', '提示语:更新成功！', '1663639363', '192.168.103.12', '/shop/setting/index/menuid/110.html');
INSERT INTO `mny_admin_log` VALUES ('239', '1', '1', '提示语:新增成功', '1663639984', '192.168.103.12', '/admin/menu/add.html?parentid=83&dialog=1');
INSERT INTO `mny_admin_log` VALUES ('240', '1', '1', '提示语:修改成功', '1663640009', '192.168.103.12', '/admin/menu/edit.html?id=102&dialog=1');
INSERT INTO `mny_admin_log` VALUES ('241', '1', '1', '提示语:修改成功', '1663640049', '192.168.103.12', '/admin/menu/edit.html?id=102&dialog=1');
INSERT INTO `mny_admin_log` VALUES ('242', '1', '1', '提示语:操作成功！', '1663640068', '192.168.103.12', '/admin/menu/multi.html');
INSERT INTO `mny_admin_log` VALUES ('243', '1', '1', '提示语:修改成功', '1663640083', '192.168.103.12', '/admin/menu/edit.html?id=111&dialog=1');
INSERT INTO `mny_admin_log` VALUES ('244', '1', '1', '提示语:操作成功！', '1663640112', '192.168.103.12', '/admin/menu/multi.html');
INSERT INTO `mny_admin_log` VALUES ('245', '1', '1', '提示语:修改成功', '1663640202', '192.168.103.12', '/admin/menu/edit.html?id=98&dialog=1');
INSERT INTO `mny_admin_log` VALUES ('246', '1', '1', '提示语:新增成功', '1663640249', '192.168.103.12', '/admin/menu/add.html?parentid=83&dialog=1');
INSERT INTO `mny_admin_log` VALUES ('247', '1', '1', '提示语:新增成功', '1663640280', '192.168.103.12', '/admin/menu/add.html?parentid=163&dialog=1');
INSERT INTO `mny_admin_log` VALUES ('248', '1', '1', '提示语:新增成功', '1663640451', '192.168.103.12', '/admin/menu/add.html?parentid=84&dialog=1');
INSERT INTO `mny_admin_log` VALUES ('249', '1', '1', '提示语:修改成功', '1663642958', '192.168.103.12', '/admin/menu/edit.html?id=159&dialog=1');
INSERT INTO `mny_admin_log` VALUES ('250', '0', '0', '提示语:请先登陆', '1663657081', '192.168.103.12', '/shop/region/delivery.html?id=1');
INSERT INTO `mny_admin_log` VALUES ('251', '0', '0', '提示语:请先登陆', '1663657084', '192.168.103.12', '/shop/region/index/menuid/102.html');
INSERT INTO `mny_admin_log` VALUES ('252', '1', '1', '提示语:恭喜您，登陆成功。', '1663657101', '192.168.103.12', '/admin/index/login.html');
INSERT INTO `mny_admin_log` VALUES ('253', '1', '1', '提示语:新增成功', '1663661432', '192.168.103.12', '/admin/menu/add.html?parentid=102&dialog=1');
INSERT INTO `mny_admin_log` VALUES ('254', '1', '1', '提示语:清理缓存', '1663661443', '192.168.103.12', '/admin/index/cache.html?type=all&_=1663657106510');
INSERT INTO `mny_admin_log` VALUES ('255', '1', '1', '提示语:修改成功', '1663661593', '192.168.103.12', '/admin/menu/edit.html?id=166&dialog=1');
INSERT INTO `mny_admin_log` VALUES ('256', '1', '1', '提示语:清理缓存', '1663661597', '192.168.103.12', '/admin/index/cache.html?type=all&_=1663661448831');
INSERT INTO `mny_admin_log` VALUES ('257', '1', '1', '提示语:修改成功', '1663661671', '192.168.103.12', '/admin/menu/edit.html?id=166&dialog=1');
INSERT INTO `mny_admin_log` VALUES ('258', '1', '1', '提示语:清理缓存', '1663661672', '192.168.103.12', '/admin/index/cache.html?type=all&_=1663661603447');
INSERT INTO `mny_admin_log` VALUES ('259', '0', '1', '提示语:该页面不存在！', '1663662088', '192.168.103.12', '/shop/delivery/undefined?dialog=1');
INSERT INTO `mny_admin_log` VALUES ('260', '1', '1', '提示语:操作成功！', '1663672976', '192.168.103.12', '/admin/address/multi.html');
INSERT INTO `mny_admin_log` VALUES ('261', '1', '1', '提示语:操作成功！', '1663672981', '192.168.103.12', '/admin/address/multi.html');
INSERT INTO `mny_admin_log` VALUES ('262', '1', '1', '提示语:操作成功！', '1663674817', '192.168.103.12', '/admin/address/multi.html');
INSERT INTO `mny_admin_log` VALUES ('263', '1', '1', '提示语:操作成功！', '1663674823', '192.168.103.12', '/admin/address/multi.html');
INSERT INTO `mny_admin_log` VALUES ('264', '1', '1', '提示语:操作成功！', '1663674825', '192.168.103.12', '/admin/address/multi.html');
INSERT INTO `mny_admin_log` VALUES ('265', '1', '1', '提示语:操作成功！', '1663674830', '192.168.103.12', '/admin/address/multi.html');
INSERT INTO `mny_admin_log` VALUES ('266', '1', '1', '提示语:添加成功', '1663675645', '192.168.103.12', '/admin/address/add.html?parentid=1&dialog=1');
INSERT INTO `mny_admin_log` VALUES ('267', '0', '1', '提示语:记录未找到', '1663675701', '192.168.103.12', '/admin/address/edit.html?id=3524&dialog=1');
INSERT INTO `mny_admin_log` VALUES ('268', '0', '1', '提示语:记录未找到', '1663675955', '192.168.103.12', '/admin/address/edit.html?id=35&dialog=1');
INSERT INTO `mny_admin_log` VALUES ('269', '0', '1', '提示语:记录未找到', '1663676014', '192.168.103.12', '/admin/address/edit.html?id=3524&dialog=1');
INSERT INTO `mny_admin_log` VALUES ('270', '1', '1', '提示语:添加成功', '1663676067', '192.168.103.12', '/admin/address/add.html?dialog=1');
INSERT INTO `mny_admin_log` VALUES ('271', '0', '1', '提示语:没有数据删除！', '1663676216', '192.168.103.12', '/admin/address/del.html?id=3525');
INSERT INTO `mny_admin_log` VALUES ('272', '0', '1', '提示语:没有数据删除！', '1663676225', '192.168.103.12', '/admin/address/del.html?id=3525');
INSERT INTO `mny_admin_log` VALUES ('273', '0', '1', '提示语:没有数据删除！', '1663676252', '192.168.103.12', '/admin/address/del.html?id=3525');
INSERT INTO `mny_admin_log` VALUES ('274', '1', '1', '提示语:操作成功！', '1663676287', '192.168.103.12', '/admin/address/del.html?id=3525');
INSERT INTO `mny_admin_log` VALUES ('275', '0', '1', '提示语:参数不能为空', '1663676480', '192.168.103.12', '/admin/address/edit.html?id=3524&dialog=1');
INSERT INTO `mny_admin_log` VALUES ('276', '0', '1', '提示语:参数不能为空', '1663676517', '192.168.103.12', '/admin/address/edit.html?id=3524&dialog=1');
INSERT INTO `mny_admin_log` VALUES ('277', '1', '1', '提示语:修改成功', '1663676636', '192.168.103.12', '/admin/address/edit.html?id=3524&dialog=1');
INSERT INTO `mny_admin_log` VALUES ('278', '1', '1', '提示语:修改成功', '1663676690', '192.168.103.12', '/admin/address/edit.html?id=3524&dialog=1');
INSERT INTO `mny_admin_log` VALUES ('279', '1', '1', '提示语:操作成功！', '1663676706', '192.168.103.12', '/admin/address/del.html?id=3524');
INSERT INTO `mny_admin_log` VALUES ('280', '0', '1', '提示语:该页面不存在！', '1663678298', '192.168.103.12', '/shop/delivery/select_city.html');
INSERT INTO `mny_admin_log` VALUES ('281', '0', '0', '提示语:请先登陆', '1663681268', '192.168.103.12', '/admin/index/index.html');
INSERT INTO `mny_admin_log` VALUES ('282', '1', '1', '提示语:恭喜您，登陆成功。', '1663681284', '192.168.103.12', '/admin/index/login.html');
INSERT INTO `mny_admin_log` VALUES ('283', '0', '0', '提示语:请先登陆', '1663685940', '127.0.0.1', '/admin/index/index.html');
INSERT INTO `mny_admin_log` VALUES ('284', '1', '1', '提示语:恭喜您，登陆成功。', '1663685961', '127.0.0.1', '/admin/index/login.html');
INSERT INTO `mny_admin_log` VALUES ('285', '0', '0', '提示语:请先登陆', '1663720573', '192.168.103.12', '/admin/index/index.html');
INSERT INTO `mny_admin_log` VALUES ('286', '0', '0', '提示语:验证码错误!', '1663722356', '192.168.103.12', '/admin/index/login.html');
INSERT INTO `mny_admin_log` VALUES ('287', '1', '1', '提示语:恭喜您，登陆成功。', '1663722367', '192.168.103.12', '/admin/index/login.html');
INSERT INTO `mny_admin_log` VALUES ('288', '1', '1', '提示语:操作成功！', '1663739460', '192.168.103.12', '/admin/address/del.html?id=3526');
INSERT INTO `mny_admin_log` VALUES ('289', '0', '0', '提示语:请先登陆', '1663761771', '192.168.103.12', '/shop/setting/index/menuid/110.html');
INSERT INTO `mny_admin_log` VALUES ('290', '0', '0', '提示语:请先登陆', '1663807458', '192.168.103.12', '/admin/index/index.html');
INSERT INTO `mny_admin_log` VALUES ('291', '1', '1', '提示语:更新成功！', '1663838878', '192.168.103.12', '/shop/setting/index/menuid/110.html');
INSERT INTO `mny_admin_log` VALUES ('292', '1', '1', '提示语:更新成功！', '1663839372', '192.168.103.12', '/shop/setting/index/menuid/110.html');
INSERT INTO `mny_admin_log` VALUES ('293', '1', '1', '提示语:清理缓存', '1663839376', '192.168.103.12', '/admin/index/cache.html?type=all&_=1663807466727');
INSERT INTO `mny_admin_log` VALUES ('294', '1', '1', '提示语:修改成功', '1663841393', '192.168.103.12', '/admin/config/edit.html?id=10&dialog=1');
INSERT INTO `mny_admin_log` VALUES ('295', '1', '1', '提示语:设置更新成功', '1663841403', '192.168.103.12', '/admin/config/setting/group/upload.html');
INSERT INTO `mny_admin_log` VALUES ('296', '1', '1', '提示语:设置更新成功', '1663841410', '192.168.103.12', '/admin/config/setting/group/upload.html');
INSERT INTO `mny_admin_log` VALUES ('297', '1', '1', '提示语:清理缓存', '1663842392', '192.168.103.12', '/admin/index/cache.html?type=all&_=1663842389171');
INSERT INTO `mny_admin_log` VALUES ('298', '1', '1', '提示语:清理缓存', '1663843237', '192.168.103.12', '/admin/index/cache.html?type=all&_=1663842492616');
INSERT INTO `mny_admin_log` VALUES ('299', '1', '1', '提示语:设置更新成功', '1663845505', '192.168.103.12', '/admin/config/setting/group/upload.html');
INSERT INTO `mny_admin_log` VALUES ('300', '1', '1', '提示语:清理缓存', '1663848340', '192.168.103.12', '/admin/index/cache.html?type=all&_=1663842492617');
INSERT INTO `mny_admin_log` VALUES ('301', '1', '1', '提示语:操作成功！', '1663848472', '192.168.103.12', '/admin/menu/multi.html');
INSERT INTO `mny_admin_log` VALUES ('302', '1', '1', '提示语:清理缓存', '1663848597', '192.168.103.12', '/admin/index/cache.html?type=all&_=1663848478299');
INSERT INTO `mny_admin_log` VALUES ('303', '0', '1', '提示语:Undefined index: status', '1663848839', '192.168.103.12', '/addons/addons/uninstall.html?name=qiniu');
INSERT INTO `mny_admin_log` VALUES ('304', '0', '1', '提示语:插件主启动程序不存在', '1663848921', '192.168.103.12', '/addons/addons/install.html?name=qiniu');
INSERT INTO `mny_admin_log` VALUES ('305', '0', '1', '提示语:插件主启动程序不存在', '1663848927', '192.168.103.12', '/addons/addons/install.html?name=qiniu');
INSERT INTO `mny_admin_log` VALUES ('306', '0', '1', '提示语:插件主启动程序不存在', '1663848940', '192.168.103.12', '/addons/addons/install.html?name=qiniu');
INSERT INTO `mny_admin_log` VALUES ('307', '0', '0', '提示语:请先登陆', '1663849699', '192.168.103.12', '/admin/index/index.html');
INSERT INTO `mny_admin_log` VALUES ('308', '0', '1', '提示语:插件主启动程序不存在', '1663849714', '192.168.103.12', '/addons/addons/install.html?name=qiniu');
INSERT INTO `mny_admin_log` VALUES ('309', '0', '0', '提示语:请先登陆', '1663849752', '127.0.0.1', '/admin/index/index.html');
INSERT INTO `mny_admin_log` VALUES ('310', '0', '1', '提示语:插件主启动程序不存在', '1663850333', '192.168.103.12', '/addons/addons/install.html?name=qiniu');
INSERT INTO `mny_admin_log` VALUES ('311', '0', '1', '提示语:插件主启动程序不存在', '1663850550', '192.168.103.12', '/addons/addons/install.html?name=qiniu');
INSERT INTO `mny_admin_log` VALUES ('312', '0', '1', '提示语:插件主启动程序不存在', '1663850589', '192.168.103.12', '/addons/addons/install.html?name=qiniu');
INSERT INTO `mny_admin_log` VALUES ('313', '1', '1', '提示语:恭喜您，登陆成功。', '1663854377', '127.0.0.1', '/admin/index/login.html');
INSERT INTO `mny_admin_log` VALUES ('314', '0', '1', '提示语:插件主启动程序不存在', '1663854606', '127.0.0.1', '/addons/addons/install.html?name=qiniu');
INSERT INTO `mny_admin_log` VALUES ('315', '0', '1', '提示语:插件主启动程序不存在', '1663854612', '127.0.0.1', '/addons/addons/install.html?name=qiniu');
INSERT INTO `mny_admin_log` VALUES ('316', '0', '1', '提示语:插件主启动程序不存在', '1663854689', '127.0.0.1', '/addons/addons/install.html?name=qiniu');
INSERT INTO `mny_admin_log` VALUES ('317', '1', '1', '提示语:设置更新成功', '1663857342', '127.0.0.1', '/admin/config/setting/group/upload.html');
INSERT INTO `mny_admin_log` VALUES ('318', '1', '1', '提示语:设置更新成功', '1663858299', '127.0.0.1', '/admin/config/setting/group/system.html');
INSERT INTO `mny_admin_log` VALUES ('319', '0', '0', '提示语:请先登陆', '1663895672', '192.168.103.12', '/admin/index/index.html');
INSERT INTO `mny_admin_log` VALUES ('320', '1', '1', '提示语:恭喜您，登陆成功。', '1663895683', '192.168.103.12', '/admin/index/login.html');
INSERT INTO `mny_admin_log` VALUES ('321', '1', '1', '提示语:更新成功！', '1663896153', '192.168.103.12', '/shop/setting/index/menuid/110.html');
INSERT INTO `mny_admin_log` VALUES ('322', '1', '1', '提示语:更新成功！', '1663896450', '192.168.103.12', '/shop/setting/index/menuid/110.html');
INSERT INTO `mny_admin_log` VALUES ('323', '1', '1', '提示语:更新成功！', '1663918653', '192.168.103.12', '/shop/setting/index/menuid/110.html');
INSERT INTO `mny_admin_log` VALUES ('324', '1', '1', '提示语:更新成功！', '1663923849', '192.168.103.12', '/shop/setting/index/menuid/110.html');
INSERT INTO `mny_admin_log` VALUES ('325', '1', '1', '提示语:更新成功！', '1663927154', '192.168.103.12', '/shop/setting/index/menuid/110.html');
INSERT INTO `mny_admin_log` VALUES ('326', '1', '1', '提示语:更新成功！', '1663927167', '192.168.103.12', '/shop/setting/index/menuid/110.html');
INSERT INTO `mny_admin_log` VALUES ('327', '0', '0', '提示语:请先登陆', '1663985048', '127.0.0.1', '/admin/index/index.html');
INSERT INTO `mny_admin_log` VALUES ('328', '1', '1', '提示语:恭喜您，登陆成功。', '1663985141', '127.0.0.1', '/admin/index/login.html');
INSERT INTO `mny_admin_log` VALUES ('329', '0', '0', '提示语:请先登陆', '1663989905', '127.0.0.1', '/admin/index/index.html');
INSERT INTO `mny_admin_log` VALUES ('330', '1', '1', '提示语:恭喜您，登陆成功。', '1663989920', '127.0.0.1', '/admin/index/login.html');
INSERT INTO `mny_admin_log` VALUES ('331', '0', '0', '提示语:请先登陆', '1663991143', '127.0.0.1', '/admin');
INSERT INTO `mny_admin_log` VALUES ('332', '1', '1', '提示语:恭喜您，登陆成功。', '1663991160', '127.0.0.1', '/admin/index/login.html');
INSERT INTO `mny_admin_log` VALUES ('333', '0', '1', '提示语:插件主启动程序不存在', '1663991251', '127.0.0.1', '/addons/addons/install.html?name=qiniu');
INSERT INTO `mny_admin_log` VALUES ('334', '1', '1', '提示语:插件安装成功！清除浏览器缓存和框架缓存后生效！', '1664022931', '127.0.0.1', '/addons/addons/install.html?name=qiniu');
INSERT INTO `mny_admin_log` VALUES ('335', '1', '1', '提示语:插件安装成功！清除浏览器缓存和框架缓存后生效！', '1664023153', '127.0.0.1', '/addons/addons/install.html?name=easysms');
INSERT INTO `mny_admin_log` VALUES ('336', '1', '1', '提示语:操作成功！', '1664023235', '127.0.0.1', '/admin/menu/multi.html');
INSERT INTO `mny_admin_log` VALUES ('337', '1', '1', '提示语:插件配置成功！', '1664032818', '127.0.0.1', '/addons/addons/config.html?name=qiniu');
INSERT INTO `mny_admin_log` VALUES ('338', '1', '1', '提示语:设置更新成功', '1664033237', '127.0.0.1', '/admin/config/setting/group/upload.html');
INSERT INTO `mny_admin_log` VALUES ('339', '1', '1', '提示语:插件安装成功！清除浏览器缓存和框架缓存后生效！', '1664033455', '127.0.0.1', '/addons/addons/install.html?name=loginbg');
INSERT INTO `mny_admin_log` VALUES ('340', '0', '0', '提示语:请先登陆', '1664033471', '127.0.0.1', '/admin');
INSERT INTO `mny_admin_log` VALUES ('341', '1', '1', '提示语:清理缓存', '1664033729', '127.0.0.1', '/admin/index/cache.html?type=all&_=1664033447707');
INSERT INTO `mny_admin_log` VALUES ('342', '1', '1', '提示语:插件卸载成功！清除浏览器缓存和框架缓存后生效！', '1664034491', '127.0.0.1', '/addons/addons/uninstall.html?name=easysms');
INSERT INTO `mny_admin_log` VALUES ('343', '1', '1', '提示语:插件安装成功！清除浏览器缓存和框架缓存后生效！', '1664034502', '127.0.0.1', '/addons/addons/install.html?name=easysms');
INSERT INTO `mny_admin_log` VALUES ('344', '1', '1', '提示语:操作成功！', '1664034688', '127.0.0.1', '/admin/menu/multi.html');
INSERT INTO `mny_admin_log` VALUES ('345', '1', '1', '提示语:插件安装成功！清除浏览器缓存和框架缓存后生效！', '1664034787', '127.0.0.1', '/addons/addons/install.html?name=database');
INSERT INTO `mny_admin_log` VALUES ('346', '1', '1', '提示语:初始化成功！', '1664034899', '127.0.0.1', '/addons/database/export/isadmin/1.html');
INSERT INTO `mny_admin_log` VALUES ('347', '1', '1', '提示语:正在备份...(28%)', '1664034900', '127.0.0.1', '/addons/database/export/isadmin/1.html?id=0&start=0');
INSERT INTO `mny_admin_log` VALUES ('348', '1', '1', '提示语:正在备份...(56%)', '1664034901', '127.0.0.1', '/addons/database/export/isadmin/1.html?id=0&start=1000');
INSERT INTO `mny_admin_log` VALUES ('349', '1', '1', '提示语:正在备份...(85%)', '1664034902', '127.0.0.1', '/addons/database/export/isadmin/1.html?id=0&start=2000');
INSERT INTO `mny_admin_log` VALUES ('350', '1', '1', '提示语:备份完成！', '1664034903', '127.0.0.1', '/addons/database/export/isadmin/1.html?id=0&start=3000');
INSERT INTO `mny_admin_log` VALUES ('351', '1', '1', '提示语:备份完成！', '1664034903', '127.0.0.1', '/addons/database/export/isadmin/1.html?id=1&start=0');

-- -----------------------------
-- Table structure for `mny_article`
-- -----------------------------
DROP TABLE IF EXISTS `mny_article`;
CREATE TABLE `mny_article` (
  `id` mediumint unsigned NOT NULL AUTO_INCREMENT COMMENT '文档ID',
  `region_id` int DEFAULT '0' COMMENT '区域id值',
  `type` smallint unsigned NOT NULL DEFAULT '0' COMMENT '1：官方公告  2：轮播图广告',
  `title` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT '标题',
  `thumb` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '缩略图',
  `listorder` smallint unsigned NOT NULL DEFAULT '100' COMMENT '排序',
  `hits` mediumint unsigned DEFAULT '0' COMMENT '点击量',
  `inputtime` int unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `updatetime` int unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `url` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '链接地址',
  `status` tinyint NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `status` (`type`,`status`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='文章模型模型表';

-- -----------------------------
-- Records of `mny_article`
-- -----------------------------
INSERT INTO `mny_article` VALUES ('1', '1', '9', '让客户留住更长时间访问你的网站', '', '100', '0', '1550188136', '1550476672', '', '1');
INSERT INTO `mny_article` VALUES ('2', '1', '9', '移动网站需要吸引哪些观众并将其转化为客户', '', '100', '0', '1550202861', '1550450153', '', '1');
INSERT INTO `mny_article` VALUES ('3', '1', '14', '空壳网站是什么？如何避免成为空壳网站？空壳网站怎么处理？', '', '100', '0', '1550448808', '1550476816', '', '1');
INSERT INTO `mny_article` VALUES ('4', '', '14', '单位或网站涉及金融类关键词，办理网站备案注意事项', '', '100', '0', '1550449235', '1550449733', '', '1');
INSERT INTO `mny_article` VALUES ('5', '', '10', '个人建设网站有哪些步骤？', '', '100', '1', '1550449817', '1550476910', '', '1');
INSERT INTO `mny_article` VALUES ('6', '', '10', '企业建设手机网站注意的事项？', '', '100', '0', '1550450424', '1550476700', '', '1');
INSERT INTO `mny_article` VALUES ('7', '', '6', '123123', '', '100', '0', '1661157259', '1661193133', '', '1');

-- -----------------------------
-- Table structure for `mny_article_data`
-- -----------------------------
DROP TABLE IF EXISTS `mny_article_data`;
CREATE TABLE `mny_article_data` (
  `did` mediumint unsigned NOT NULL DEFAULT '0',
  `content` mediumtext CHARACTER SET utf8 COLLATE utf8_unicode_ci COMMENT '内容',
  PRIMARY KEY (`did`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='文章模型模型表';

-- -----------------------------
-- Records of `mny_article_data`
-- -----------------------------
INSERT INTO `mny_article_data` VALUES ('1', '&lt;p&gt;&lt;strong&gt;通过网站让客户“一见钟情”&lt;/strong&gt;&lt;/p&gt;&lt;p&gt;什么能让您的客户“一见钟情”？除了网站的界面，没有其他因素。网站的界面是非常重要的因素之一。因为这是客户访问网站时的第一印象。那时，您需要为客户提供一个吸引人且引人注目的界面。要做到这一点非常容易，你只需要有一个合理布局的界面，整洁不要分散读者的注意力。在与网站互动时，客户可以轻松搜索他们需要学习的信息。此外，您还可以使用一些额外的注释来使界面更加美观：首先，效果的最大效果用于避免分散用户的注意力。这些效果甚至会使网站更重，并且加载速度更慢。其次，您可以创建更多可用空间并消除不重要的信息，从而使关键消息更容易，更快地到达客户。&amp;nbsp;&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;p&gt;&lt;strong&gt;内容不仅要有回报，还应该精美呈现&lt;/strong&gt;&lt;/p&gt;&lt;p&gt;对客户有用的内容是让客户保持更长时间的首要因素之一。但是，不仅昂贵的信息足够，内容的呈现和格式是您的网站有更长的时间留在客户的技巧。您可以设计一个白色背景的网站，以便所有信息变得更加突出。绝对不要使用色彩鲜艳的花朵和图案的深色背景，因为它可能使读者难以获取信息。此外，字体用法和段落间距同样重要。选择的字体不应该太挑剔，时尚，但应该是简单，易于看到的字体和显示专业性。附加，线条之间应该是合理的距离，内容布局的段落更加开放。&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;p&gt;&lt;strong&gt;优化网站以与所有设备兼容&lt;/strong&gt;&lt;/p&gt;&lt;p&gt;通常情况下，企业只能优化显示在计算机或笔记本电脑上，但往往会忽略各种其他重要设备，如智能手机或平板电脑等。但是，用户数量的情况随着移动设备的访问越来越多，新网站可确保与设备（包括移动设备）的兼容性。&amp;nbsp;&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;p&gt;&lt;strong&gt;适当地浏览网站中的信息&lt;/strong&gt;&lt;/p&gt;&lt;p&gt;如果您通过主页给客户留下了深刻印象，客户一直渴望了解您的业务。为了使此过程更好地运行，您需要确保子页面的所有链接与前面提到的链接标题的内容一致。\r\n您还可以为关键位置的内容创建重音，以提高点击率。而且您也不要忘记确保您没有基本错误，例如链接到损坏的页面，丢失图像甚至丢失链接。&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;p&gt;&lt;strong&gt;定期更新网站内容&lt;/strong&gt;&lt;/p&gt;&lt;p&gt;内容不需要质量，但在网站上也需要有数量。这里的金额并不意味着猖獗的金额，而是每天都是偶数。如果客户返回您的网站但仍然是旧内容，则您可能会失去客户，因为客户不想返回网站更新旧内容。\r\n有了这些提示，您需要立即更新缺少的元素以完成网站并留住客户。做好这些事情后，您会很快注意到您网站的跳出率大&lt;/p&gt;');
INSERT INTO `mny_article_data` VALUES ('2', '&lt;p&gt;在移动设备上设计网站以吸引观众并使他们成为他们的客户并不容易。移动网站是否只有两个友好元素，下载速度是否足够快？&lt;br/&gt;&lt;/p&gt;&lt;p&gt;使用移动设备访问网站的人是那些时间很少的人，所以他们总是希望事情快速而正确。&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;p&gt;&lt;strong&gt;1：并非计算机上显示的所有内容都需要显示在移动设备上&lt;/strong&gt;&lt;/p&gt;&lt;p&gt;很容易看出微小的移动屏幕不能像计算机那样宽，因此需要选择出现在移动屏幕上的网站内容。重要内容，您需要将它们推上去，以便它们可以显示在移动屏幕上&lt;/p&gt;&lt;p&gt;还需要选择移动屏幕上显示的网站内容&lt;br/&gt;&lt;br/&gt;&lt;/p&gt;&lt;p&gt;&lt;strong&gt;2：网站下载速度&lt;/strong&gt;&lt;/p&gt;&lt;p&gt;专业网站设计师应该始终关注的一件事是下载网站的速度。根据一项研究，谷歌正在研究，53％的用户将离开一个网站，如果下载需要超过3秒。提高网站的下载速度有时只是为了删除图像，减少图像的大小是网站可以更快下载。但是，有时原因比我们想象的更复杂，例如，原因来自网站代码，或者可能是因为您的网站开发的内容远远超过原始网站，而且当前主机不再响应了。&lt;/p&gt;&lt;p&gt;所以你需要找出你的网站下载速度慢的原因以及在哪里立即修复它。&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;p&gt;&lt;strong&gt;3：添加通话按钮&lt;/strong&gt;&lt;/p&gt;&lt;p&gt;对于移动用户，尤其是移动用户访问网站，他们说话的时间非常重要。因此，在查看产品信息之后，他们会立即打电话询问产品。但你确定他们会耐心等待撤回并找到你的电话号码吗？绝对不是。现在，移动屏幕上始终可用的简单呼叫按钮是可以立即按下客户想要呼叫的最全面的解决方案。&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;p&gt;&lt;strong&gt;4：集成返回顶部按钮&lt;/strong&gt;&lt;/p&gt;&lt;p&gt;对于网站，菜单始终是一个重要的导航栏，可帮助用户导航到网站内的子页面。对于某些网站，当用户向下滚动并阅读下面的内容时，此菜单栏将始终显示在屏幕上。但是，其他一些网站没有。因此，当用户在网站底部附近阅读时，想要查看菜单，他们必须进行大量冲浪，现在，返回顶部按钮将非常有效并让用户感到舒适。&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;p&gt;&lt;strong&gt;5：网站上的菜单&lt;/strong&gt;&lt;/p&gt;&lt;p&gt;与网站显示在计算机上的不同，手机上显示的网站菜单将减少到一行。当您想要查看时，用户将单击以显示子菜单。菜单图标现在是3个图块，但不是每个人都知道图标是菜单，因此如果您想让它更容易理解，您可以立即编写菜单字母。&lt;/p&gt;');
INSERT INTO `mny_article_data` VALUES ('6', '&lt;p&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp;虽然很多企业都专门弄起了APP软件，不过从综合层面来说，还是网站更加靠谱一些，因为网站比制作APP成本要低廉很多，而且受传统思维习惯的影响，大部分的会主动寻找相关内容的人来说，他们还是更加习惯利用搜索引擎去进行寻找。并且这一群人在社会上面也拥有一定的社会经验以及地位，像是销售人员、采购人员等等，如果他们不再办公室，正好在上班途中或者是出差途中的话，肯定是需要使用手机来搜索某些信息的，所以从实用性角度来看的话，反倒是企业网站比APP更好一些，那么，企业建设手机网站的时候要注意什么?&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;p&gt;&lt;strong&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp;第一、图片设计&lt;/strong&gt;&lt;/p&gt;&lt;p&gt;  虽然当前的手机企业网站在建设的时候都是弄成的响应式网站，它可以按照上网具体设备的不同，而自动调整成符合当前屏幕大小的格式，但是只要稍微留心一些，就会发现，就算是那些超级大型的网站，他们在图片处理方面都已经十分谨慎了，还是会出现因为图片出现一些问题，因为只要出现图片就会消耗流量，另外如果图片太多的话，也会导致企业网站页面的加载速度变得非常慢，导致用户体验严重受到影响，因此在不是特别有必要的情况之下，最好还是少使用图片比较合适。&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;p&gt;  &lt;strong&gt;第二、页面简洁&lt;/strong&gt;&lt;/p&gt;&lt;p&gt;  既然是建设手机企业网站，那在设计的时候建议还是弄得简单一些更合适，不需要像电脑PC端的网站一样弄很多的内容，因为手机本身的屏幕就要比PC端小很多，如果手机企业网站建设的时候设计很多的内容，会导致人们浏览起来变得比较困难的，特别是用内容作为主导倾向的网站，建设成简洁的形式，更加容易让网友找到自己需要的信息&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;p&gt;  &lt;strong&gt;第三、断点功能&lt;/strong&gt;&lt;/p&gt;&lt;p&gt;  对于移动网站的断点设置，在CSS模式样式中，都支持断点功能设置，而传统PC端网站就缺少这个功能设置，所以经常会出现网站显示不合理，大量乱码等现象。但是，网站断点功能并非就保证网站访问流畅，对于断点技术的研究，还在进一步探讨中，比如说，在移动设备显示不错的网站，可是反过来用PC端却显示紊乱，在特别注重移动端网站的时候，也要注意到传统网站的感受，只要这样全兼容的设计，才符合未来网站的发展方向。&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;');
INSERT INTO `mny_article_data` VALUES ('3', '&lt;p&gt;一、备案数据，包括：主体信息、网站信息、接入信息。&lt;/p&gt;&lt;p&gt;（1）主体信息是指，网站主办者（网站开办者）的注册信息。&lt;/p&gt;&lt;p&gt;（2）网站信息是指，网站主办者开办的（一个或多个）网站的注册信息。&lt;/p&gt;&lt;p&gt;（3）接入信息是指，网站主办者（每个）网站的数据存放的虚拟空间的接入信息。&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;p&gt;二、空壳类备案数据，包括:空壳主体和空壳网站。&lt;/p&gt;&lt;p&gt;（1）空壳主体是指，在工业和信息化部备案系统中，网站主办者的历史备案信息只存在主体信息，没有网站信息和接入信息。&lt;/p&gt;&lt;p&gt;（2）空壳网站是指，在工业和信息化部备案系统中，网站主办者的历史备案信息中含有主体信息和网站信息，但（一个或多个网站）没有接入信息（即网站有备案号，但由于网站实际使用空间IP地址变更，之前空间接入商已将网站的备案信息取消接入，同时网站主办者并没有在新的空间接入商办理备案信息转接入）。&lt;/p&gt;&lt;p&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp; 通俗来讲，空壳网站是指，用户域名绑定IP发生变更（主要是更换了不同空间接入商IP），但备案信息没有及时变更，因此就变成了空壳网站。&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;p&gt;三、空壳类备案数据处理方式。&lt;/p&gt;&lt;p&gt;（1）若网站主办者存在空壳主体信息，则唯一解决方式：&lt;/p&gt;&lt;p&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp; 需网站主办者携带相关证件到网站实际的接入商重新办理备案。已被注销（收回）的备案号及备案信息无法恢复。&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;p&gt;四、如何避免成为空壳类数据。&lt;/p&gt;&lt;p&gt;（1）不可随意变更域名绑定IP（若需变更请及时联系网站实际使用的空间接入商）；&lt;/p&gt;&lt;p&gt;以此避免因未及时变更网站备案接入信息，而成为空壳类备案数据，从而被当地省通信管理局注销（收回）备案号。&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;p&gt;五、办理网站备案真实性核验，请网站负责人携带以下材料：&lt;/p&gt;&lt;p&gt;（1）本人身份证原件&lt;/p&gt;&lt;p&gt;（2）单位有效证件（含年检页）原件&lt;/p&gt;&lt;p&gt;（3）企业法人身份证原件&lt;/p&gt;&lt;p&gt;（4）单位公章&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;');
INSERT INTO `mny_article_data` VALUES ('4', '&lt;ol class=&quot; list-paddingleft-2&quot; style=&quot;list-style-type: decimal;&quot;&gt;&lt;li&gt;&lt;p&gt;根据《国务院办公厅关于印发互联网金融风险专项整治工作实施方案的通知（国办发〔2016〕21号）》要求，公司注册名称或经营范围中使用“交易所”、“交易中心”、“金融”、“资产管理”、“理财”、“基金”、“基金管理”、“投资管理（包括投资）”、“财富管理”、“股权投资基金”、“网贷”、“网络借贷”、“P2P”、“股权众筹”、“互联网保险”、“支付”、“信托”等字样的企业，在做网站备案业务办理时，需提供金融管理部门的专项审批文件。&lt;/p&gt;&lt;/li&gt;&lt;/ol&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;p&gt;2.无相关金融许可的不允许接入。若网站内容确实和金融活动无关的，需要用户更改公司注册名称或经营范围，否则不予备案。&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;p&gt;3.对于上述存量网站，备案中心将会不定期进行核查，一旦发现违规从事金融活动，将直接予以注销备案号处置。&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;p&gt;4.（仅供参考）涉及金融类业务相关许可证办理部门：&lt;/p&gt;&lt;p&gt;&amp;nbsp; ① p2p网站需要金融办和银监会两家一起发的许可证；&lt;/p&gt;&lt;p&gt;&amp;nbsp; ② 股票、公募基金是证监会发的证；&lt;/p&gt;&lt;p&gt;&amp;nbsp; ③ 私募基金是证券协会的备案（股权投资指的就是私募基金）；&lt;/p&gt;&lt;p&gt;&amp;nbsp; ④ 小额贷款是银监会发证；&lt;/p&gt;&lt;p&gt;&amp;nbsp; ⑤ 第三方支付是人民银行发证；&lt;/p&gt;&lt;p&gt;&amp;nbsp; ⑥ 保险是保监会发证；&lt;/p&gt;&lt;p&gt;&amp;nbsp; ⑦ 金融机构发证比如银行什么的都是银监会；&lt;/p&gt;&lt;p&gt;&amp;nbsp; ⑧ 证券公司发证都是证监会；&lt;/p&gt;&lt;p&gt;&amp;nbsp; ⑨ 信托公司是银监会；&lt;/p&gt;');
INSERT INTO `mny_article_data` VALUES ('5', '&lt;p&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp;虽然互联网上付费提供网站建设和网站制作服务的公司或者个人有很多，都是为企业或者个人提供网站建设和网页设计服务的，但是对于那些刚刚走出校门或者刚刚参加工作的朋友来说，如果想通过互联网创业，想要做一个自己的网站，但是又没有明确的经营理念，只是想要尝试一下互联网创业，这时候大部分人都会选择自己建网站，一方面是为了能够节省较高的网站建设费用，另一方面也可以简单的学习一些网站建设或网站制作的一些基本知识，那么自己建网站到底应该如何入手呢今天小编就跟大家写一篇自己建网站的全攻略，希望能够帮助那些想要自己建网站的朋友有一个系统的认识和了解。&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;p&gt;&lt;strong&gt;1、了解基础的脚本语言&lt;/strong&gt;&lt;/p&gt;&lt;p&gt;  无论你是打算用网络上分享出来的免费源代码做网站还是用自助建站系统来建网站，首先应该学习和了解的就是网站前台脚本语言，网站前台脚本语言主要是html/js/css这三种，其中html是客户端网页源代码的主要语言，js脚本语言用来实现各种网页特效，css脚本语言用来实现网站的各种布局及网页色调的调整。&lt;/p&gt;&lt;p&gt;  相对于php、java等编程语言来说，脚本语言更加容易记忆和学习，所以一般想要接触网站建设的朋友都应该首先学习和认识上边说道的三种脚本语言。&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;p&gt;&lt;strong&gt;2、免费的源码程序&lt;/strong&gt;&lt;/p&gt;&lt;p&gt;  对于刚学网站建设的朋友来说，自己建网站肯定不可能上来就自己写一套强大的网站CMS系统，这几乎是不可能的，而且也是不现实的，毕竟一套功能强大的网站管理系统往往都是很多人开发测试很久才能完成的，依靠一个人的力量快速的完全一套建站系统显然难度很大，所以这就需要借助网络上已经分享出来的免费网站源码程序来快速完成自己建网站的目的。&lt;/p&gt;&lt;p&gt;  自建网站虽然除了使用免费的源码程序还可以通过选择一些免费的自助建站平台来完成，但是小编这里推荐大家使用免费的源码程序来做网站，这样一方面是保证网站最终的控制权在自己手里，另一方面也有助于更好的提升自己的网站建设的认识和熟悉，如果你使用自助建站平台，永远都不可能明白网站开发的基本框架设计，但是你通过研究别人分享出来的免费源码就可以很好的掌握整个程序的框架结构和页面设计方面的一些知识，能够更好的提升自己的专业技能。&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;p&gt;&lt;strong&gt;3、服务器及域名&lt;/strong&gt;&lt;/p&gt;&lt;p&gt;  通过学习第一步骤的那些前台脚本语言，然后按照第二步骤说的去下载和研究别人的源码程序，相信很快你就可以自己建网站了，但是建立好的网站如果只是在本地运行，那只有你自己可以访问和看到，如何才能让网络上的所有人都看到自己做的网站呢，这就涉及到了网站的发布，网站发布就需要使用服务器和域名，这时候就需要我们去接触服务器和域名。&lt;/p&gt;&lt;p&gt;  虽然说大部分的新手自己建网站都不希望花费太高的成本，但是服务器和域名的成本是每一个做网站的人都要承担的，而且一个稳定的服务器直接影响到你网站将来的打开速度、网站性能及搜索引擎收录情况，所以建议新手们在购买服务器的时候还是要选择性价比比较高的服务器。&lt;/p&gt;&lt;p&gt;  哦，最后还得补充一下，要想自己建网站，除了上边说道的这些都必须要学习和了解之外，还有两个重要的软件需要下载安装和学习怎么使用，一个是Dreamweaver(简称DW)另一个就是Photoshop(简称PS)这两款软件即使你不打算自己开发设计，你就是研究和修改别人的源码程序也一样需要用到，比如你在步骤二中需要修改别人的网页代码，肯定需要用DW打开网页文件来编辑，需要修改别人程序的中图标或者图片就肯定需要使用PS来作图，所以这两款软件也是自己建网站过程中必须要学习使用的。&lt;/p&gt;');

-- -----------------------------
-- Table structure for `mny_attachment`
-- -----------------------------
DROP TABLE IF EXISTS `mny_attachment`;
CREATE TABLE `mny_attachment` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `aid` smallint unsigned NOT NULL DEFAULT '0' COMMENT '管理员id',
  `uid` mediumint unsigned NOT NULL DEFAULT '0' COMMENT '用户id',
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '文件名',
  `module` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '模块名，由哪个模块上传的',
  `path` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '文件路径',
  `thumb` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '缩略图路径',
  `url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '文件链接',
  `mime` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '文件mime类型',
  `ext` varchar(4) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '文件类型',
  `size` int unsigned NOT NULL DEFAULT '0' COMMENT '文件大小',
  `md5` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '文件md5',
  `sha1` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'sha1 散列值',
  `driver` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'local' COMMENT '上传驱动',
  `create_time` int unsigned NOT NULL DEFAULT '0' COMMENT '上传时间',
  `update_time` int unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `listorders` int NOT NULL DEFAULT '100' COMMENT '排序',
  `status` tinyint NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='附件表';

-- -----------------------------
-- Records of `mny_attachment`
-- -----------------------------
INSERT INTO `mny_attachment` VALUES ('7', '1', '0', '111.jpg', '', '/uploads/images/20220919/458f20886a34ddbaed66a6eaa48442aa.jpg', '', '', 'image/jpeg', 'jpg', '65263', '458f20886a34ddbaed66a6eaa48442aa', 'e550a2315cbccb3c0fbb6ea7eaca6dda3368e9d5', 'local', '1663568563', '1663568563', '100', '1');
INSERT INTO `mny_attachment` VALUES ('8', '1', '0', 'cbc21f747f4c56bd106bb8d79ad19280.jpeg', '', '/uploads/images/20220920/c3575ec4b98df4181618d3e65eb5d13c.jpeg', '', '', 'image/jpeg', 'jpeg', '1365979', 'c3575ec4b98df4181618d3e65eb5d13c', '0c07e21aaf900e6501a0bed14ef127728235542c', 'local', '1663638071', '1663638071', '100', '1');
INSERT INTO `mny_attachment` VALUES ('9', '1', '0', '6e54fa5eb34300eda5140c654822cdae.jpeg', '', '/uploads/images/20220922/6a4c2eb397afcda905d30b41ff89f6ed.jpeg', '', '', 'image/jpeg', 'jpeg', '36869', '6a4c2eb397afcda905d30b41ff89f6ed', '68432b725f8c024133a011b9de899fa1c01082e7', 'local', '1663857167', '1663857167', '100', '1');
INSERT INTO `mny_attachment` VALUES ('10', '1', '0', '1b567f2cfd9750e73938334327a64bdd.jpeg', '', '/uploads/images/20220922/13129ba25ad6e3760716d5f039658374.jpeg', '', '', 'image/jpeg', 'jpeg', '108577', '13129ba25ad6e3760716d5f039658374', '2bd2e8079ec109d9050966e3018bb44f71840cec', 'local', '1663857282', '1663857282', '100', '1');
INSERT INTO `mny_attachment` VALUES ('11', '1', '0', '微信图片_20220711123622.jpg', '', 'http://cdn.angoukeji.com/images/20220924/184ac2e72d736ff295596f2284857762.jpg', '', '', 'image/jpeg', 'jpg', '20450', '184ac2e72d736ff295596f2284857762', '16f9ab9a49fab7ee5a6f82071f6790f39e748bae', 'qiniu', '1664033231', '1664033231', '100', '1');

-- -----------------------------
-- Table structure for `mny_auth_group`
-- -----------------------------
DROP TABLE IF EXISTS `mny_auth_group`;
CREATE TABLE `mny_auth_group` (
  `id` mediumint unsigned NOT NULL AUTO_INCREMENT COMMENT '用户组id,自增主键',
  `parentid` mediumint unsigned NOT NULL DEFAULT '0' COMMENT '父组别',
  `module` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '用户组所属模块',
  `type` tinyint NOT NULL COMMENT '组类型',
  `title` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '用户组中文名称',
  `description` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '描述信息',
  `rules` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '用户组拥有的规则id，多个规则 , 隔开',
  `status` tinyint NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='权限组表';

-- -----------------------------
-- Records of `mny_auth_group`
-- -----------------------------
INSERT INTO `mny_auth_group` VALUES ('1', '0', 'admin', '1', '超级管理员', '拥有所有权限', '*', '1');
INSERT INTO `mny_auth_group` VALUES ('2', '1', 'admin', '1', '文章编辑员', '编辑', '', '1');

-- -----------------------------
-- Table structure for `mny_auth_rule`
-- -----------------------------
DROP TABLE IF EXISTS `mny_auth_rule`;
CREATE TABLE `mny_auth_rule` (
  `id` mediumint unsigned NOT NULL AUTO_INCREMENT COMMENT '规则id,自增主键',
  `module` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '规则所属module',
  `type` tinyint NOT NULL DEFAULT '1' COMMENT '1-url;2-主菜单',
  `name` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '规则唯一英文标识',
  `title` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '规则中文描述',
  `condition` varchar(300) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '规则附加条件',
  `status` tinyint NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `module` (`module`,`status`,`type`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=146 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='规则表';

-- -----------------------------
-- Records of `mny_auth_rule`
-- -----------------------------
INSERT INTO `mny_auth_rule` VALUES ('1', 'admin', '2', 'admin/setting/index', '设置', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('2', 'admin', '1', 'admin/profile/index', '个人资料', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('3', 'admin', '1', 'admin/profile/update', '资料更新', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('4', 'admin', '1', 'admin/config/index1', '系统配置', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('5', 'admin', '1', 'admin/config/index', '配置管理', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('6', 'admin', '1', 'admin/adminlog/deletelog', '删除日志', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('7', 'admin', '1', 'admin/config/setting', '网站设置', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('8', 'admin', '1', 'admin/menu/index', '菜单管理', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('9', 'admin', '1', 'admin/manager/index1', '权限管理', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('10', 'admin', '1', 'admin/manager/index', '管理员管理', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('11', 'admin', '1', 'admin/authManager/index', '角色管理', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('12', 'admin', '1', 'admin/manager/add', '添加管理员', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('13', 'admin', '1', 'admin/manager/edit', '编辑管理员', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('14', 'admin', '1', 'admin/adminlog/index', '管理日志', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('15', 'admin', '1', 'admin/manager/del', '删除管理员', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('16', 'admin', '1', 'admin/authManager/createGroup', '添加角色', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('17', 'admin', '1', 'admin/config/multi', '批量更新', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('18', 'admin', '1', 'admin/menu/add', '新增菜单', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('19', 'admin', '1', 'admin/menu/edit', '编辑菜单', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('20', 'admin', '1', 'admin/menu/del', '删除菜单', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('21', 'admin', '1', 'admin/menu/multi', '批量更新', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('22', 'attachment', '1', 'attachment/attachments/upload', '附件上传', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('23', 'attachment', '1', 'attachment/attachments/del', '附件删除', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('24', 'attachment', '1', 'attachment/ueditor/run', '编辑器附件', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('25', 'attachment', '1', 'attachment/attachments/showFileLis', '图片列表', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('26', 'attachment', '1', 'attachment/attachments/getUrlFile', '图片本地化', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('27', 'attachment', '1', 'attachment/attachments/select', '图片选择', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('28', 'addons', '1', 'addons/addons/index2', '插件扩展', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('29', 'addons', '1', 'addons/addons/index', '插件管理', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('30', 'addons', '1', 'addons/addons/addonadmin', '插件后台列表', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('31', 'admin', '1', 'admin/module/index2', '本地模块', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('32', 'admin', '1', 'admin/module/index', '模块后台列表', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('33', 'admin', '1', 'admin/authManager/editGroup', '编辑角色', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('34', 'admin', '1', 'admin/authManager/deleteGroup', '删除角色', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('35', 'admin', '1', 'admin/authManager/access', '访问授权', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('36', 'admin', '1', 'admin/authManager/writeGroup', '角色授权', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('37', 'admin', '1', 'admin/module/install', '模块安装', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('38', 'admin', '1', 'admin/module/uninstall', '模块卸载', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('39', 'admin', '1', 'admin/module/local', '本地安装', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('40', 'addons', '1', 'addons/addons/config', '插件设置', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('41', 'addons', '1', 'addons/addons/install', '插件安装', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('42', 'addons', '1', 'addons/addons/uninstall', '插件卸载', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('43', 'addons', '1', 'addons/addons/state', '插件状态', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('44', 'addons', '1', 'addons/addons/local', '本地安装', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('45', 'member', '1', 'member/member/index1', '会员管理', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('46', 'member', '1', 'member/setting/setting', '会员设置', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('47', 'member', '1', 'member/member/index', '会员管理', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('48', 'member', '1', 'member/member/userverify', '审核会员', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('49', 'member', '1', 'member/member/add', '会员添加', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('50', 'member', '1', 'member/member/edit', '会员编辑', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('51', 'member', '1', 'member/member/del', '会员删除', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('52', 'member', '1', 'member/member/pass', '会员审核', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('53', 'member', '1', 'member/group/index1', '会员组', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('54', 'member', '1', 'member/group/index', '会员组管理', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('55', 'member', '1', 'member/group/add', '会员组添加', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('56', 'member', '1', 'member/group/edit', '会员组编辑', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('57', 'member', '1', 'member/group/del', '会员组删除', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('58', 'links', '1', 'links/links/index', '友情链接', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('59', 'links', '1', 'links/links/add', '添加友情链接', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('60', 'links', '1', 'links/links/edit', '链接编辑', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('61', 'links', '1', 'links/links/del', '链接删除', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('62', 'links', '1', 'links/links/multi', '批量操作', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('63', 'links', '1', 'links/links/terms', '分类管理', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('64', 'links', '1', 'links/links/addTerms', '分类新增', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('65', 'links', '1', 'links/links/termsedit', '分类修改', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('66', 'links', '1', 'links/links/termsdelete', '分类删除', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('67', 'cms', '1', 'cms/cms/index2', '内容管理', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('68', 'cms', '1', 'cms/cms/index', '管理内容', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('69', 'cms', '1', 'cms/cms/panl', '面板', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('70', 'cms', '1', 'cms/cms/classlist', '信息列表', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('71', 'cms', '1', 'cms/cms/add', '添加', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('72', 'cms', '1', 'cms/cms/edit', '编辑', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('73', 'cms', '1', 'cms/cms/del', '删除', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('74', 'cms', '1', 'cms/cms/listorder', '排序', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('75', 'cms', '1', 'cms/cms/remove', '批量移动', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('76', 'cms', '1', 'cms/cms/setstate', '状态', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('77', 'cms', '1', 'cms/cms/check_title', '标题检查', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('78', 'cms', '1', 'cms/cms/recycle', '回收站', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('79', 'cms', '1', 'cms/cms/destroy', '清空回收站', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('80', 'cms', '1', 'cms/cms/restore', '还原回收站', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('81', 'cms', '1', 'cms/publish/index', '稿件管理', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('82', 'cms', '1', 'cms/publish/del', '删除', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('83', 'cms', '1', 'cms/publish/pass', '通过', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('84', 'cms', '1', 'cms/publish/reject', '退稿', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('85', 'cms', '1', 'cms/tags/index', '列表', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('86', 'cms', '1', 'cms/tags/add', '添加', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('87', 'cms', '1', 'cms/tags/edit', '编辑', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('88', 'cms', '1', 'cms/tags/del', '删除', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('89', 'cms', '1', 'cms/tags/create', '数据重建', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('90', 'cms', '1', 'cms/tags/multi', '批量更新', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('91', 'cms', '1', 'cms/category/index1', '相关设置', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('92', 'cms', '1', 'cms/setting/index', 'CMS配置', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('93', 'cms', '1', 'cms/category/index', '栏目列表', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('94', 'cms', '1', 'cms/category/add', '添加栏目', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('95', 'cms', '1', 'cms/category/singlepage', '添加单页', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('96', 'cms', '1', 'cms/category/cat_priv', '栏目授权', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('97', 'cms', '1', 'cms/category/edit', '编辑栏目', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('98', 'cms', '1', 'cms/category/del', '删除栏目', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('99', 'cms', '1', 'cms/category/multi', '批量更新', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('100', 'cms', '1', 'cms/category/public_tpl_file_list', '栏目模板', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('101', 'cms', '1', 'cms/models/index', '模型管理', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('102', 'cms', '1', 'cms/field/index', '字段管理', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('103', 'cms', '1', 'cms/field/add', '字段添加', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('104', 'cms', '1', 'cms/field/edit', '字段编辑', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('105', 'cms', '1', 'cms/field/del', '字段删除', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('106', 'cms', '1', 'cms/field/listorder', '字段排序', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('107', 'cms', '1', 'cms/field/setstate', '字段状态', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('108', 'cms', '1', 'cms/field/setsearch', '字段搜索', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('109', 'cms', '1', 'cms/field/setvisible', '字段隐藏', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('110', 'cms', '1', 'cms/field/setrequire', '字段必须', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('111', 'cms', '1', 'cms/models/add', '添加模型', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('112', 'cms', '1', 'cms/models/edit', '修改模型', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('113', 'cms', '1', 'cms/models/del', '删除模型', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('114', 'cms', '1', 'cms/models/multi', '批量更新', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('115', 'collection', '1', 'collection/node/index2', '采集管理', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('116', 'collection', '1', 'collection/node/index', '采集任务', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('117', 'formguide', '1', 'formguide/formguide/add', '添加表单', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('118', 'formguide', '1', 'formguide/formguide/edit', '编辑表单', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('119', 'formguide', '1', 'formguide/formguide/del', '删除表单', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('120', 'formguide', '1', 'formguide/field/index', '字段管理', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('121', 'formguide', '1', 'formguide/field/add', '添加字段', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('122', 'formguide', '1', 'formguide/field/edit', '编辑字段', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('123', 'formguide', '1', 'formguide/field/del', '删除字段', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('124', 'formguide', '1', 'formguide/info/index', '信息列表', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('125', 'formguide', '1', 'formguide/info/public_view', '信息查看', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('126', 'formguide', '1', 'formguide/info/del', '信息删除', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('127', 'message', '1', 'message/message/index', '短消息', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('128', 'message', '1', 'message/message/group', '群发消息列表', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('129', 'message', '1', 'message/message/message_send', '群发消息', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('130', 'message', '1', 'message/message/send_one', '发消息', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('131', 'message', '1', 'message/message/del', '删除短消息', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('132', 'message', '1', 'message/message/delete_group', '删除群发消息', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('133', 'pay', '1', 'pay/payment/pay_list', '支付模块', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('134', 'pay', '1', 'pay/payment/edit', '支付配置', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('135', 'attachment', '1', 'attachment/attachments/index', '附件管理', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('136', 'admin', '1', 'admin/config/add', '新增配置', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('137', 'admin', '1', 'admin/config/edit', '编辑配置', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('138', 'admin', '1', 'admin/config/del', '删除配置', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('139', 'cms', '2', 'cms/cms/index1', '内容', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('140', 'formguide', '1', 'formguide/formguide/index', '表单管理', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('141', 'pay', '1', 'pay/payment/index', '支付管理', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('142', 'member', '2', 'member/member/index2', '会员', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('143', 'collection', '2', 'collection/node/index1', '采集', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('144', 'admin', '2', 'admin/module/index1', '模块', '', '1');
INSERT INTO `mny_auth_rule` VALUES ('145', 'addons', '2', 'addons/addons/index1', '扩展', '', '1');

-- -----------------------------
-- Table structure for `mny_banner`
-- -----------------------------
DROP TABLE IF EXISTS `mny_banner`;
CREATE TABLE `mny_banner` (
  `id` int NOT NULL AUTO_INCREMENT,
  `type` tinyint(1) DEFAULT '0' COMMENT '1：文章类 2：商品类',
  `goods_id` int DEFAULT NULL COMMENT '商品id值',
  `thumb` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '轮播图地址',
  `url` varchar(90) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '图片链接',
  `region_id` int unsigned NOT NULL DEFAULT '0' COMMENT '区域id',
  `listorder` int DEFAULT '0' COMMENT '排序',
  `status` int DEFAULT '1' COMMENT '1:显示 0：影藏',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='会员Token表';

-- -----------------------------
-- Records of `mny_banner`
-- -----------------------------
INSERT INTO `mny_banner` VALUES ('3', '1', '0', '/uploads/images/20220920/c3575ec4b98df4181618d3e65eb5d13c.jpeg', '0', '1', '0', '1');
INSERT INTO `mny_banner` VALUES ('4', '1', '', '/uploads/images/20220920/c3575ec4b98df4181618d3e65eb5d13c.jpeg', '', '1', '', '1');

-- -----------------------------
-- Table structure for `mny_cache`
-- -----------------------------
DROP TABLE IF EXISTS `mny_cache`;
CREATE TABLE `mny_cache` (
  `id` int NOT NULL AUTO_INCREMENT,
  `key` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '缓存KEY值',
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '名称',
  `module` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '模块名称',
  `model` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '模型名称',
  `action` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '方法名',
  `system` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否系统',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `ckey` (`key`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='缓存列队表';

-- -----------------------------
-- Records of `mny_cache`
-- -----------------------------
INSERT INTO `mny_cache` VALUES ('1', 'Config', '网站配置', 'admin', 'Config', 'config_cache', '1');
INSERT INTO `mny_cache` VALUES ('2', 'Menu', '后台菜单', 'admin', 'Menu', 'menu_cache', '1');
INSERT INTO `mny_cache` VALUES ('3', 'Module', '可用模块列表', 'admin', 'Module', 'module_cache', '1');
INSERT INTO `mny_cache` VALUES ('4', 'Model', '模型列表', 'admin', 'Models', 'model_cache', '1');
INSERT INTO `mny_cache` VALUES ('5', 'ModelField', '模型字段', 'admin', 'ModelField', 'model_field_cache', '1');
INSERT INTO `mny_cache` VALUES ('6', 'Member_Config', '会员配置', 'member', 'Member', 'member_cache', '0');
INSERT INTO `mny_cache` VALUES ('7', 'Member_Group', '会员组', 'member', 'MemberGroup', 'membergroup_cache', '0');
INSERT INTO `mny_cache` VALUES ('8', 'Category', '栏目索引', 'cms', 'Category', 'category_cache', '0');
INSERT INTO `mny_cache` VALUES ('9', 'Shop_Config', '商城配置', 'shop', 'Cache', 'config_cache', '0');
INSERT INTO `mny_cache` VALUES ('10', 'Model_form', '自定义表单模型', 'formguide', 'Formguide', 'formguide_cache', '0');
INSERT INTO `mny_cache` VALUES ('11', 'Pay_Config', '支付配置', 'pay', 'Payment', 'pay_cache', '0');
INSERT INTO `mny_cache` VALUES ('12', 'Address', '全国地址', 'admin', 'Cache', 'address_cache', '0');

-- -----------------------------
-- Table structure for `mny_category`
-- -----------------------------
DROP TABLE IF EXISTS `mny_category`;
CREATE TABLE `mny_category` (
  `id` smallint unsigned NOT NULL AUTO_INCREMENT COMMENT '栏目ID',
  `catname` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '栏目名称',
  `catdir` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '唯一标识',
  `type` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '类别',
  `modelid` smallint unsigned NOT NULL DEFAULT '0' COMMENT '模型ID',
  `parentid` smallint unsigned NOT NULL DEFAULT '0' COMMENT '父ID',
  `arrparentid` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '所有父ID',
  `arrchildid` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '所有子栏目ID',
  `child` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '是否存在子栏目，1存在',
  `image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '栏目图片',
  `icon` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '栏目图标',
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '栏目描述',
  `url` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '链接地址',
  `items` mediumint unsigned NOT NULL DEFAULT '0' COMMENT '文档数量',
  `setting` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '相关配置信息',
  `listorder` smallint unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `status` tinyint NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `catdir` (`catdir`) USING BTREE,
  KEY `parentid` (`parentid`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='栏目表';

-- -----------------------------
-- Records of `mny_category`
-- -----------------------------
INSERT INTO `mny_category` VALUES ('2', '公司简介', 'Introduction', '1', '0', '1', '0,1', '2', '0', '', '', '', '', '0', 'a:4:{s:10:\"meta_title\";s:0:\"\";s:13:\"meta_keywords\";s:0:\"\";s:16:\"meta_description\";s:0:\"\";s:13:\"page_template\";s:9:\"page.html\";}', '1', '1');
INSERT INTO `mny_category` VALUES ('3', '企业文化', 'culture', '1', '0', '1', '0,1', '3', '0', '', '', '', '', '0', 'a:4:{s:10:\"meta_title\";s:0:\"\";s:13:\"meta_keywords\";s:0:\"\";s:16:\"meta_description\";s:0:\"\";s:13:\"page_template\";s:9:\"page.html\";}', '2', '1');
INSERT INTO `mny_category` VALUES ('4', '公司荣誉', 'honor', '2', '2', '1', '0,1', '4', '0', '', '', '', '', '5', 'a:7:{s:10:\"meta_title\";s:0:\"\";s:13:\"meta_keywords\";s:0:\"\";s:16:\"meta_description\";s:0:\"\";s:17:\"category_template\";s:21:\"category_picture.html\";s:13:\"list_template\";s:17:\"list_picture.html\";s:13:\"show_template\";s:17:\"show_picture.html\";s:13:\"page_template\";s:9:\"page.html\";}', '3', '1');
INSERT INTO `mny_category` VALUES ('5', '案例展示', 'case', '2', '3', '0', '0', '5', '0', '', '', '', '', '9', 'a:7:{s:10:\"meta_title\";s:0:\"\";s:13:\"meta_keywords\";s:0:\"\";s:16:\"meta_description\";s:0:\"\";s:17:\"category_template\";s:18:\"category_case.html\";s:13:\"list_template\";s:14:\"list_case.html\";s:13:\"show_template\";s:17:\"show_picture.html\";s:13:\"page_template\";s:9:\"page.html\";}', '2', '1');
INSERT INTO `mny_category` VALUES ('6', '新闻中心', 'news', '2', '1', '0', '0', '6,9,10,14', '1', '', '', '', '', '1', 'a:7:{s:10:\"meta_title\";s:0:\"\";s:13:\"meta_keywords\";s:0:\"\";s:16:\"meta_description\";s:0:\"\";s:17:\"category_template\";s:13:\"category.html\";s:13:\"list_template\";s:9:\"list.html\";s:13:\"show_template\";s:9:\"show.html\";s:13:\"page_template\";s:9:\"page.html\";}', '1', '1');
INSERT INTO `mny_category` VALUES ('8', '联系我们', 'contact', '1', '0', '0', '0', '8,18,19', '1', '', '', '', 'cms/index/lists?catid=18', '0', 'a:4:{s:10:\"meta_title\";s:0:\"\";s:13:\"meta_keywords\";s:0:\"\";s:16:\"meta_description\";s:0:\"\";s:13:\"page_template\";s:9:\"page.html\";}', '0', '1');
INSERT INTO `mny_category` VALUES ('9', '网络营销', 'marketing', '2', '1', '6', '0,6', '9', '0', '', '', '', '', '2', 'a:6:{s:10:\"meta_title\";s:0:\"\";s:13:\"meta_keywords\";s:0:\"\";s:16:\"meta_description\";s:0:\"\";s:17:\"category_template\";s:13:\"category.html\";s:13:\"list_template\";s:9:\"list.html\";s:13:\"show_template\";s:9:\"show.html\";}', '1', '1');
INSERT INTO `mny_category` VALUES ('10', '网站知识', 'knowledge', '2', '1', '6', '0,6', '10', '0', '', '', '', '', '2', 'a:7:{s:10:\"meta_title\";s:0:\"\";s:13:\"meta_keywords\";s:0:\"\";s:16:\"meta_description\";s:0:\"\";s:17:\"category_template\";s:13:\"category.html\";s:13:\"list_template\";s:9:\"list.html\";s:13:\"show_template\";s:9:\"show.html\";s:13:\"page_template\";s:9:\"page.html\";}', '2', '1');
INSERT INTO `mny_category` VALUES ('14', '备案知识', 'record', '2', '1', '6', '0,6', '14', '0', '', '', '', '', '2', 'a:7:{s:10:\"meta_title\";s:0:\"\";s:13:\"meta_keywords\";s:0:\"\";s:16:\"meta_description\";s:0:\"\";s:17:\"category_template\";s:13:\"category.html\";s:13:\"list_template\";s:9:\"list.html\";s:13:\"show_template\";s:9:\"show.html\";s:13:\"page_template\";s:9:\"page.html\";}', '3', '1');
INSERT INTO `mny_category` VALUES ('1', '关于我们', 'about', '1', '0', '0', '0', '1,2,3,4', '1', '', '', '', 'cms/index/lists?catid=2', '0', 'a:4:{s:10:\"meta_title\";s:0:\"\";s:13:\"meta_keywords\";s:0:\"\";s:16:\"meta_description\";s:0:\"\";s:13:\"page_template\";s:9:\"page.html\";}', '2', '1');
INSERT INTO `mny_category` VALUES ('18', '联系方式', 'fangshi', '1', '0', '8', '0,8', '18', '0', '', '', '', '', '0', 'a:4:{s:10:\"meta_title\";s:0:\"\";s:13:\"meta_keywords\";s:0:\"\";s:16:\"meta_description\";s:0:\"\";s:13:\"page_template\";s:9:\"page.html\";}', '0', '1');

-- -----------------------------
-- Table structure for `mny_category_priv`
-- -----------------------------
DROP TABLE IF EXISTS `mny_category_priv`;
CREATE TABLE `mny_category_priv` (
  `catid` smallint unsigned NOT NULL DEFAULT '0',
  `roleid` smallint unsigned NOT NULL DEFAULT '0' COMMENT '角色或者组ID',
  `is_admin` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '是否为管理员 1、管理员',
  `action` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '动作',
  KEY `catid` (`catid`,`roleid`,`is_admin`,`action`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='栏目权限表';


-- -----------------------------
-- Table structure for `mny_collection_content`
-- -----------------------------
DROP TABLE IF EXISTS `mny_collection_content`;
CREATE TABLE `mny_collection_content` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `nid` int unsigned NOT NULL DEFAULT '0',
  `status` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '0:未采集,1:已采集,2:已导入',
  `url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `title` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `data` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `nid` (`nid`) USING BTREE,
  KEY `status` (`status`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='采集内容表';


-- -----------------------------
-- Table structure for `mny_collection_node`
-- -----------------------------
DROP TABLE IF EXISTS `mny_collection_node`;
CREATE TABLE `mny_collection_node` (
  `id` smallint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '采集节点',
  `lastdate` int unsigned NOT NULL DEFAULT '0' COMMENT '最后采集时间',
  `sourcecharset` varchar(8) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '采集点字符集',
  `sourcetype` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '网址类型:1序列网址,2单页',
  `urlpage` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '采集地址',
  `url_contain` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '网址中必须包含',
  `url_except` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '网址中不能包含',
  `url_range` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '列表url切片选择器',
  `url_rule1` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '列表url选择器规则',
  `url_rule2` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '列表url属性规则',
  `url_rule3` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '列表url过滤器规则',
  `url_rule4` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '列表url选择器规则',
  `url_rule5` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '列表url属性规则',
  `url_rule6` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '列表url过滤器规则',
  `pagesize_start` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '页码开始',
  `pagesize_end` mediumint unsigned NOT NULL DEFAULT '0' COMMENT '页码结束',
  `par_num` tinyint unsigned NOT NULL DEFAULT '1' COMMENT '每次增加数',
  `down_attachment` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '是否下载图片',
  `watermark` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '图片加水印',
  `coll_order` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '导入顺序',
  `customize_config` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='采集任务表';


-- -----------------------------
-- Table structure for `mny_collection_program`
-- -----------------------------
DROP TABLE IF EXISTS `mny_collection_program`;
CREATE TABLE `mny_collection_program` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `nid` int unsigned NOT NULL DEFAULT '0',
  `modelid` mediumint unsigned NOT NULL DEFAULT '0',
  `catid` int unsigned NOT NULL DEFAULT '0',
  `config` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `nid` (`nid`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='采集方案表';


-- -----------------------------
-- Table structure for `mny_config`
-- -----------------------------
DROP TABLE IF EXISTS `mny_config`;
CREATE TABLE `mny_config` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '配置ID',
  `name` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '配置名称',
  `type` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '配置类型',
  `title` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '配置说明',
  `group` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '配置分组',
  `options` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '配置项',
  `remark` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '配置说明',
  `create_time` int unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint NOT NULL DEFAULT '0' COMMENT '状态',
  `value` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '配置值',
  `listorder` smallint unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `uk_name` (`name`) USING BTREE,
  KEY `type` (`type`) USING BTREE,
  KEY `group` (`group`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='网站配置';

-- -----------------------------
-- Records of `mny_config`
-- -----------------------------
INSERT INTO `mny_config` VALUES ('1', 'web_site_name', 'text', '网站名称', 'base', '', '', '1551244923', '1663492764', '1', '安购网络生鲜商城', '1');
INSERT INTO `mny_config` VALUES ('3', 'config_group', 'array', '配置分组', 'system', '', '', '1494408414', '1494408414', '1', '{\"base\":\"基础\",\"system\":\"系统\",\"upload\":\"上传\"}', '0');
INSERT INTO `mny_config` VALUES ('5', 'admin_forbid_ip', 'textarea', '后台禁止访问IP', 'system', '', '匹配IP段用\"*\"占位，如192.168.*.*，多个IP地址请用英文逗号\",\"分割', '1551244957', '1551244957', '1', '', '2');
INSERT INTO `mny_config` VALUES ('6', 'upload_image_size', 'text', '图片上传大小限制', 'upload', '', '0为不限制大小，单位：kb', '1540457656', '1552436075', '1', '0', '2');
INSERT INTO `mny_config` VALUES ('7', 'upload_image_ext', 'text', '允许上传图片后缀', 'upload', '', '多个后缀用逗号隔开，不填写则不限制类型', '1540457657', '1552436074', '1', 'gif,jpg,jpeg,bmp,png', '1');
INSERT INTO `mny_config` VALUES ('8', 'upload_file_size', 'text', '文件上传大小限制', 'upload', '', '0为不限制大小，单位：kb', '1540457658', '1663493222', '1', '0', '4');
INSERT INTO `mny_config` VALUES ('9', 'upload_file_ext', 'text', '允许上传文件后缀', 'upload', '', '多个后缀用逗号隔开，不填写则不限制类型', '1540457659', '1552436080', '1', 'doc,docx,xls,xlsx,ppt,pptx,pdf,wps,txt,rar,zip,gz,bz2,7z', '4');
INSERT INTO `mny_config` VALUES ('10', 'upload_driver', 'radio', '上传驱动', 'upload', 'local:本地\r\nqiniu:七牛云', '图片或文件上传驱动', '1541752781', '1663841393', '1', 'qiniu', '9');
INSERT INTO `mny_config` VALUES ('11', 'upload_thumb_water', 'switch', '添加水印', 'upload', '', '', '1552435063', '1552436080', '1', '0', '5');
INSERT INTO `mny_config` VALUES ('12', 'upload_thumb_water_pic', 'image', '水印图片', 'upload', '', '只有开启水印功能才生效', '1552435183', '1552436081', '1', 'http://cdn.angoukeji.com/images/20220924/184ac2e72d736ff295596f2284857762.jpg', '6');
INSERT INTO `mny_config` VALUES ('13', 'upload_thumb_water_position', 'radio', '水印位置', 'upload', '1:左上角\r\n2:上居中\r\n3:右上角\r\n4:左居中\r\n5:居中\r\n6:右居中\r\n7:左下角\r\n8:下居中\r\n9:右下角', '只有开启水印功能才生效', '1552435257', '1552436082', '1', '9', '7');
INSERT INTO `mny_config` VALUES ('14', 'upload_thumb_water_alpha', 'text', '水印透明度', 'upload', '', '请输入0~100之间的数字，数字越小，透明度越高', '1552435299', '1552436083', '1', '50', '8');

-- -----------------------------
-- Table structure for `mny_delivery`
-- -----------------------------
DROP TABLE IF EXISTS `mny_delivery`;
CREATE TABLE `mny_delivery` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `name` varchar(90) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '配送点名称',
  `region_id` int NOT NULL DEFAULT '0' COMMENT '区域id',
  `delivery_time` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '配送时间配置',
  `address` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '详细地址',
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `thumb` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city_id` int DEFAULT '0',
  `area_id` int DEFAULT '0',
  `area_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `province_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `province_id` int DEFAULT '0',
  `listorder` int DEFAULT '9' COMMENT '排序',
  `status` tinyint(1) DEFAULT '1' COMMENT '1:启用 0：禁用 2：暂停配送',
  `create_time` int unsigned DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='短信验证码表';

-- -----------------------------
-- Records of `mny_delivery`
-- -----------------------------
INSERT INTO `mny_delivery` VALUES ('2', '123213', '0', '', '', '', '', '0', '0', '中牟县', '郑州市', '河南省', '0', '0', '1', '0');
INSERT INTO `mny_delivery` VALUES ('3', '123123', '0', '[{\"hm\":\"00:00 - 00:00\"},{\"hm\":\"00:00 - 00:00\"}]', '', '', '', '0', '0', '中牟县', '郑州市', '河南省', '0', '0', '1', '0');
INSERT INTO `mny_delivery` VALUES ('4', '11', '0', '[{\"hm\":\"00:00 - 00:00\"},{\"hm\":\"00:00 - 00:00\"}]', '', '', '', '0', '0', '中牟县', '郑州市', '河南省', '0', '0', '1', '0');
INSERT INTO `mny_delivery` VALUES ('5', '我是配送点', '1', '[\"00:00 - 00:00\",\"00:00 - 00:00\"]', '', '我是描述', '', '189', '1891', '中牟县', '郑州市', '河南省', '16', '0', '1', '0');
INSERT INTO `mny_delivery` VALUES ('6', '我是配送点', '1', '[\"00:00 - 00:00\",\"00:00 - 00:00\"]', '', '我是描述', '', '189', '1891', '中牟县', '郑州市', '河南省', '16', '0', '1', '0');
INSERT INTO `mny_delivery` VALUES ('7', '我是配送点', '1', '[\"00:00 - 00:00\",\"00:00 - 00:00\"]', '', '我是描述', '', '189', '1891', '中牟县', '郑州市', '河南省', '16', '0', '1', '0');
INSERT INTO `mny_delivery` VALUES ('8', '我是配送点', '1', '[\"00:00 - 00:00\",\"00:00 - 00:00\"]', '', '我是描述', '', '189', '1891', '中牟县', '郑州市', '河南省', '16', '0', '1', '0');
INSERT INTO `mny_delivery` VALUES ('9', '我是配送点', '1', '[\"00:00 - 00:00\",\"00:00 - 00:00\"]', '', '我是描述', '', '189', '1891', '中牟县', '郑州市', '河南省', '16', '0', '1', '0');
INSERT INTO `mny_delivery` VALUES ('10', '我是配送点', '1', '[\"00:00 - 00:00\",\"00:00 - 00:00\"]', '', '我是描述', '', '189', '1891', '中牟县', '郑州市', '河南省', '16', '0', '1', '0');

-- -----------------------------
-- Table structure for `mny_download`
-- -----------------------------
DROP TABLE IF EXISTS `mny_download`;
CREATE TABLE `mny_download` (
  `id` mediumint unsigned NOT NULL AUTO_INCREMENT COMMENT '文档ID',
  `catid` smallint unsigned NOT NULL DEFAULT '0' COMMENT '栏目ID',
  `title` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT '标题',
  `thumb` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '缩略图',
  `flag` varchar(32) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT '属性',
  `keywords` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT 'SEO关键词',
  `description` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT 'SEO描述',
  `tags` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT 'Tags标签',
  `listorder` smallint unsigned NOT NULL DEFAULT '100' COMMENT '排序',
  `uid` mediumint unsigned NOT NULL DEFAULT '0' COMMENT '用户id',
  `username` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '用户名',
  `sysadd` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '是否后台添加',
  `hits` mediumint unsigned DEFAULT '0' COMMENT '点击量',
  `inputtime` int unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `updatetime` int unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `url` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '链接地址',
  `status` tinyint NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `status` (`catid`,`status`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='下载模型模型表';


-- -----------------------------
-- Table structure for `mny_download_data`
-- -----------------------------
DROP TABLE IF EXISTS `mny_download_data`;
CREATE TABLE `mny_download_data` (
  `did` mediumint unsigned NOT NULL DEFAULT '0',
  `content` mediumtext CHARACTER SET utf8 COLLATE utf8_unicode_ci COMMENT '内容',
  PRIMARY KEY (`did`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='下载模型模型表';


-- -----------------------------
-- Table structure for `mny_ems`
-- -----------------------------
DROP TABLE IF EXISTS `mny_ems`;
CREATE TABLE `mny_ems` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `event` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '事件',
  `email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '邮箱',
  `code` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '验证码',
  `times` int unsigned NOT NULL DEFAULT '0' COMMENT '验证次数',
  `ip` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '操作IP',
  `create_time` int unsigned DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='邮箱验证码表';


-- -----------------------------
-- Table structure for `mny_field_type`
-- -----------------------------
DROP TABLE IF EXISTS `mny_field_type`;
CREATE TABLE `mny_field_type` (
  `name` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '字段类型',
  `title` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '中文类型名',
  `listorder` int NOT NULL DEFAULT '0' COMMENT '排序',
  `default_define` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '默认定义',
  `ifoption` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '是否需要设置选项',
  `ifstring` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '是否自由字符',
  PRIMARY KEY (`name`) USING BTREE,
  UNIQUE KEY `name` (`name`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='字段类型表';

-- -----------------------------
-- Records of `mny_field_type`
-- -----------------------------
INSERT INTO `mny_field_type` VALUES ('text', '输入框', '1', 'varchar(255) NOT NULL', '0', '1');
INSERT INTO `mny_field_type` VALUES ('checkbox', '复选框', '2', 'varchar(32) NOT NULL', '1', '0');
INSERT INTO `mny_field_type` VALUES ('textarea', '多行文本', '3', 'varchar(255) NOT NULL', '0', '1');
INSERT INTO `mny_field_type` VALUES ('password', '密码', '4', 'varchar(255) NOT NULL', '0', '1');
INSERT INTO `mny_field_type` VALUES ('radio', '单选按钮', '5', 'char(10) NOT NULL', '1', '0');
INSERT INTO `mny_field_type` VALUES ('switch', '开关', '6', 'tinyint(2) UNSIGNED NOT NULL', '0', '0');
INSERT INTO `mny_field_type` VALUES ('array', '数组', '7', 'varchar(512) NOT NULL', '0', '0');
INSERT INTO `mny_field_type` VALUES ('select', '下拉框', '8', 'char(10) NOT NULL', '1', '0');
INSERT INTO `mny_field_type` VALUES ('selects', '下拉框(多选)', '9', 'varchar(32) NOT NULL', '1', '0');
INSERT INTO `mny_field_type` VALUES ('selectpage', '高级下拉框', '10', 'varchar(32) NOT NULL', '1', '0');
INSERT INTO `mny_field_type` VALUES ('image', '单张图', '11', 'varchar(255) NOT NULL', '0', '0');
INSERT INTO `mny_field_type` VALUES ('images', '多张图', '12', 'text NOT NULL', '0', '0');
INSERT INTO `mny_field_type` VALUES ('tags', '标签', '13', 'varchar(255) NOT NULL', '0', '1');
INSERT INTO `mny_field_type` VALUES ('number', '数字', '14', 'int(10) UNSIGNED NOT NULL', '0', '0');
INSERT INTO `mny_field_type` VALUES ('datetime', '日期和时间', '15', 'int(10) UNSIGNED NOT NULL', '0', '0');
INSERT INTO `mny_field_type` VALUES ('Ueditor', '百度编辑器', '16', 'mediumtext NOT NULL', '0', '1');
INSERT INTO `mny_field_type` VALUES ('markdown', 'markdown编辑器', '17', 'mediumtext NOT NULL', '0', '1');
INSERT INTO `mny_field_type` VALUES ('files', '多文件', '18', 'text NOT NULL', '0', '0');
INSERT INTO `mny_field_type` VALUES ('file', '单文件', '19', 'varchar(255) NOT NULL', '0', '0');
INSERT INTO `mny_field_type` VALUES ('color', '颜色值', '20', 'varchar(7) NOT NULL', '0', '0');
INSERT INTO `mny_field_type` VALUES ('city', '城市地区', '21', 'varchar(255) NOT NULL', '0', '0');
INSERT INTO `mny_field_type` VALUES ('custom', '自定义', '22', 'text NOT NULL', '1', '0');

-- -----------------------------
-- Table structure for `mny_goods`
-- -----------------------------
DROP TABLE IF EXISTS `mny_goods`;
CREATE TABLE `mny_goods` (
  `id` mediumint unsigned NOT NULL AUTO_INCREMENT COMMENT '文档ID',
  `region_id` int DEFAULT '0' COMMENT '区域id值',
  `catid` smallint unsigned NOT NULL DEFAULT '0' COMMENT '分类id值',
  `is_select` tinyint DEFAULT '0' COMMENT '0：普通 1：质选+特卖',
  `goods_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT '商品名称',
  `ad_thumb` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '广告图',
  `banner` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '详情轮播图',
  `is_new` int DEFAULT '1' COMMENT '1：新品 0：不是新品',
  `feature` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '商品特点',
  `sale_num` int DEFAULT '0' COMMENT '销量',
  `is_specs` tinyint(1) DEFAULT '0' COMMENT '1：有规格 0：无规格',
  `tag` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '商品标签',
  `listorder` smallint unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `hits` mediumint unsigned DEFAULT '0' COMMENT '点击量',
  `inputtime` int unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `updatetime` int unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `content` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '商品详情',
  `status` tinyint NOT NULL DEFAULT '0' COMMENT '状态 0：下架 1：上架',
  `thumb` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '缩略图',
  `limit_buy_num` int DEFAULT '0' COMMENT '单人限制购买数量，无规格，有规格，质选限购',
  `price` decimal(10,2) DEFAULT '0.00' COMMENT '默认显示价格，无规格，有规格取默认最低价，质选最低价',
  `weight` double DEFAULT '0' COMMENT '重量，无规格，有规格默认最低价的重量，质选最低价重量',
  `stock` int DEFAULT '0' COMMENT '库存，所有的规格总和，无规格，质选和特卖单独库存',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `status` (`catid`,`status`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='文章模型模型表';

-- -----------------------------
-- Records of `mny_goods`
-- -----------------------------
INSERT INTO `mny_goods` VALUES ('8', '1', '8', '1', '测试', '', '', '0', '颗粒,大小', '0', '1', '', '100', '0', '0', '0', '', '1', 'https://img1.baidu.com/it/u=1655164402,138037022&fm=253&fmt=auto&app=138&f=JPEG?w=500&h=707', '0', '30.00', '23', '55');
INSERT INTO `mny_goods` VALUES ('1', '1', '8', '0', '测试333', '', '', '0', '颗粒', '0', '0', '', '100', '0', '0', '0', '', '1', 'https://img1.baidu.com/it/u=1655164402,138037022&fm=253&fmt=auto&app=138&f=JPEG?w=500&h=707', '0', '40.00', '5', '66');
INSERT INTO `mny_goods` VALUES ('10', '1', '8', '0', '测试', '', '', '0', '颗粒,大小', '0', '0', '', '100', '0', '0', '0', '', '1', 'https://img1.baidu.com/it/u=1655164402,138037022&fm=253&fmt=auto&app=138&f=JPEG?w=500&h=707', '0', '30.00', '23', '55');
INSERT INTO `mny_goods` VALUES ('11', '1', '8', '0', '测试', '', '', '0', '颗粒,大小', '0', '0', '', '100', '0', '0', '0', '', '1', 'https://img1.baidu.com/it/u=958309874,2965705453&fm=253&fmt=auto&app=138&f=JPEG?w=800&h=500', '0', '30.00', '23', '55');
INSERT INTO `mny_goods` VALUES ('12', '1', '8', '0', '测试', '', '', '0', '颗粒,大小', '0', '0', '', '100', '0', '0', '0', '', '1', 'https://img1.baidu.com/it/u=958309874,2965705453&fm=253&fmt=auto&app=138&f=JPEG?w=800&h=500', '0', '30.00', '23', '55');
INSERT INTO `mny_goods` VALUES ('13', '1', '8', '0', '测试', '', '', '0', '颗粒,大小', '0', '0', '', '100', '0', '0', '0', '', '1', 'https://img2.baidu.com/it/u=1902601184,2307116445&fm=253&fmt=auto&app=138&f=PNG?w=600&h=388\'', '0', '30.00', '23', '55');
INSERT INTO `mny_goods` VALUES ('14', '1', '8', '0', '测试', '', '', '0', '颗粒,大小', '0', '0', '', '100', '0', '0', '0', '', '1', 'https://img1.baidu.com/it/u=2337137358,1300002153&fm=253&fmt=auto&app=138&f=JPEG?w=729&h=500\'', '0', '30.00', '23', '55');
INSERT INTO `mny_goods` VALUES ('15', '1', '8', '0', '测试', '', '', '0', '颗粒,大小', '0', '0', '', '100', '0', '0', '0', '', '1', 'https://img1.baidu.com/it/u=2337137358,1300002153&fm=253&fmt=auto&app=138&f=JPEG?w=729&h=500\'', '0', '30.00', '23', '55');
INSERT INTO `mny_goods` VALUES ('16', '1', '8', '0', '测试', '', '', '0', '颗粒,大小', '0', '0', '', '100', '0', '0', '0', '', '1', 'https://img1.baidu.com/it/u=2337137358,1300002153&fm=253&fmt=auto&app=138&f=JPEG?w=729&h=500\'', '0', '30.00', '23', '55');
INSERT INTO `mny_goods` VALUES ('17', '1', '8', '0', '测试', '', '', '0', '颗粒,大小', '0', '0', '', '100', '0', '0', '0', '', '1', 'https://img1.baidu.com/it/u=2337137358,1300002153&fm=253&fmt=auto&app=138&f=JPEG?w=729&h=500\'', '0', '30.00', '23', '55');
INSERT INTO `mny_goods` VALUES ('18', '1', '8', '0', '测试', '', '', '0', '颗粒,大小', '0', '0', '', '100', '0', '0', '0', '', '1', 'https://img1.baidu.com/it/u=2337137358,1300002153&fm=253&fmt=auto&app=138&f=JPEG?w=729&h=500\'', '0', '30.00', '23', '55');
INSERT INTO `mny_goods` VALUES ('19', '1', '8', '0', '测试', '', '', '0', '颗粒,大小', '0', '0', '', '100', '0', '0', '0', '', '1', 'https://img1.baidu.com/it/u=2337137358,1300002153&fm=253&fmt=auto&app=138&f=JPEG?w=729&h=500\'', '0', '30.00', '23', '55');
INSERT INTO `mny_goods` VALUES ('20', '1', '8', '0', '测试', '', '', '0', '颗粒,大小', '0', '0', '', '100', '0', '0', '0', '', '1', 'https://img1.baidu.com/it/u=2337137358,1300002153&fm=253&fmt=auto&app=138&f=JPEG?w=729&h=500\'', '0', '30.00', '23', '55');
INSERT INTO `mny_goods` VALUES ('21', '1', '8', '0', '测试', '', '', '0', '颗粒,大小', '0', '0', '', '100', '0', '0', '0', '', '1', 'https://img1.baidu.com/it/u=958309874,2965705453&fm=253&fmt=auto&app=138&f=JPEG?w=800&h=500', '0', '30.00', '23', '55');
INSERT INTO `mny_goods` VALUES ('22', '1', '8', '0', '测试', '', '', '0', '颗粒,大小', '0', '0', '', '100', '0', '0', '0', '', '1', 'https://img1.baidu.com/it/u=1655164402,138037022&fm=253&fmt=auto&app=138&f=JPEG?w=500&h=707', '0', '30.00', '23', '55');
INSERT INTO `mny_goods` VALUES ('23', '1', '8', '0', '测试', '', '', '0', '颗粒,大小', '0', '0', '', '100', '0', '0', '0', '', '1', 'https://img1.baidu.com/it/u=958309874,2965705453&fm=253&fmt=auto&app=138&f=JPEG?w=800&h=500', '0', '30.00', '23', '55');
INSERT INTO `mny_goods` VALUES ('24', '1', '8', '0', '测试', '', '', '0', '颗粒,大小', '0', '0', '', '100', '0', '0', '0', '', '1', 'https://img1.baidu.com/it/u=958309874,2965705453&fm=253&fmt=auto&app=138&f=JPEG?w=800&h=500', '0', '30.00', '23', '55');
INSERT INTO `mny_goods` VALUES ('25', '1', '8', '0', '测试', 'https://img1.baidu.com/it/u=1655164402,138037022&fm=253&fmt=auto&app=138&f=JPEG?w=500&h=707', '', '0', '颗粒,大小', '0', '1', '', '100', '0', '0', '0', '<p>123123123123</p>234234234234<b>jininni</b>', '1', 'https://img1.baidu.com/it/u=1655164402,138037022&fm=253&fmt=auto&app=138&f=JPEG?w=500&h=707', '0', '30.00', '23', '55');
INSERT INTO `mny_goods` VALUES ('26', '1', '8', '0', '测试', '', '', '0', '颗粒,大小', '0', '0', '', '100', '0', '0', '0', '', '1', 'https://img1.baidu.com/it/u=958309874,2965705453&fm=253&fmt=auto&app=138&f=JPEG?w=800&h=500', '0', '30.00', '23', '55');
INSERT INTO `mny_goods` VALUES ('27', '1', '8', '0', '测试', '', '', '0', '颗粒,大小', '0', '0', '', '100', '0', '0', '0', '', '1', 'https://img1.baidu.com/it/u=958309874,2965705453&fm=253&fmt=auto&app=138&f=JPEG?w=800&h=500', '0', '30.00', '23', '55');
INSERT INTO `mny_goods` VALUES ('28', '1', '8', '0', '测试', '', '', '0', '颗粒,大小', '0', '0', '', '100', '0', '0', '0', '', '1', 'https://img1.baidu.com/it/u=958309874,2965705453&fm=253&fmt=auto&app=138&f=JPEG?w=800&h=500', '0', '30.00', '23', '55');
INSERT INTO `mny_goods` VALUES ('29', '1', '8', '0', '测试', '', '', '0', '颗粒,大小', '0', '0', '', '100', '0', '0', '0', '', '1', 'https://img1.baidu.com/it/u=958309874,2965705453&fm=253&fmt=auto&app=138&f=JPEG?w=800&h=500', '0', '30.00', '23', '55');
INSERT INTO `mny_goods` VALUES ('30', '1', '8', '0', '测试', '', '', '0', '颗粒,大小', '0', '0', '', '100', '0', '0', '0', '', '1', 'https://img1.baidu.com/it/u=958309874,2965705453&fm=253&fmt=auto&app=138&f=JPEG?w=800&h=500', '0', '30.00', '23', '55');
INSERT INTO `mny_goods` VALUES ('31', '1', '8', '0', '测试', '', '', '0', '颗粒,大小', '0', '0', '', '100', '0', '0', '0', '', '1', 'https://img1.baidu.com/it/u=958309874,2965705453&fm=253&fmt=auto&app=138&f=JPEG?w=800&h=500', '0', '30.00', '23', '55');
INSERT INTO `mny_goods` VALUES ('32', '1', '8', '0', '测试', '', '', '0', '颗粒,大小', '0', '0', '', '100', '0', '0', '0', '', '1', 'https://img1.baidu.com/it/u=958309874,2965705453&fm=253&fmt=auto&app=138&f=JPEG?w=800&h=500', '0', '30.00', '23', '55');
INSERT INTO `mny_goods` VALUES ('33', '1', '8', '0', '测试', '', '', '0', '颗粒,大小', '0', '0', '', '100', '0', '0', '0', '', '1', 'https://img1.baidu.com/it/u=958309874,2965705453&fm=253&fmt=auto&app=138&f=JPEG?w=800&h=500', '0', '30.00', '23', '55');
INSERT INTO `mny_goods` VALUES ('34', '1', '8', '0', '测试', '', '', '0', '颗粒,大小', '0', '0', '', '100', '0', '0', '0', '', '1', 'https://img1.baidu.com/it/u=958309874,2965705453&fm=253&fmt=auto&app=138&f=JPEG?w=800&h=500', '0', '30.00', '23', '55');
INSERT INTO `mny_goods` VALUES ('35', '1', '8', '0', '测试', '', '', '0', '颗粒,大小', '0', '0', '', '100', '0', '0', '0', '', '1', 'https://img1.baidu.com/it/u=958309874,2965705453&fm=253&fmt=auto&app=138&f=JPEG?w=800&h=500', '0', '30.00', '23', '55');
INSERT INTO `mny_goods` VALUES ('36', '1', '8', '1', '测试', '', '', '0', '颗粒,大小', '0', '1', '', '100', '0', '0', '0', '', '1', 'https://img1.baidu.com/it/u=958309874,2965705453&fm=253&fmt=auto&app=138&f=JPEG?w=800&h=500', '0', '30.00', '23', '55');
INSERT INTO `mny_goods` VALUES ('37', '1', '13', '0', '测试', '', '', '0', '颗粒,大小', '0', '0', '', '100', '0', '0', '0', '', '1', 'https://img1.baidu.com/it/u=958309874,2965705453&fm=253&fmt=auto&app=138&f=JPEG?w=800&h=500', '0', '30.00', '23', '55');
INSERT INTO `mny_goods` VALUES ('38', '1', '14', '0', '测试', '', '', '0', '颗粒,大小', '0', '0', '', '100', '0', '0', '0', '', '1', 'https://img1.baidu.com/it/u=958309874,2965705453&fm=253&fmt=auto&app=138&f=JPEG?w=800&h=500', '0', '30.00', '23', '55');
INSERT INTO `mny_goods` VALUES ('39', '1', '15', '0', '测试', '', '', '0', '颗粒,大小', '0', '0', '', '100', '0', '0', '0', '', '1', 'https://img1.baidu.com/it/u=958309874,2965705453&fm=253&fmt=auto&app=138&f=JPEG?w=800&h=500', '0', '30.00', '23', '55');

-- -----------------------------
-- Table structure for `mny_goods_category`
-- -----------------------------
DROP TABLE IF EXISTS `mny_goods_category`;
CREATE TABLE `mny_goods_category` (
  `id` mediumint unsigned NOT NULL AUTO_INCREMENT COMMENT '文档ID',
  `parentid` smallint unsigned NOT NULL DEFAULT '0' COMMENT '父id',
  `level` int DEFAULT '0' COMMENT '1:一级分类 2：二级分类',
  `catname` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT '分类名',
  `thumb` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '缩略图',
  `listorder` smallint unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `status` tinyint NOT NULL DEFAULT '0' COMMENT '状态',
  `is_lock` tinyint DEFAULT '0' COMMENT '1：不可操作',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `status` (`parentid`,`status`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='文章模型模型表';

-- -----------------------------
-- Records of `mny_goods_category`
-- -----------------------------
INSERT INTO `mny_goods_category` VALUES ('8', '10', '1', '蔬菜', '', '100', '1', '0');
INSERT INTO `mny_goods_category` VALUES ('9', '10', '1', '水果', '', '100', '1', '0');
INSERT INTO `mny_goods_category` VALUES ('10', '0', '0', '首页商品', '', '100', '1', '1');
INSERT INTO `mny_goods_category` VALUES ('11', '0', '0', '质品', '', '0', '1', '1');
INSERT INTO `mny_goods_category` VALUES ('12', '0', '0', '拼', '', '0', '1', '1');
INSERT INTO `mny_goods_category` VALUES ('13', '11', '1', '质品一级分类', '', '0', '1', '0');
INSERT INTO `mny_goods_category` VALUES ('14', '13', '2', '质品二级分类', '', '0', '1', '0');
INSERT INTO `mny_goods_category` VALUES ('15', '13', '2', '质品二级分类', '', '0', '1', '0');
INSERT INTO `mny_goods_category` VALUES ('16', '12', '1', '拼的一级分类', '', '0', '1', '0');
INSERT INTO `mny_goods_category` VALUES ('17', '16', '2', '拼的二级分类', '', '0', '1', '0');

-- -----------------------------
-- Table structure for `mny_goods_item`
-- -----------------------------
DROP TABLE IF EXISTS `mny_goods_item`;
CREATE TABLE `mny_goods_item` (
  `id` mediumint unsigned NOT NULL AUTO_INCREMENT COMMENT '文档ID',
  `goods_id` int DEFAULT NULL COMMENT '商品id值',
  `type` tinyint(1) DEFAULT '1' COMMENT '1：质选 2：特卖',
  `thumb` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '商品图',
  `weight` double DEFAULT NULL COMMENT '重量',
  `price` decimal(10,2) DEFAULT NULL COMMENT '价格',
  `limit_buy_num` int DEFAULT NULL COMMENT '限制数量',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='文章模型模型表';

-- -----------------------------
-- Records of `mny_goods_item`
-- -----------------------------
INSERT INTO `mny_goods_item` VALUES ('10', '8', '1', 'https://img1.baidu.com/it/u=958309874,2965705453&fm=253&fmt=auto&app=138&f=JPEG?w=800&h=500', '', '', '20');
INSERT INTO `mny_goods_item` VALUES ('11', '8', '2', 'https://img1.baidu.com/it/u=958309874,2965705453&fm=253&fmt=auto&app=138&f=JPEG?w=800&h=500', '', '', '60');
INSERT INTO `mny_goods_item` VALUES ('12', '36', '1', 'https://img1.baidu.com/it/u=958309874,2965705453&fm=253&fmt=auto&app=138&f=JPEG?w=800&h=500', '30', '10.00', '10');
INSERT INTO `mny_goods_item` VALUES ('13', '36', '2', 'https://img1.baidu.com/it/u=958309874,2965705453&fm=253&fmt=auto&app=138&f=JPEG?w=800&h=500', '20', '34.00', '24');

-- -----------------------------
-- Table structure for `mny_goods_price`
-- -----------------------------
DROP TABLE IF EXISTS `mny_goods_price`;
CREATE TABLE `mny_goods_price` (
  `id` mediumint unsigned NOT NULL AUTO_INCREMENT COMMENT '文档ID',
  `goods_id` smallint unsigned NOT NULL DEFAULT '0' COMMENT '商品id',
  `item_id_group` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '规格组合',
  `weight` double DEFAULT '0' COMMENT '重量',
  `type` tinyint NOT NULL DEFAULT '0' COMMENT '0：不分特卖、质选 1：质选 2：特卖',
  `stock` int DEFAULT '0' COMMENT '库存',
  `price` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '价格',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `status` (`goods_id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='文章模型模型表';

-- -----------------------------
-- Records of `mny_goods_price`
-- -----------------------------
INSERT INTO `mny_goods_price` VALUES ('9', '8', '9,11', '8', '1', '10', '30.00');
INSERT INTO `mny_goods_price` VALUES ('10', '8', '9,12', '3.4', '2', '20', '50.00');
INSERT INTO `mny_goods_price` VALUES ('11', '36', '15', '34', '1', '10', '40.00');
INSERT INTO `mny_goods_price` VALUES ('12', '36', '17,20', '20', '2', '3', '80.00');
INSERT INTO `mny_goods_price` VALUES ('13', '25', '19', '23', '0', '12', '7.00');

-- -----------------------------
-- Table structure for `mny_goods_specs`
-- -----------------------------
DROP TABLE IF EXISTS `mny_goods_specs`;
CREATE TABLE `mny_goods_specs` (
  `id` mediumint unsigned NOT NULL AUTO_INCREMENT COMMENT '文档ID',
  `goods_id` smallint unsigned NOT NULL DEFAULT '0' COMMENT '商品id',
  `type` tinyint NOT NULL DEFAULT '0' COMMENT '0：不分特卖、质选 1：质选 2：特卖',
  `specs_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '规格名称',
  `listorder` smallint unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `status` (`goods_id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='文章模型模型表';

-- -----------------------------
-- Records of `mny_goods_specs`
-- -----------------------------
INSERT INTO `mny_goods_specs` VALUES ('8', '8', '1', '果肉', '0');
INSERT INTO `mny_goods_specs` VALUES ('9', '8', '2', '颜色', '0');
INSERT INTO `mny_goods_specs` VALUES ('10', '36', '1', '果肉', '0');
INSERT INTO `mny_goods_specs` VALUES ('11', '36', '2', '颜色', '0');
INSERT INTO `mny_goods_specs` VALUES ('12', '25', '0', '果肉', '0');
INSERT INTO `mny_goods_specs` VALUES ('13', '36', '2', '果肉', '0');

-- -----------------------------
-- Table structure for `mny_goods_specs_item`
-- -----------------------------
DROP TABLE IF EXISTS `mny_goods_specs_item`;
CREATE TABLE `mny_goods_specs_item` (
  `id` mediumint unsigned NOT NULL AUTO_INCREMENT COMMENT '文档ID',
  `specs_id` smallint unsigned NOT NULL DEFAULT '0' COMMENT '商品id',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '名称',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `status` (`specs_id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='文章模型模型表';

-- -----------------------------
-- Records of `mny_goods_specs_item`
-- -----------------------------
INSERT INTO `mny_goods_specs_item` VALUES ('10', '8', '饱满');
INSERT INTO `mny_goods_specs_item` VALUES ('11', '8', '满满');
INSERT INTO `mny_goods_specs_item` VALUES ('12', '9', '微甜');
INSERT INTO `mny_goods_specs_item` VALUES ('13', '9', '不甜');
INSERT INTO `mny_goods_specs_item` VALUES ('14', '10', '饱满');
INSERT INTO `mny_goods_specs_item` VALUES ('15', '10', '满满');
INSERT INTO `mny_goods_specs_item` VALUES ('16', '11', '黄色');
INSERT INTO `mny_goods_specs_item` VALUES ('17', '11', '绿色');
INSERT INTO `mny_goods_specs_item` VALUES ('18', '12', '满满');
INSERT INTO `mny_goods_specs_item` VALUES ('19', '12', '饱满');
INSERT INTO `mny_goods_specs_item` VALUES ('20', '13', '满满');
INSERT INTO `mny_goods_specs_item` VALUES ('21', '13', '不瞒你说');

-- -----------------------------
-- Table structure for `mny_links`
-- -----------------------------
DROP TABLE IF EXISTS `mny_links`;
CREATE TABLE `mny_links` (
  `id` smallint unsigned NOT NULL AUTO_INCREMENT COMMENT '链接id',
  `linktype` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '0:文字链接,1:logo链接',
  `url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '链接地址',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '链接名称',
  `image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '链接图片',
  `target` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '链接打开方式',
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '链接描述',
  `inputtime` int NOT NULL COMMENT '添加时间',
  `listorder` smallint unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `termsid` smallint NOT NULL COMMENT '分类id',
  `status` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '0未通过,1正常,2未审核',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='友情链接';


-- -----------------------------
-- Table structure for `mny_luck_draw`
-- -----------------------------
DROP TABLE IF EXISTS `mny_luck_draw`;
CREATE TABLE `mny_luck_draw` (
  `id` int NOT NULL AUTO_INCREMENT,
  `key` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '缓存KEY值',
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '名称',
  `module` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '模块名称',
  `model` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '模型名称',
  `action` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '方法名',
  `system` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否系统',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `ckey` (`key`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='缓存列队表';


-- -----------------------------
-- Table structure for `mny_member`
-- -----------------------------
DROP TABLE IF EXISTS `mny_member`;
CREATE TABLE `mny_member` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `username` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '用户名',
  `nickname` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '昵称',
  `password` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '密码',
  `encrypt` varchar(6) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '加密因子',
  `point` mediumint NOT NULL DEFAULT '0' COMMENT '用户积分',
  `amount` decimal(8,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '钱金总额',
  `login` int unsigned NOT NULL DEFAULT '0' COMMENT '登录次数',
  `email` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '电子邮箱',
  `mobile` varchar(11) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '手机号',
  `avatar` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '头像',
  `groupid` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '用户组ID',
  `modelid` smallint unsigned NOT NULL DEFAULT '0' COMMENT '用户模型ID',
  `vip` tinyint unsigned NOT NULL DEFAULT '0' COMMENT 'VIP会员',
  `overduedate` int unsigned NOT NULL DEFAULT '0' COMMENT '过期时间',
  `reg_ip` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '注册IP',
  `reg_time` int unsigned NOT NULL DEFAULT '0' COMMENT '注册时间',
  `last_login_ip` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '最后登录IP',
  `last_login_time` int unsigned NOT NULL DEFAULT '0' COMMENT '最后登录时间',
  `ischeck_email` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否验证过邮箱',
  `ischeck_mobile` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否验证过手机',
  `token` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT 'Token',
  `status` tinyint NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `username` (`username`) USING BTREE,
  KEY `email` (`email`) USING BTREE,
  KEY `mobile` (`mobile`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='会员表';

-- -----------------------------
-- Records of `mny_member`
-- -----------------------------
INSERT INTO `mny_member` VALUES ('1', 'jinsong', 'jinsong', '48b356adabac939b0ba6f8cac5c65a4c', '0fElIe', '0', '2.00', '6', '211983652@qq.com', '19523693971', '/uploads/images/20220827/cf4c92132c36245a8555a5e1f3b82a7b.jpg', '2', '0', '0', '0', '127.0.0.1', '1660376551', '192.168.103.12', '1663555588', '0', '0', '', '1');

-- -----------------------------
-- Table structure for `mny_member_content`
-- -----------------------------
DROP TABLE IF EXISTS `mny_member_content`;
CREATE TABLE `mny_member_content` (
  `id` int NOT NULL AUTO_INCREMENT,
  `catid` smallint NOT NULL COMMENT '栏目ID',
  `content_id` int NOT NULL COMMENT '信息ID',
  `uid` mediumint NOT NULL COMMENT '会员ID',
  `username` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '用户名',
  `create_time` int NOT NULL COMMENT '添加时间',
  `status` tinyint NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `uid` (`catid`,`content_id`,`status`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='会员投稿信息记录表';


-- -----------------------------
-- Table structure for `mny_member_group`
-- -----------------------------
DROP TABLE IF EXISTS `mny_member_group`;
CREATE TABLE `mny_member_group` (
  `id` tinyint unsigned NOT NULL AUTO_INCREMENT COMMENT '会员组id',
  `name` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '用户组名称',
  `issystem` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '是否是系统组',
  `starnum` tinyint unsigned NOT NULL COMMENT '会员组星星数',
  `point` smallint unsigned NOT NULL COMMENT '积分范围',
  `allowmessage` smallint unsigned NOT NULL DEFAULT '0' COMMENT '许允发短消息数量',
  `allowvisit` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '是否允许访问',
  `allowpost` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '是否允许发稿',
  `allowpostverify` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '是否投稿不需审核',
  `allowsearch` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '是否允许搜索',
  `allowupgrade` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '是否允许自主升级',
  `allowsendmessage` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '允许发送短消息',
  `allowpostnum` smallint unsigned NOT NULL DEFAULT '0' COMMENT '每天允许发文章数',
  `allowattachment` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '是否允许上传附件',
  `price_y` decimal(8,2) unsigned NOT NULL DEFAULT '0.00',
  `price_m` decimal(8,2) unsigned NOT NULL DEFAULT '0.00',
  `price_d` decimal(8,2) unsigned NOT NULL DEFAULT '0.00',
  `icon` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '用户组图标',
  `usernamecolor` varchar(7) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '用户名颜色',
  `description` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '描述',
  `listorder` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `status` tinyint NOT NULL DEFAULT '0' COMMENT '状态',
  `expand` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '拓展',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='会员组';

-- -----------------------------
-- Records of `mny_member_group`
-- -----------------------------
INSERT INTO `mny_member_group` VALUES ('1', '禁止访问', '1', '0', '0', '0', '1', '1', '0', '1', '0', '0', '0', '0', '0.00', '0.00', '0.00', '', '', '0', '0', '1', '');
INSERT INTO `mny_member_group` VALUES ('2', '新手上路', '1', '1', '50', '100', '1', '1', '0', '0', '0', '1', '0', '0', '50.00', '10.00', '1.00', '', '', '', '2', '1', '');
INSERT INTO `mny_member_group` VALUES ('6', '注册会员', '1', '2', '100', '150', '0', '1', '0', '0', '1', '1', '0', '0', '300.00', '30.00', '1.00', '', '', '', '6', '1', '');
INSERT INTO `mny_member_group` VALUES ('4', '中级会员', '1', '3', '150', '500', '1', '1', '0', '1', '1', '1', '0', '0', '360.00', '60.00', '1.00', '', '', '', '4', '1', '');
INSERT INTO `mny_member_group` VALUES ('5', '高级会员', '1', '5', '300', '999', '1', '1', '0', '1', '1', '1', '0', '0', '500.00', '90.00', '1.00', '', '', '', '5', '1', '');
INSERT INTO `mny_member_group` VALUES ('7', '邮件认证', '1', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0.00', '0.00', '0.00', '', '#000000', '', '7', '1', '');
INSERT INTO `mny_member_group` VALUES ('8', '游客', '1', '0', '0', '0', '0', '0', '0', '1', '0', '0', '0', '0', '0.00', '0.00', '0.00', '', '', '', '0', '1', '');

-- -----------------------------
-- Table structure for `mny_member_token`
-- -----------------------------
DROP TABLE IF EXISTS `mny_member_token`;
CREATE TABLE `mny_member_token` (
  `token` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Token',
  `user_id` int unsigned NOT NULL DEFAULT '0' COMMENT '会员ID',
  `create_time` int DEFAULT NULL COMMENT '创建时间',
  `expire_time` int DEFAULT NULL COMMENT '过期时间',
  PRIMARY KEY (`token`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='会员Token表';

-- -----------------------------
-- Records of `mny_member_token`
-- -----------------------------
INSERT INTO `mny_member_token` VALUES ('e1671f181b5e08382600dace780fde833b24c289', '1', '1663555588', '1666147588');

-- -----------------------------
-- Table structure for `mny_menu`
-- -----------------------------
DROP TABLE IF EXISTS `mny_menu`;
CREATE TABLE `mny_menu` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '菜单ID',
  `title` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '标题',
  `icon` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '图标',
  `parentid` int unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `app` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '应用标识',
  `controller` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '控制器标识',
  `action` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '方法标识',
  `parameter` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '附加参数',
  `status` tinyint NOT NULL DEFAULT '0' COMMENT '状态',
  `tip` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '提示',
  `is_dev` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '是否开发者可见',
  `listorder` smallint unsigned NOT NULL DEFAULT '0' COMMENT '排序ID',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `pid` (`parentid`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=175 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='后台菜单表';

-- -----------------------------
-- Records of `mny_menu`
-- -----------------------------
INSERT INTO `mny_menu` VALUES ('3', '设置', 'icon-setup', '0', 'admin', 'setting', 'index', '', '1', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('4', '模块', 'icon-apps-line', '0', 'admin', 'module', 'index1', '', '1', '', '0', '9');
INSERT INTO `mny_menu` VALUES ('5', '扩展', 'icon-equalizer-line', '0', 'addons', 'addons', 'index1', '', '1', '', '0', '10');
INSERT INTO `mny_menu` VALUES ('8', '个人资料', '', '10', 'admin', 'profile', 'index', '', '0', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('9', '资料更新', '', '10', 'admin', 'profile', 'update', '', '0', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('10', '系统配置', 'icon-zidongxiufu', '3', 'admin', 'config', 'index1', '', '1', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('11', '配置管理', 'icon-apartment', '10', 'admin', 'config', 'index', '', '1', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('12', '删除日志', '', '20', 'admin', 'adminlog', 'deletelog', '', '1', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('13', '网站设置', 'icon-setup', '10', 'admin', 'config', 'setting', '', '1', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('14', '菜单管理', 'icon-other', '10', 'admin', 'menu', 'index', '', '1', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('15', '权限管理', 'icon-user-settings-line', '3', 'admin', 'manager', 'index1', '', '1', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('16', '管理员管理', 'icon-user-settings-line', '15', 'admin', 'manager', 'index', '', '1', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('17', '角色管理', 'icon-user-shared-2-line', '15', 'admin', 'authManager', 'index', '', '1', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('18', '添加管理员', '', '16', 'admin', 'manager', 'add', '', '1', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('19', '编辑管理员', '', '16', 'admin', 'manager', 'edit', '', '1', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('20', '管理日志', 'icon-history', '15', 'admin', 'AdminLog', 'index', '', '1', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('21', '删除管理员', '', '16', 'admin', 'manager', 'del', '', '1', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('22', '添加角色', '', '17', 'admin', 'authManager', 'createGroup', '', '1', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('23', '附件管理', 'icon-accessory', '10', 'attachment', 'attachments', 'index', '', '1', '', '0', '1');
INSERT INTO `mny_menu` VALUES ('24', '新增配置', '', '11', 'admin', 'config', 'add', '', '1', '', '0', '1');
INSERT INTO `mny_menu` VALUES ('25', '编辑配置', '', '11', 'admin', 'config', 'edit', '', '1', '', '0', '2');
INSERT INTO `mny_menu` VALUES ('26', '删除配置', '', '11', 'admin', 'config', 'del', '', '1', '', '0', '3');
INSERT INTO `mny_menu` VALUES ('27', '批量更新', '', '11', 'admin', 'config', 'multi', '', '1', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('28', '新增菜单', '', '14', 'admin', 'menu', 'add', '', '1', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('29', '编辑菜单', '', '14', 'admin', 'menu', 'edit', '', '1', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('30', '删除菜单', '', '14', 'admin', 'menu', 'del', '', '1', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('31', '批量更新', '', '14', 'admin', 'menu', 'multi', '', '1', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('32', '附件上传', '', '23', 'attachment', 'attachments', 'upload', '', '1', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('33', '附件删除', '', '23', 'attachment', 'attachments', 'del', '', '1', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('34', '编辑器附件', '', '23', 'attachment', 'ueditor', 'run', '', '0', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('35', '图片列表', '', '23', 'attachment', 'attachments', 'showFileLis', '', '0', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('36', '图片本地化', '', '23', 'attachment', 'attachments', 'getUrlFile', '', '0', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('37', '图片选择', '', '23', 'attachment', 'attachments', 'select', '', '0', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('38', '插件扩展', 'icon-equalizer-line', '5', 'addons', 'addons', 'index2', '', '1', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('39', '插件管理', 'icon-apartment', '38', 'addons', 'addons', 'index', '', '1', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('41', '插件后台列表', 'icon-liebiaosousuo', '5', 'addons', 'addons', 'addonadmin', '', '1', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('43', '本地模块', 'icon-apps-line', '4', 'admin', 'module', 'index2', '', '0', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('44', '模块管理', 'icon-apartment', '43', 'admin', 'module', 'index', '', '1', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('45', '模块列表', 'icon-liebiaosousuo', '4', 'admin', 'module', 'index', '', '1', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('48', '编辑角色', '', '17', 'admin', 'authManager', 'editGroup', '', '1', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('49', '删除角色', '', '17', 'admin', 'authManager', 'deleteGroup', '', '1', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('50', '访问授权', '', '17', 'admin', 'authManager', 'access', '', '1', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('51', '角色授权', '', '17', 'admin', 'authManager', 'writeGroup', '', '1', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('52', '模块安装', '', '44', 'admin', 'module', 'install', '', '1', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('53', '模块卸载', '', '44', 'admin', 'module', 'uninstall', '', '1', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('54', '本地安装', '', '44', 'admin', 'module', 'local', '', '1', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('55', '插件设置', '', '39', 'addons', 'addons', 'config', '', '1', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('56', '插件安装', '', '39', 'addons', 'addons', 'install', '', '1', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('57', '插件卸载', '', '39', 'addons', 'addons', 'uninstall', '', '1', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('58', '插件状态', '', '39', 'addons', 'addons', 'state', '', '1', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('59', '本地安装', '', '39', 'addons', 'addons', 'local', '', '1', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('60', '用户', 'icon-user-line', '0', 'member', 'member', 'index2', '', '1', '', '0', '4');
INSERT INTO `mny_menu` VALUES ('61', '用户管理', 'icon-user-line', '60', 'member', 'member', 'index1', '', '1', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('62', '用户设置', 'icon-user-settings-line', '61', 'member', 'setting', 'setting', '', '1', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('63', '用户管理', 'icon-user-shared-2-line', '61', 'member', 'member', 'index', '', '1', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('64', '审核会员', 'icon-user-star-line', '61', 'member', 'member', 'userverify', '', '0', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('65', '会员添加', '', '61', 'member', 'member', 'add', '', '0', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('66', '会员编辑', '', '61', 'member', 'member', 'edit', '', '0', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('67', '会员删除', '', '61', 'member', 'member', 'del', '', '0', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('68', '会员审核', '', '61', 'member', 'member', 'pass', '', '0', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('69', '会员组', 'icon-group-line', '60', 'member', 'group', 'index1', '', '0', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('70', '会员组管理', 'icon-user-settings-line', '69', 'member', 'group', 'index', '', '0', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('71', '会员组添加', '', '69', 'member', 'group', 'add', '', '0', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('72', '会员组编辑', '', '69', 'member', 'group', 'edit', '', '0', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('73', '会员组删除', '', '69', 'member', 'group', 'del', '', '0', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('74', '友情链接', 'icon-lianjie', '45', 'links', 'links', 'index', '', '0', '友情链接！', '0', '0');
INSERT INTO `mny_menu` VALUES ('75', '添加友情链接', '', '74', 'links', 'links', 'add', '', '0', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('76', '链接编辑', '', '74', 'links', 'links', 'edit', '', '0', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('77', '链接删除', '', '74', 'links', 'links', 'del', '', '0', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('78', '批量操作', '', '74', 'links', 'links', 'multi', '', '0', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('79', '分类管理', '', '74', 'links', 'links', 'terms', '', '0', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('80', '分类新增', '', '74', 'links', 'links', 'addTerms', '', '0', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('81', '分类修改', '', '74', 'links', 'links', 'termsedit', '', '0', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('82', '分类删除', '', '74', 'links', 'links', 'termsdelete', '', '0', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('83', '商城', 'icon-draft-line', '0', 'cms', 'cms', 'index1', '', '1', '', '0', '3');
INSERT INTO `mny_menu` VALUES ('84', '内容管理', 'icon-draft-line', '83', 'cms', 'cms', 'index2', '', '1', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('85', '管理内容', 'icon-draft-line', '84', 'cms', 'cms', 'index', '', '0', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('86', '面板', '', '85', 'cms', 'cms', 'panl', '', '0', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('87', '信息列表', '', '85', 'cms', 'cms', 'classlist', '', '0', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('88', '添加', '', '85', 'cms', 'cms', 'add', '', '0', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('89', '编辑', '', '85', 'cms', 'cms', 'edit', '', '0', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('90', '删除', '', '85', 'cms', 'cms', 'del', '', '0', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('91', '排序', '', '85', 'cms', 'cms', 'listorder', '', '0', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('92', '批量移动', '', '85', 'cms', 'cms', 'remove', '', '0', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('93', '状态', '', '85', 'cms', 'cms', 'setstate', '', '0', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('94', '标题检查', '', '85', 'cms', 'cms', 'check_title', '', '0', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('95', '回收站', 'icon-trash', '85', 'cms', 'cms', 'recycle', '', '0', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('96', '清空回收站', '', '85', 'cms', 'cms', 'destroy', '', '0', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('97', '还原回收站', '', '85', 'cms', 'cms', 'restore', '', '0', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('98', '公告通知', 'icon-draft-line', '84', 'shop', 'notice', 'index', '', '1', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('99', '删除', '', '98', 'cms', 'publish', 'del', '', '0', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('100', '通过', '', '98', 'cms', 'publish', 'pass', '', '0', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('101', '退稿', '', '98', 'cms', 'publish', 'reject', '', '0', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('102', '区域设置', 'icon-git-branch-line', '109', 'shop', 'region', 'index', '', '1', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('103', '列表', '', '102', 'cms', 'tags', 'index', '', '0', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('104', '添加', '', '102', 'cms', 'tags', 'add', '', '0', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('105', '编辑', '', '102', 'cms', 'tags', 'edit', '', '0', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('106', '删除', '', '102', 'cms', 'tags', 'del', '', '0', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('107', '数据重建', '', '102', 'cms', 'tags', 'create', '', '0', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('108', '批量更新', '', '102', 'cms', 'tags', 'multi', '', '0', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('109', '相关设置', 'icon-file-settings-line', '83', 'cms', 'category', 'index1', '', '1', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('110', '商城配置', 'icon-file-settings-line', '109', 'shop', 'setting', 'index', '', '1', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('111', '商品分类', 'icon-other', '162', 'shop', 'category', 'index', '', '1', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('112', '添加栏目', '', '111', 'cms', 'category', 'add', '', '0', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('113', '添加单页', '', '111', 'cms', 'category', 'singlepage', '', '0', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('114', '栏目授权', '', '111', 'cms', 'category', 'cat_priv', '', '0', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('115', '编辑栏目', '', '111', 'cms', 'category', 'edit', '', '0', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('116', '删除栏目', '', '111', 'cms', 'category', 'del', '', '0', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('117', '批量更新', '', '111', 'cms', 'category', 'multi', '', '0', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('118', '栏目模板', '', '111', 'cms', 'category', 'public_tpl_file_list', '', '0', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('119', '模型管理', 'icon-apartment', '109', 'cms', 'models', 'index', '', '0', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('120', '字段管理', '', '119', 'cms', 'field', 'index', '', '0', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('121', '字段添加', '', '119', 'cms', 'field', 'add', '', '0', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('122', '字段编辑', '', '119', 'cms', 'field', 'edit', '', '0', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('123', '字段删除', '', '119', 'cms', 'field', 'del', '', '0', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('124', '字段排序', '', '119', 'cms', 'field', 'listorder', '', '0', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('125', '字段状态', '', '119', 'cms', 'field', 'setstate', '', '0', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('126', '字段搜索', '', '119', 'cms', 'field', 'setsearch', '', '0', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('127', '字段隐藏', '', '119', 'cms', 'field', 'setvisible', '', '0', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('128', '字段必须', '', '119', 'cms', 'field', 'setrequire', '', '0', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('129', '添加模型', '', '119', 'cms', 'models', 'add', '', '0', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('130', '修改模型', '', '119', 'cms', 'models', 'edit', '', '0', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('131', '删除模型', '', '119', 'cms', 'models', 'del', '', '0', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('132', '批量更新', '', '119', 'cms', 'models', 'multi', '', '0', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('133', '采集', 'icon-apartment', '0', 'collection', 'node', 'index1', '', '0', '', '0', '4');
INSERT INTO `mny_menu` VALUES ('134', '采集管理', 'icon-apartment', '133', 'collection', 'node', 'index2', '', '1', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('135', '采集任务', 'icon-renwu', '134', 'collection', 'node', 'index', '', '1', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('136', '表单管理', 'icon-file-list-3-line', '45', 'formguide', 'formguide', 'index', '', '0', '', '0', '3');
INSERT INTO `mny_menu` VALUES ('137', '添加表单', '', '136', 'formguide', 'formguide', 'add', '', '0', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('138', '编辑表单', '', '136', 'formguide', 'formguide', 'edit', '', '0', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('139', '删除表单', '', '136', 'formguide', 'formguide', 'del', '', '0', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('140', '字段管理', '', '136', 'formguide', 'field', 'index', '', '0', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('141', '添加字段', '', '136', 'formguide', 'field', 'add', '', '0', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('142', '编辑字段', '', '136', 'formguide', 'field', 'edit', '', '0', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('143', '删除字段', '', '136', 'formguide', 'field', 'del', '', '0', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('144', '信息列表', '', '136', 'formguide', 'info', 'index', '', '0', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('145', '信息查看', '', '136', 'formguide', 'info', 'public_view', '', '0', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('146', '信息删除', '', '136', 'formguide', 'info', 'del', '', '0', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('147', '短消息', 'icon-systemprompt', '45', 'message', 'message', 'index', '', '0', '', '0', '3');
INSERT INTO `mny_menu` VALUES ('148', '消息列表', '', '147', 'message', 'message', 'index', '', '1', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('149', '群发消息列表', '', '147', 'message', 'message', 'group', '', '1', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('150', '群发消息', '', '147', 'message', 'message', 'message_send', '', '1', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('151', '发消息', '', '147', 'message', 'message', 'send_one', '', '1', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('152', '删除短消息', '', '147', 'message', 'message', 'del', '', '1', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('153', '删除群发消息', '', '147', 'message', 'message', 'delete_group', '', '1', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('154', '支付管理', 'icon-money', '45', 'pay', 'payment', 'index', '', '1', '', '0', '3');
INSERT INTO `mny_menu` VALUES ('155', '支付模块', '', '154', 'pay', 'payment', 'pay_list', '', '0', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('156', '支付配置', '', '155', 'pay', 'payment', 'edit', '', '0', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('157', '短信模块', 'icon-interactive_fill', '45', 'sms', 'sms', 'config', '', '0', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('158', '区域红包', 'icon-workbench_fill', '61', 'member', 'member', 'hongbao', '', '1', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('159', '全国地区', 'icon-baidu', '10', 'admin', 'address', 'index', '', '1', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('160', '用户相关', 'icon-group-line', '60', 'member', 'member', 'indexxg', '', '1', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('161', '注册协议', 'icon-file-list-3-line', '160', 'member', 'member', 'agreement', '', '1', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('162', '商品管理', 'icon-caigou-xianxing', '83', 'shop', 'goods', 'index1', '', '1', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('163', '订单管理', 'icon-money', '83', 'shop', 'order', 'index1', '', '1', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('164', '订单列表', 'icon-database-2-fill', '163', 'shop', 'order', 'lists', '', '1', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('165', '轮播图', 'icon-book-2-line', '84', 'shop', 'banner', 'config', '', '1', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('166', '配送点管理', 'icon-file-list-3-fill', '102', 'shop', 'delivery', 'index', '', '1', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('167', '数据库备份', 'icon-circle-line', '41', 'addons', 'database', 'index', 'isadmin=1', '1', '数据库备份插件管理后台！', '0', '0');
INSERT INTO `mny_menu` VALUES ('168', '备份还原', '', '41', 'addons', 'database', 'restore', 'isadmin=1', '0', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('169', '删除备份', '', '41', 'addons', 'database', 'del', 'isadmin=1', '0', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('170', '修复表', '', '41', 'addons', 'database', 'repair', 'isadmin=1', '0', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('171', '优化表', '', '41', 'addons', 'database', 'optimize', 'isadmin=1', '0', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('172', '还原表', '', '41', 'addons', 'database', 'import', 'isadmin=1', '0', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('173', '备份数据库', '', '41', 'addons', 'database', 'export', 'isadmin=1', '0', '', '0', '0');
INSERT INTO `mny_menu` VALUES ('174', '备份数据库下载', '', '41', 'addons', 'database', 'download', 'isadmin=1', '0', '', '0', '0');

-- -----------------------------
-- Table structure for `mny_message`
-- -----------------------------
DROP TABLE IF EXISTS `mny_message`;
CREATE TABLE `mny_message` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `send_from` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0' COMMENT '发件人',
  `send_to` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0' COMMENT '收件人',
  `create_time` int unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `subject` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '主题',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '内容',
  `replyid` int unsigned NOT NULL DEFAULT '0' COMMENT '回复ID',
  `status` tinyint NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `replyid` (`replyid`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;


-- -----------------------------
-- Table structure for `mny_message_data`
-- -----------------------------
DROP TABLE IF EXISTS `mny_message_data`;
CREATE TABLE `mny_message_data` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userid` mediumint NOT NULL,
  `group_message_id` int NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `message` (`userid`,`group_message_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=FIXED;


-- -----------------------------
-- Table structure for `mny_message_group`
-- -----------------------------
DROP TABLE IF EXISTS `mny_message_group`;
CREATE TABLE `mny_message_group` (
  `id` smallint unsigned NOT NULL AUTO_INCREMENT,
  `groupid` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '用户组id',
  `subject` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '标题',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '内容',
  `create_time` int unsigned DEFAULT '0' COMMENT '创建时间',
  `status` tinyint NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;


-- -----------------------------
-- Table structure for `mny_model`
-- -----------------------------
DROP TABLE IF EXISTS `mny_model`;
CREATE TABLE `mny_model` (
  `id` smallint unsigned NOT NULL AUTO_INCREMENT,
  `module` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '所属模块',
  `name` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '模型名称',
  `tablename` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '表名',
  `description` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '描述',
  `setting` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '配置信息',
  `type` tinyint unsigned NOT NULL DEFAULT '1' COMMENT '模型类别：1-独立表，2-主附表',
  `create_time` int unsigned NOT NULL DEFAULT '0' COMMENT '添加时间',
  `update_time` int unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `listorders` tinyint NOT NULL DEFAULT '0' COMMENT '排序',
  `status` tinyint NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='模型列表';

-- -----------------------------
-- Records of `mny_model`
-- -----------------------------
INSERT INTO `mny_model` VALUES ('1', 'cms', '文章模型', 'article', '文章模型', 'a:3:{s:17:\"category_template\";s:13:\"category.html\";s:13:\"list_template\";s:9:\"list.html\";s:13:\"show_template\";s:9:\"show.html\";}', '2', '1546574975', '1566893866', '0', '1');
INSERT INTO `mny_model` VALUES ('2', 'cms', '图片模型', 'picture', '图片模型', 'a:3:{s:17:\"category_template\";s:21:\"category_picture.html\";s:13:\"list_template\";s:17:\"list_picture.html\";s:13:\"show_template\";s:17:\"show_picture.html\";}', '2', '1548754193', '1566896531', '0', '1');
INSERT INTO `mny_model` VALUES ('3', 'cms', '产品模型', 'product', '产品模型', 'a:3:{s:17:\"category_template\";s:21:\"category_picture.html\";s:13:\"list_template\";s:17:\"list_picture.html\";s:13:\"show_template\";s:17:\"show_picture.html\";}', '2', '1549165800', '1566894329', '0', '1');
INSERT INTO `mny_model` VALUES ('4', 'cms', '下载模型', 'download', '下载模型', 'a:3:{s:17:\"category_template\";s:13:\"category.html\";s:13:\"list_template\";s:9:\"list.html\";s:13:\"show_template\";s:9:\"show.html\";}', '2', '1549624988', '1566894292', '0', '1');

-- -----------------------------
-- Table structure for `mny_model_field`
-- -----------------------------
DROP TABLE IF EXISTS `mny_model_field`;
CREATE TABLE `mny_model_field` (
  `id` smallint unsigned NOT NULL AUTO_INCREMENT,
  `modelid` smallint unsigned NOT NULL DEFAULT '0' COMMENT '模型ID',
  `name` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '字段名',
  `title` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '别名',
  `remark` tinytext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '字段提示',
  `pattern` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '数据校验正则',
  `errortips` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '数据校验未通过的提示信息',
  `type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '字段类型',
  `setting` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '字段配置',
  `ifsystem` tinyint unsigned NOT NULL DEFAULT '1' COMMENT '是否主表字段 1 是',
  `iscore` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '是否内部字段',
  `iffixed` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '是否固定不可修改',
  `ifrequire` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '是否必填',
  `ifsearch` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '作为搜索条件',
  `isadd` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '在投稿中显示',
  `create_time` int unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `listorder` smallint unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `status` tinyint NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `name` (`name`,`modelid`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=81 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='模型字段列表';

-- -----------------------------
-- Records of `mny_model_field`
-- -----------------------------
INSERT INTO `mny_model_field` VALUES ('76', '1', 'url', '链接地址', '有值时生效，内部链接格式:模块/控制器/操作?参数=参数值&...，外部链接则必须http://开头', '', '', 'text', 'a:3:{s:6:\"define\";s:32:\"varchar(100) NOT NULL DEFAULT \'\'\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:0:\"\";}', '1', '0', '1', '0', '0', '0', '1608023551', '1608023551', '255', '1');
INSERT INTO `mny_model_field` VALUES ('77', '2', 'url', '链接地址', '有值时生效，内部链接格式:模块/控制器/操作?参数=参数值&...，外部链接则必须http://开头', '', '', 'text', 'a:3:{s:6:\"define\";s:32:\"varchar(100) NOT NULL DEFAULT \'\'\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:0:\"\";}', '1', '0', '1', '0', '0', '0', '1608023551', '1608023551', '255', '1');
INSERT INTO `mny_model_field` VALUES ('78', '3', 'url', '链接地址', '有值时生效，内部链接格式:模块/控制器/操作?参数=参数值&...，外部链接则必须http://开头', '', '', 'text', 'a:3:{s:6:\"define\";s:32:\"varchar(100) NOT NULL DEFAULT \'\'\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:0:\"\";}', '1', '0', '1', '0', '0', '0', '1608023551', '1608023551', '255', '1');
INSERT INTO `mny_model_field` VALUES ('79', '4', 'url', '链接地址', '有值时生效，内部链接格式:模块/控制器/操作?参数=参数值&...，外部链接则必须http://开头', '', '', 'text', 'a:3:{s:6:\"define\";s:32:\"varchar(100) NOT NULL DEFAULT \'\'\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:0:\"\";}', '1', '0', '1', '0', '0', '0', '1608023551', '1608023551', '255', '1');
INSERT INTO `mny_model_field` VALUES ('74', '3', 'thumb', '缩略图', '', '', '', 'image', 'a:3:{s:6:\"define\";s:13:\"text NOT NULL\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:0:\"\";}', '1', '0', '0', '0', '0', '1', '1565948216', '1565948216', '275', '1');
INSERT INTO `mny_model_field` VALUES ('75', '4', 'thumb', '缩略图', '', '', '', 'image', 'a:3:{s:6:\"define\";s:13:\"text NOT NULL\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:0:\"\";}', '1', '0', '0', '0', '0', '1', '1565948216', '1565948216', '275', '1');
INSERT INTO `mny_model_field` VALUES ('73', '2', 'thumb', '缩略图', '', '', '', 'image', 'a:3:{s:6:\"define\";s:13:\"text NOT NULL\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:0:\"\";}', '1', '0', '0', '0', '0', '1', '1565948216', '1565948216', '275', '1');
INSERT INTO `mny_model_field` VALUES ('70', '4', 'did', '附表文档id', '', '', '', 'hidden', '', '0', '1', '1', '0', '0', '0', '1549624988', '1549624988', '100', '1');
INSERT INTO `mny_model_field` VALUES ('71', '4', 'content', '内容', '', '', '', 'Ueditor', 'a:3:{s:6:\"define\";s:13:\"text NOT NULL\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:0:\"\";}', '0', '0', '0', '0', '0', '1', '1549624988', '1549624988', '270', '1');
INSERT INTO `mny_model_field` VALUES ('72', '1', 'thumb', '缩略图', '', '', '', 'image', 'a:3:{s:6:\"define\";s:13:\"text NOT NULL\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:0:\"\";}', '1', '0', '0', '0', '0', '1', '1565948216', '1565948216', '275', '1');
INSERT INTO `mny_model_field` VALUES ('69', '4', 'hits', '点击量', '', '', '', 'number', 'a:3:{s:6:\"define\";s:42:\"mediumint(8) UNSIGNED NOT NULL DEFAULT \'0\'\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:1:\"0\";}', '1', '0', '1', '0', '0', '0', '1549624988', '1549624988', '265', '1');
INSERT INTO `mny_model_field` VALUES ('68', '4', 'updatetime', '更新时间', '', '', '', 'datetime', 'a:3:{s:6:\"define\";s:37:\"int(10) UNSIGNED NOT NULL DEFAULT \'0\'\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:0:\"\";}', '1', '1', '1', '0', '0', '0', '1549624988', '1549624988', '245', '1');
INSERT INTO `mny_model_field` VALUES ('66', '4', 'status', '状态', '', '', '', 'radio', 'a:3:{s:6:\"define\";s:40:\"tinyint(2) UNSIGNED NOT NULL DEFAULT \'0\'\";s:7:\"options\";s:21:\"0:待审核\r\n1:通过\";s:5:\"value\";s:1:\"1\";}', '1', '0', '1', '0', '0', '0', '1549624988', '1549624988', '240', '1');
INSERT INTO `mny_model_field` VALUES ('67', '4', 'inputtime', '创建时间', '', '', '', 'datetime', 'a:3:{s:6:\"define\";s:37:\"int(10) UNSIGNED NOT NULL DEFAULT \'0\'\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:0:\"\";}', '1', '0', '1', '0', '0', '0', '1549624988', '1549624988', '250', '1');
INSERT INTO `mny_model_field` VALUES ('62', '4', 'uid', '用户id', '', '', '', 'number', '', '1', '1', '1', '0', '0', '0', '1549624988', '1549624988', '100', '1');
INSERT INTO `mny_model_field` VALUES ('63', '4', 'username', '用户名', '', '', '', 'text', '', '1', '1', '1', '0', '0', '0', '1558767044', '1558767044', '100', '1');
INSERT INTO `mny_model_field` VALUES ('64', '4', 'sysadd', '是否后台添加', '', '', '', 'number', '', '1', '1', '1', '0', '0', '0', '1558767044', '1558767044', '100', '1');
INSERT INTO `mny_model_field` VALUES ('65', '4', 'listorder', '排序', '', '', '', 'number', 'a:3:{s:6:\"define\";s:40:\"tinyint(3) UNSIGNED NOT NULL DEFAULT \'0\'\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:3:\"100\";}', '1', '0', '1', '0', '0', '0', '1549624988', '1549624988', '260', '1');
INSERT INTO `mny_model_field` VALUES ('60', '4', 'description', 'SEO摘要', '如不填写，则自动截取附表中编辑器的200字符', '', '', 'textarea', 'a:3:{s:6:\"define\";s:32:\"varchar(255) NOT NULL DEFAULT \'\'\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:0:\"\";}', '1', '0', '0', '0', '0', '1', '1549624988', '1549624988', '285', '1');
INSERT INTO `mny_model_field` VALUES ('61', '4', 'tags', 'Tags标签', '关键词用回车确认', '', '', 'tags', 'a:3:{s:6:\"define\";s:32:\"varchar(255) NOT NULL DEFAULT \'\'\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:0:\"\";}', '1', '0', '0', '0', '0', '0', '1546574975', '1546574975', '280', '1');
INSERT INTO `mny_model_field` VALUES ('59', '4', 'keywords', 'SEO关键词', '关键词用回车确认', '', '', 'tags', 'a:3:{s:6:\"define\";s:32:\"varchar(255) NOT NULL DEFAULT \'\'\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:0:\"\";}', '1', '0', '0', '0', '0', '1', '1549624988', '1549624988', '290', '1');
INSERT INTO `mny_model_field` VALUES ('58', '4', 'flag', '属性', '', '', '', 'checkbox', 'a:3:{s:6:\"define\";s:31:\"varchar(32) NOT NULL DEFAULT \'\'\";s:7:\"options\";s:76:\"1:置顶[1]\r\n2:头条[2]\r\n3:特荐[3]\r\n4:推荐[4]\r\n5:热点[5]\r\n6:幻灯[6]\";s:5:\"value\";s:0:\"\";}', '1', '0', '1', '0', '0', '0', '1551846870', '1551846870', '295', '1');
INSERT INTO `mny_model_field` VALUES ('55', '4', 'id', '文档id', '', '', '', 'hidden', '', '1', '0', '1', '0', '0', '1', '1549624988', '1549624988', '100', '1');
INSERT INTO `mny_model_field` VALUES ('56', '4', 'catid', '栏目id', '', '', '', 'hidden', '', '1', '0', '1', '0', '0', '1', '1549624988', '1549624988', '100', '1');
INSERT INTO `mny_model_field` VALUES ('57', '4', 'title', '标题', '', '', '', 'text', 'a:3:{s:6:\"define\";s:32:\"varchar(255) NOT NULL DEFAULT \'\'\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:0:\"\";}', '1', '0', '1', '1', '1', '1', '1549624988', '1549624988', '300', '1');
INSERT INTO `mny_model_field` VALUES ('54', '3', 'price', '价格', '', '', '', 'radio', 'a:4:{s:6:\"define\";s:40:\"tinyint(2) UNSIGNED NOT NULL DEFAULT \'0\'\";s:7:\"options\";s:42:\"1:≤2500\r\n2:≤5000\r\n3:≤8000\r\n4:≥1万\";s:10:\"filtertype\";s:1:\"1\";s:5:\"value\";s:0:\"\";}', '1', '0', '0', '1', '0', '1', '1552372433', '1552372433', '0', '1');
INSERT INTO `mny_model_field` VALUES ('53', '3', 'trade', '行业', '', '', '', 'radio', 'a:4:{s:6:\"define\";s:40:\"tinyint(2) UNSIGNED NOT NULL DEFAULT \'0\'\";s:7:\"options\";s:78:\"1:机械设备\r\n2:车辆物流\r\n3:地产建筑装修\r\n4:教育培训\r\n5:其他\";s:10:\"filtertype\";s:1:\"1\";s:5:\"value\";s:0:\"\";}', '1', '0', '0', '1', '0', '1', '1552372387', '1552372387', '0', '1');
INSERT INTO `mny_model_field` VALUES ('50', '3', 'did', '附表文档id', '', '', '', 'hidden', '', '0', '1', '1', '0', '0', '0', '1549165800', '1549165800', '100', '1');
INSERT INTO `mny_model_field` VALUES ('51', '3', 'content', '内容', '', '', '', 'Ueditor', 'a:3:{s:6:\"define\";s:13:\"text NOT NULL\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:0:\"\";}', '0', '0', '0', '0', '0', '1', '1549165800', '1549165800', '270', '1');
INSERT INTO `mny_model_field` VALUES ('52', '3', 'type', '类型', '', '', '', 'radio', 'a:4:{s:6:\"define\";s:40:\"tinyint(2) UNSIGNED NOT NULL DEFAULT \'0\'\";s:7:\"options\";s:91:\"1:营销网站\r\n2:电商网站\r\n3:响应式网站\r\n4:手机网站\r\n5:外贸网站\r\n6:其他\";s:10:\"filtertype\";s:1:\"1\";s:5:\"value\";s:0:\"\";}', '1', '0', '0', '1', '0', '1', '1552368369', '1552372294', '0', '1');
INSERT INTO `mny_model_field` VALUES ('48', '3', 'updatetime', '更新时间', '', '', '', 'datetime', 'a:3:{s:6:\"define\";s:37:\"int(10) UNSIGNED NOT NULL DEFAULT \'0\'\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:0:\"\";}', '1', '1', '1', '0', '0', '0', '1549165800', '1549165800', '245', '1');
INSERT INTO `mny_model_field` VALUES ('49', '3', 'hits', '点击量', '', '', '', 'number', 'a:3:{s:6:\"define\";s:42:\"mediumint(8) UNSIGNED NOT NULL DEFAULT \'0\'\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:1:\"0\";}', '1', '0', '1', '0', '0', '0', '1549165800', '1549165800', '265', '1');
INSERT INTO `mny_model_field` VALUES ('47', '3', 'inputtime', '创建时间', '', '', '', 'datetime', 'a:3:{s:6:\"define\";s:37:\"int(10) UNSIGNED NOT NULL DEFAULT \'0\'\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:0:\"\";}', '1', '0', '1', '0', '0', '0', '1549165800', '1549165800', '250', '1');
INSERT INTO `mny_model_field` VALUES ('44', '3', 'sysadd', '是否后台添加', '', '', '', 'number', '', '1', '1', '1', '0', '0', '0', '1558767044', '1558767044', '100', '1');
INSERT INTO `mny_model_field` VALUES ('45', '3', 'listorder', '排序', '', '', '', 'number', 'a:3:{s:6:\"define\";s:40:\"tinyint(3) UNSIGNED NOT NULL DEFAULT \'0\'\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:3:\"100\";}', '1', '0', '1', '0', '0', '0', '1549165800', '1549165800', '260', '1');
INSERT INTO `mny_model_field` VALUES ('46', '3', 'status', '状态', '', '', '', 'radio', 'a:3:{s:6:\"define\";s:40:\"tinyint(2) UNSIGNED NOT NULL DEFAULT \'0\'\";s:7:\"options\";s:21:\"0:待审核\r\n1:通过\";s:5:\"value\";s:1:\"1\";}', '1', '0', '1', '0', '0', '0', '1549165800', '1549165800', '240', '1');
INSERT INTO `mny_model_field` VALUES ('42', '3', 'uid', '用户id', '', '', '', 'number', '', '1', '1', '1', '0', '0', '0', '1549165800', '1549165800', '100', '1');
INSERT INTO `mny_model_field` VALUES ('43', '3', 'username', '用户名', '', '', '', 'text', '', '1', '1', '1', '0', '0', '0', '1558767044', '1558767044', '100', '1');
INSERT INTO `mny_model_field` VALUES ('41', '3', 'tags', 'Tags标签', '关键词用回车确认', '', '', 'tags', 'a:3:{s:6:\"define\";s:32:\"varchar(255) NOT NULL DEFAULT \'\'\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:0:\"\";}', '1', '0', '0', '0', '0', '0', '1546574975', '1546574975', '280', '1');
INSERT INTO `mny_model_field` VALUES ('40', '3', 'description', 'SEO摘要', '如不填写，则自动截取附表中编辑器的200字符', '', '', 'textarea', 'a:3:{s:6:\"define\";s:32:\"varchar(255) NOT NULL DEFAULT \'\'\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:0:\"\";}', '1', '0', '0', '0', '0', '1', '1549165800', '1549165800', '285', '1');
INSERT INTO `mny_model_field` VALUES ('39', '3', 'keywords', 'SEO关键词', '关键词用回车确认', '', '', 'tags', 'a:3:{s:6:\"define\";s:32:\"varchar(255) NOT NULL DEFAULT \'\'\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:0:\"\";}', '1', '0', '0', '0', '0', '1', '1549165800', '1549165800', '290', '1');
INSERT INTO `mny_model_field` VALUES ('36', '3', 'catid', '栏目id', '', '', '', 'hidden', '', '1', '0', '1', '0', '0', '1', '1549165800', '1549165800', '100', '1');
INSERT INTO `mny_model_field` VALUES ('37', '3', 'title', '标题', '', '', '', 'text', 'a:3:{s:6:\"define\";s:32:\"varchar(255) NOT NULL DEFAULT \'\'\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:0:\"\";}', '1', '0', '1', '1', '1', '1', '1549165800', '1549165800', '300', '1');
INSERT INTO `mny_model_field` VALUES ('38', '3', 'flag', '属性', '', '', '', 'checkbox', 'a:3:{s:6:\"define\";s:31:\"varchar(32) NOT NULL DEFAULT \'\'\";s:7:\"options\";s:76:\"1:置顶[1]\r\n2:头条[2]\r\n3:特荐[3]\r\n4:推荐[4]\r\n5:热点[5]\r\n6:幻灯[6]\";s:5:\"value\";s:0:\"\";}', '1', '0', '1', '0', '0', '0', '1551846870', '1551846870', '295', '1');
INSERT INTO `mny_model_field` VALUES ('33', '2', 'did', '附表文档id', '', '', '', 'hidden', '', '0', '1', '1', '0', '0', '0', '1548754192', '1548754192', '100', '1');
INSERT INTO `mny_model_field` VALUES ('34', '2', 'content', '内容', '', '', '', 'Ueditor', 'a:3:{s:6:\"define\";s:13:\"text NOT NULL\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:0:\"\";}', '0', '0', '0', '0', '0', '1', '1548754192', '1548754192', '270', '1');
INSERT INTO `mny_model_field` VALUES ('35', '3', 'id', '文档id', '', '', '', 'hidden', '', '1', '0', '1', '0', '0', '1', '1549165800', '1549165800', '100', '1');
INSERT INTO `mny_model_field` VALUES ('32', '2', 'hits', '点击量', '', '', '', 'number', 'a:3:{s:6:\"define\";s:42:\"mediumint(8) UNSIGNED NOT NULL DEFAULT \'0\'\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:1:\"0\";}', '1', '0', '1', '0', '0', '0', '1548754192', '1548754192', '265', '1');
INSERT INTO `mny_model_field` VALUES ('31', '2', 'updatetime', '更新时间', '', '', '', 'datetime', 'a:3:{s:6:\"define\";s:37:\"int(10) UNSIGNED NOT NULL DEFAULT \'0\'\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:0:\"\";}', '1', '1', '1', '0', '0', '0', '1548754192', '1548754192', '245', '1');
INSERT INTO `mny_model_field` VALUES ('30', '2', 'inputtime', '创建时间', '', '', '', 'datetime', 'a:3:{s:6:\"define\";s:37:\"int(10) UNSIGNED NOT NULL DEFAULT \'0\'\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:0:\"\";}', '1', '0', '1', '0', '0', '0', '1548754192', '1548754192', '250', '1');
INSERT INTO `mny_model_field` VALUES ('29', '2', 'status', '状态', '', '', '', 'radio', 'a:3:{s:6:\"define\";s:40:\"tinyint(2) UNSIGNED NOT NULL DEFAULT \'0\'\";s:7:\"options\";s:21:\"0:待审核\r\n1:通过\";s:5:\"value\";s:1:\"1\";}', '1', '0', '1', '0', '0', '0', '1548754192', '1548754192', '240', '1');
INSERT INTO `mny_model_field` VALUES ('27', '2', 'sysadd', '是否后台添加', '', '', '', 'number', '', '1', '1', '1', '0', '0', '0', '1558767044', '1558767044', '100', '1');
INSERT INTO `mny_model_field` VALUES ('28', '2', 'listorder', '排序', '', '', '', 'number', 'a:3:{s:6:\"define\";s:40:\"tinyint(3) UNSIGNED NOT NULL DEFAULT \'0\'\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:3:\"100\";}', '1', '0', '1', '0', '0', '0', '1548754192', '1548754192', '260', '1');
INSERT INTO `mny_model_field` VALUES ('24', '2', 'tags', 'Tags标签', '关键词用回车确认', '', '', 'tags', 'a:3:{s:6:\"define\";s:32:\"varchar(255) NOT NULL DEFAULT \'\'\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:0:\"\";}', '1', '0', '0', '0', '0', '0', '1546574975', '1546574975', '280', '1');
INSERT INTO `mny_model_field` VALUES ('25', '2', 'uid', '用户id', '', '', '', 'number', '', '1', '1', '1', '0', '0', '0', '1548754192', '1548754192', '100', '1');
INSERT INTO `mny_model_field` VALUES ('26', '2', 'username', '用户名', '', '', '', 'text', '', '1', '1', '1', '0', '0', '0', '1558767044', '1558767044', '100', '1');
INSERT INTO `mny_model_field` VALUES ('23', '2', 'description', 'SEO摘要', '如不填写，则自动截取附表中编辑器的200字符', '', '', 'textarea', 'a:3:{s:6:\"define\";s:32:\"varchar(255) NOT NULL DEFAULT \'\'\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:0:\"\";}', '1', '0', '0', '0', '0', '1', '1548754192', '1548754192', '285', '1');
INSERT INTO `mny_model_field` VALUES ('22', '2', 'keywords', 'SEO关键词', '关键词用回车确认', '', '', 'tags', 'a:3:{s:6:\"define\";s:32:\"varchar(255) NOT NULL DEFAULT \'\'\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:0:\"\";}', '1', '0', '0', '0', '0', '1', '1548754192', '1548754192', '290', '1');
INSERT INTO `mny_model_field` VALUES ('20', '2', 'title', '标题', '', '', '', 'text', 'a:3:{s:6:\"define\";s:32:\"varchar(255) NOT NULL DEFAULT \'\'\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:0:\"\";}', '1', '0', '1', '1', '1', '1', '1548754192', '1548754192', '300', '1');
INSERT INTO `mny_model_field` VALUES ('21', '2', 'flag', '属性', '', '', '', 'checkbox', 'a:3:{s:6:\"define\";s:31:\"varchar(32) NOT NULL DEFAULT \'\'\";s:7:\"options\";s:76:\"1:置顶[1]\r\n2:头条[2]\r\n3:特荐[3]\r\n4:推荐[4]\r\n5:热点[5]\r\n6:幻灯[6]\";s:5:\"value\";s:0:\"\";}', '1', '0', '1', '0', '0', '0', '1551846870', '1551846870', '295', '1');
INSERT INTO `mny_model_field` VALUES ('6', '1', 'description', 'SEO摘要', '如不填写，则自动截取附表中编辑器的200字符', '', '', 'textarea', 'a:3:{s:6:\"define\";s:32:\"varchar(255) NOT NULL DEFAULT \'\'\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:0:\"\";}', '1', '0', '0', '0', '0', '1', '1546574975', '1546574975', '285', '1');
INSERT INTO `mny_model_field` VALUES ('7', '1', 'tags', 'Tags标签', '关键词用回车确认', '', '', 'tags', 'a:3:{s:6:\"define\";s:32:\"varchar(255) NOT NULL DEFAULT \'\'\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:0:\"\";}', '1', '0', '0', '0', '0', '0', '1546574975', '1546574975', '280', '1');
INSERT INTO `mny_model_field` VALUES ('8', '1', 'uid', '用户id', '', '', '', 'number', '', '1', '1', '1', '0', '0', '0', '1546574975', '1546574975', '100', '1');
INSERT INTO `mny_model_field` VALUES ('9', '1', 'username', '用户名', '', '', '', 'text', '', '1', '1', '1', '0', '0', '0', '1558767044', '1558767044', '100', '1');
INSERT INTO `mny_model_field` VALUES ('10', '1', 'sysadd', '是否后台添加', '', '', '', 'number', '', '1', '1', '1', '0', '0', '0', '1558767044', '1558767044', '100', '1');
INSERT INTO `mny_model_field` VALUES ('11', '1', 'listorder', '排序', '', '', '', 'number', 'a:3:{s:6:\"define\";s:40:\"tinyint(3) UNSIGNED NOT NULL DEFAULT \'0\'\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:3:\"100\";}', '1', '0', '1', '0', '0', '0', '1546574975', '1546574975', '260', '1');
INSERT INTO `mny_model_field` VALUES ('12', '1', 'status', '状态', '', '', '', 'radio', 'a:3:{s:6:\"define\";s:40:\"tinyint(2) UNSIGNED NOT NULL DEFAULT \'0\'\";s:7:\"options\";s:21:\"0:待审核\r\n1:通过\";s:5:\"value\";s:1:\"1\";}', '1', '0', '1', '0', '0', '0', '1546574975', '1546574975', '240', '1');
INSERT INTO `mny_model_field` VALUES ('13', '1', 'inputtime', '创建时间', '', '', '', 'datetime', 'a:3:{s:6:\"define\";s:37:\"int(10) UNSIGNED NOT NULL DEFAULT \'0\'\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:0:\"\";}', '1', '0', '1', '0', '0', '0', '1546574975', '1546574975', '250', '1');
INSERT INTO `mny_model_field` VALUES ('14', '1', 'updatetime', '更新时间', '', '', '', 'datetime', 'a:3:{s:6:\"define\";s:37:\"int(10) UNSIGNED NOT NULL DEFAULT \'0\'\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:0:\"\";}', '1', '1', '1', '0', '0', '0', '1546574975', '1546574975', '245', '1');
INSERT INTO `mny_model_field` VALUES ('15', '1', 'hits', '点击量', '', '', '', 'number', 'a:3:{s:6:\"define\";s:42:\"mediumint(8) UNSIGNED NOT NULL DEFAULT \'0\'\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:1:\"0\";}', '1', '0', '1', '0', '0', '0', '1546574975', '1546574975', '265', '1');
INSERT INTO `mny_model_field` VALUES ('16', '1', 'did', '附表文档id', '', '', '', 'hidden', '', '0', '1', '1', '0', '0', '0', '1546574975', '1546574975', '100', '1');
INSERT INTO `mny_model_field` VALUES ('17', '1', 'content', '内容', '', '', '', 'Ueditor', 'a:3:{s:6:\"define\";s:13:\"text NOT NULL\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:0:\"\";}', '0', '0', '0', '0', '0', '1', '1546574975', '1546574975', '270', '1');
INSERT INTO `mny_model_field` VALUES ('18', '2', 'id', '文档id', '', '', '', 'hidden', '', '1', '0', '1', '0', '0', '1', '1548754192', '1548754192', '100', '1');
INSERT INTO `mny_model_field` VALUES ('19', '2', 'catid', '栏目id', '', '', '', 'hidden', '', '1', '0', '1', '0', '0', '1', '1548754192', '1548754192', '100', '1');
INSERT INTO `mny_model_field` VALUES ('1', '1', 'id', '文档id', '', '', '', 'hidden', '', '1', '0', '1', '0', '0', '1', '1546574975', '1546574975', '100', '1');
INSERT INTO `mny_model_field` VALUES ('2', '1', 'catid', '栏目id', '', '', '', 'hidden', '', '1', '0', '1', '0', '0', '1', '1546574975', '1546574975', '100', '1');
INSERT INTO `mny_model_field` VALUES ('3', '1', 'title', '标题', '', '', '', 'text', 'a:3:{s:6:\"define\";s:32:\"varchar(255) NOT NULL DEFAULT \'\'\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:0:\"\";}', '1', '0', '1', '1', '1', '1', '1546574975', '1546574975', '300', '1');
INSERT INTO `mny_model_field` VALUES ('4', '1', 'flag', '属性', '', '', '', 'checkbox', 'a:3:{s:6:\"define\";s:31:\"varchar(32) NOT NULL DEFAULT \'\'\";s:7:\"options\";s:76:\"1:置顶[1]\r\n2:头条[2]\r\n3:特荐[3]\r\n4:推荐[4]\r\n5:热点[5]\r\n6:幻灯[6]\";s:5:\"value\";s:0:\"\";}', '1', '0', '0', '0', '0', '0', '1551846870', '1551846870', '295', '1');
INSERT INTO `mny_model_field` VALUES ('5', '1', 'keywords', 'SEO关键词', '关键词用回车确认', '', '', 'tags', 'a:3:{s:6:\"define\";s:32:\"varchar(255) NOT NULL DEFAULT \'\'\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:0:\"\";}', '1', '0', '0', '0', '0', '1', '1546574975', '1546574975', '290', '1');
INSERT INTO `mny_model_field` VALUES ('80', '1', 'item', '测试', '', '', '', 'array', 'a:3:{s:6:\"define\";s:21:\"varchar(512) NOT NULL\";s:5:\"value\";s:0:\"\";s:7:\"options\";s:0:\"\";}', '1', '0', '0', '1', '0', '1', '1661157240', '1661157251', '300', '1');

-- -----------------------------
-- Table structure for `mny_module`
-- -----------------------------
DROP TABLE IF EXISTS `mny_module`;
CREATE TABLE `mny_module` (
  `module` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '模块',
  `name` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '模块名称',
  `sign` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '签名',
  `iscore` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '内置模块',
  `version` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '版本',
  `setting` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '设置信息',
  `create_time` int NOT NULL DEFAULT '0' COMMENT '安装时间',
  `update_time` int NOT NULL DEFAULT '0' COMMENT '更新时间',
  `listorder` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `status` tinyint NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`module`) USING BTREE,
  KEY `sign` (`sign`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='已安装模块列表';

-- -----------------------------
-- Records of `mny_module`
-- -----------------------------
INSERT INTO `mny_module` VALUES ('member', '用户模块', 'fcfe4d97f35d1f30df5d6018a84f74ba', '0', '1.0.0', 'a:3:{s:11:\"new_hongbao\";s:1:\"1\";s:9:\"agreement\";s:18:\"<p>23123123213</p>\";s:7:\"privacy\";s:18:\"<p>12312321344</p>\";}', '1660202995', '1663569453', '0', '1');
INSERT INTO `mny_module` VALUES ('links', '友情链接', '960c30f9b119fa6c39a4a31867441c82', '0', '1.0.0', '', '1660203009', '1660203009', '0', '1');
INSERT INTO `mny_module` VALUES ('shop', '商城模块', 'b19cc279ed484c13c96c2f7142e2f437', '0', '1.0.0', 'a:11:{s:15:\"web_site_status\";s:1:\"1\";s:16:\"site_weight_unit\";s:2:\"kg\";s:13:\"point_convert\";s:3:\"100\";s:13:\"pay_wait_time\";s:1:\"1\";s:13:\"site_url_mode\";s:1:\"1\";s:9:\"site_name\";s:24:\"安购网络生鲜商城\";s:8:\"index_bg\";s:62:\"/uploads/images/20220920/c3575ec4b98df4181618d3e65eb5d13c.jpeg\";s:13:\"luckdraw_rule\";s:19:\"<p>抽奖规则</p>\";s:7:\"contact\";s:19:\"<p>联系我们</p>\";s:5:\"about\";s:19:\"<p>关于我们</p>\";s:7:\"my_kefu\";s:19:\"<p>我的客服</p>\";}', '1660203025', '1663927167', '0', '1');
INSERT INTO `mny_module` VALUES ('apidoc', '接口文档模块', 'b19cc279ed484c13c96c2f7142e2f437', '0', '1.0.0', '', '1660203031', '1660203031', '0', '1');
INSERT INTO `mny_module` VALUES ('collection', '采集模块', 'b19cc279ed484c13c96c2f7142e2f437', '0', '1.0.0', '', '1660203037', '1660203037', '0', '1');
INSERT INTO `mny_module` VALUES ('formguide', '表单模块', '1fa2d9a6f16e75616918c57ce3b88440', '0', '1.0.0', '', '1660203042', '1660203042', '0', '1');
INSERT INTO `mny_module` VALUES ('message', '消息模块', 'b19cc279ed484c13c96c2f7142e2f437', '0', '1.0.0', '', '1660203054', '1660203054', '0', '1');
INSERT INTO `mny_module` VALUES ('pay', '支付模块', 'b803d6de0bf866df8350ca074efdd02e', '0', '1.0.0', '', '1660203058', '1660203058', '0', '1');

-- -----------------------------
-- Table structure for `mny_page`
-- -----------------------------
DROP TABLE IF EXISTS `mny_page`;
CREATE TABLE `mny_page` (
  `catid` smallint unsigned NOT NULL DEFAULT '0' COMMENT '栏目ID',
  `title` varchar(160) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '标题',
  `keywords` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '关键字',
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'SEO描述',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '内容',
  `thumb` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '缩略图',
  `inputtime` int unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `updatetime` int unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  PRIMARY KEY (`catid`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='单页内容表';

-- -----------------------------
-- Records of `mny_page`
-- -----------------------------
INSERT INTO `mny_page` VALUES ('2', '关于我们', '', '', '<p>&nbsp; &nbsp; xxx网络科技股份有限公司是一家集策略咨询、创意创新、视觉设计、技术研发、内容制造、营销推广为一体的综合型数字化创新服务企业，其利用公司持续积累的核心技术和互联网思维，提供以互联网、移动互联网为核心的网络技术服务和互动整合营销服务，为传统企业实现“互联网+”升级提供整套解决方案。公司定位于中大型企业为核心客户群，可充分满足这一群体相比中小企业更为丰富、高端、多元的互联网数字综合需求。</p><p><br/></p><p>&nbsp; &nbsp; xxx网络科技股份有限公司作为一家互联网数字服务综合商，其主营业务包括移动互联网应用开发服务、数字互动整合营销服务、互联网网站建设综合服务和电子商务综合服务。</p><p><br/></p><p>&nbsp; &nbsp; xxx网络科技股份有限公司秉承实现全网价值营销的理念，通过实现互联网与移动互联网的精准数字营销和用户数据分析，日益深入到客户互联网技术建设及运维营销的方方面面，在帮助客户形成自身互联网运作体系的同时，有效对接BAT(百度，阿里，腾讯)等平台即百度搜索、阿里电商、腾讯微信，通过平台的推广来推进互联网综合服务，实现企业、用户、平台三者完美对接，并形成高效互动的枢纽，在帮助客户获取互联网高附加价值的同时获得自身的不断成长和壮大。</p>', '', '0', '0');
INSERT INTO `mny_page` VALUES ('3', '企业文化', '', '', '<p>【愿景】</p><ul class=\" list-paddingleft-2\" style=\"list-style-type: disc;\"><li><p>不断倾听和满足用户需求，引导并超越用户需求，赢得用户尊敬</p></li><li><p>通过提升品牌形象，使员工具有高度企业荣誉感，赢得员工尊敬&nbsp;</p></li><li><p>推动互联网行业的健康发展，与合作伙伴共成长，赢得行业尊敬</p></li><li><p>注重企业责任，用心服务，关爱社会、回馈社会，赢得社会尊敬</p></li></ul><p><br/></p><p>【使命】</p><ul class=\" list-paddingleft-2\" style=\"list-style-type: disc;\"><li><p>使产品和服务像水和电融入人们的生活，为人们带来便捷和愉悦</p></li><li><p>关注不同地域、群体，并针对不同对象提供差异化的产品和服务</p></li><li><p>打造开放共赢平台，与合作伙伴共同营造健康的互联网生态环境</p></li></ul><p><br/></p><p>【管理理念】</p><ul class=\" list-paddingleft-2\" style=\"list-style-type: disc;\"><li><p>为员工提供良好的工作环境和激励机制&nbsp;</p></li><li><p>完善员工培养体系和职业发展通道，使员工与企业同步成长</p></li><li><p>充分尊重和信任员工，不断引导和鼓励，使其获得成就的喜悦</p></li></ul>', '', '0', '0');
INSERT INTO `mny_page` VALUES ('18', '联系我们', '', '', '<p>手　机：158-88888888</p><p>传　真：0512-88888888</p><p>邮　编：215000</p><p>邮　箱：admin@admin.com</p><p>地　址：江苏省苏州市吴中区某某工业园一区</p><p><br/></p><p><img width=\"530\" height=\"340\" src=\"http://api.map.baidu.com/staticimage?center=116.404,39.915&zoom=10&width=530&height=340&markers=116.404,39.915\"/></p>', '', '0', '0');

-- -----------------------------
-- Table structure for `mny_pay_account`
-- -----------------------------
DROP TABLE IF EXISTS `mny_pay_account`;
CREATE TABLE `mny_pay_account` (
  `id` mediumint unsigned NOT NULL AUTO_INCREMENT COMMENT '交易ID',
  `trade_sn` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '订单ID',
  `uid` int unsigned NOT NULL COMMENT '用户ID',
  `username` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '用户名',
  `money` varchar(8) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '价格',
  `addtime` int NOT NULL DEFAULT '0' COMMENT '添加时间',
  `paytime` int NOT NULL DEFAULT '0' COMMENT '支付时间',
  `usernote` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '备注',
  `pay_type` enum('offline','recharge','selfincome','online') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'recharge' COMMENT '支付类型',
  `payment` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '支付方式名称',
  `type` tinyint unsigned NOT NULL DEFAULT '1' COMMENT '1金钱or2点数',
  `ip` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '操作IP',
  `status` enum('succ','failed','error','progress','timeout','cancel','waitting','unpay') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'unpay' COMMENT '状态',
  `adminnote` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '管理员记录',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `status` (`status`) USING BTREE,
  KEY `uid` (`uid`) USING BTREE,
  KEY `trade_sn` (`trade_sn`,`money`,`status`,`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='交易数据表';

-- -----------------------------
-- Records of `mny_pay_account`
-- -----------------------------
INSERT INTO `mny_pay_account` VALUES ('1', '20220827061716000000012801', '1', 'jinsong', '1', '1661595436', '1661595436', '', 'recharge', '后台充值', '1', '127.0.0.1', 'succ', 'admin');
INSERT INTO `mny_pay_account` VALUES ('2', '20220827061802000000012943', '1', 'jinsong', '1', '1661595482', '1661595482', '12', 'recharge', '后台充值', '1', '127.0.0.1', 'succ', 'admin');
INSERT INTO `mny_pay_account` VALUES ('3', '20220827061857000000014935', '1', 'jinsong', '1', '1661595537', '0', '', 'online', '支付宝', '1', '127.0.0.1', 'unpay', '');
INSERT INTO `mny_pay_account` VALUES ('4', '20220827072248000000013278', '1', 'jinsong', '1', '1661599368', '0', '', 'online', '微信', '1', '127.0.0.1', 'unpay', '');

-- -----------------------------
-- Table structure for `mny_pay_payment`
-- -----------------------------
DROP TABLE IF EXISTS `mny_pay_payment`;
CREATE TABLE `mny_pay_payment` (
  `id` tinyint unsigned NOT NULL AUTO_INCREMENT COMMENT '方式ID',
  `name` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '方式名称',
  `title` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `icon` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '图标',
  `pay_desc` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '支付描述',
  `config` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '配置信息',
  `status` tinyint NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='支付模块表';

-- -----------------------------
-- Records of `mny_pay_payment`
-- -----------------------------
INSERT INTO `mny_pay_payment` VALUES ('1', 'alipay', '支付宝', 'icon-zhifubao', '支付宝是国内领先的独立第三方支付平台，由阿里巴巴集团创办。致力于为中国电子商务提供“简单、安全、快速”的在线支付解决方案。', '', '1');
INSERT INTO `mny_pay_payment` VALUES ('2', 'wechat', '微信', 'icon-weixin', '腾讯集团旗下中国领先的第三方支付平台，致力于为用户和企业提供安全、便捷、专业的在线支付服务', 'a:6:{s:6:\"app_id\";s:18:\"wx608c410294f7f3cd\";s:10:\"app_secret\";s:32:\"cb372331641e795554f6150471a0e9c9\";s:6:\"mch_id\";s:10:\"1610832555\";s:3:\"key\";s:32:\"wx372331345e799084f6156781a0shv3\";s:4:\"mode\";s:1:\"0\";s:3:\"log\";s:1:\"0\";}', '1');

-- -----------------------------
-- Table structure for `mny_pay_spend`
-- -----------------------------
DROP TABLE IF EXISTS `mny_pay_spend`;
CREATE TABLE `mny_pay_spend` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '消费ID',
  `creat_at` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '消费流水号',
  `uid` int unsigned NOT NULL COMMENT '用户ID',
  `username` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '用户名',
  `type` tinyint unsigned NOT NULL DEFAULT '1' COMMENT '1金钱or2点数',
  `money` varchar(8) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '价格',
  `msg` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '类型说明',
  `addtime` int NOT NULL DEFAULT '0' COMMENT '添加时间',
  `ip` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '操作IP',
  `remarks` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '备注说明',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `type` (`type`) USING BTREE,
  KEY `creat_at` (`creat_at`) USING BTREE,
  KEY `uid` (`uid`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='消费记录表';


-- -----------------------------
-- Table structure for `mny_picture`
-- -----------------------------
DROP TABLE IF EXISTS `mny_picture`;
CREATE TABLE `mny_picture` (
  `id` mediumint unsigned NOT NULL AUTO_INCREMENT COMMENT '文档ID',
  `catid` smallint unsigned NOT NULL DEFAULT '0' COMMENT '栏目ID',
  `title` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT '标题',
  `thumb` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '缩略图',
  `flag` varchar(32) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT '属性',
  `keywords` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT 'SEO关键词',
  `description` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT 'SEO描述',
  `tags` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT 'Tags标签',
  `listorder` smallint unsigned NOT NULL DEFAULT '100' COMMENT '排序',
  `uid` mediumint unsigned NOT NULL DEFAULT '0' COMMENT '用户id',
  `username` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT '用户名',
  `sysadd` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '是否后台添加',
  `hits` mediumint unsigned DEFAULT '0' COMMENT '点击量',
  `inputtime` int unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `updatetime` int unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `url` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '链接地址',
  `status` tinyint NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `status` (`catid`,`status`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='图片模型模型表';

-- -----------------------------
-- Records of `mny_picture`
-- -----------------------------
INSERT INTO `mny_picture` VALUES ('1', '4', 'ISO9001证书', '', '', '', '', '', '100', '1', 'admin', '1', '0', '1550552511', '1550554247', '', '1');
INSERT INTO `mny_picture` VALUES ('2', '4', 'ISO14001证书', '', '', '', '', '', '100', '1', 'admin', '1', '0', '1550554284', '1550554288', '', '1');
INSERT INTO `mny_picture` VALUES ('3', '4', 'OHSAS18001证书', '', '', '', '', '', '100', '1', 'admin', '1', '0', '1550554298', '1550554301', '', '1');
INSERT INTO `mny_picture` VALUES ('4', '4', '企业信用等级评价', '', '', '', '', '', '100', '1', 'admin', '1', '0', '1550554307', '1550554309', '', '1');
INSERT INTO `mny_picture` VALUES ('5', '4', '企业荣誉证书', '', '', '', '', '', '100', '1', 'admin', '1', '0', '1550554314', '1550554316', '', '1');

-- -----------------------------
-- Table structure for `mny_picture_data`
-- -----------------------------
DROP TABLE IF EXISTS `mny_picture_data`;
CREATE TABLE `mny_picture_data` (
  `did` mediumint unsigned NOT NULL DEFAULT '0',
  `content` mediumtext CHARACTER SET utf8 COLLATE utf8_unicode_ci COMMENT '内容',
  PRIMARY KEY (`did`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='图片模型模型表';


-- -----------------------------
-- Table structure for `mny_product`
-- -----------------------------
DROP TABLE IF EXISTS `mny_product`;
CREATE TABLE `mny_product` (
  `id` mediumint unsigned NOT NULL AUTO_INCREMENT COMMENT '文档ID',
  `catid` smallint unsigned NOT NULL DEFAULT '0' COMMENT '栏目ID',
  `title` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT '标题',
  `thumb` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '缩略图',
  `flag` varchar(32) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT '属性',
  `keywords` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT 'SEO关键词',
  `description` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT 'SEO描述',
  `tags` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT 'Tags标签',
  `listorder` smallint unsigned NOT NULL DEFAULT '100' COMMENT '排序',
  `uid` mediumint unsigned NOT NULL DEFAULT '0' COMMENT '用户id',
  `username` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT '用户名',
  `sysadd` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '是否后台添加',
  `hits` mediumint unsigned DEFAULT '0' COMMENT '点击量',
  `inputtime` int unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `updatetime` int unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `url` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '链接地址',
  `status` tinyint NOT NULL DEFAULT '0' COMMENT '状态',
  `type` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '类型',
  `trade` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '行业',
  `price` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '价格',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `status` (`catid`,`status`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='产品模型模型表';

-- -----------------------------
-- Records of `mny_product`
-- -----------------------------
INSERT INTO `mny_product` VALUES ('1', '5', '苏州欧泊**机电进出口有限公司', '', '', '', '苏州欧伯**机电进出口有限公司成立于2014年，是德国HUK/DOPAG/METER MIX定量注脂、打胶产品正式授权的代理商，另经销德国CAPTRON、NORELEM等众多国外知名品牌，可为客户提供从技术咨询、产品销售、技术支持到售后服务的全程服务。公司自成立以来，一直致力于为客户提供德国及欧美地区原产的各类工业备品、备件，并确保100%原厂全新正品。', '注脂,打胶', '100', '1', 'admin', '1', '0', '1552365964', '1553067407', '', '1', '4', '1', '1');
INSERT INTO `mny_product` VALUES ('4', '5', '南通红*居餐饮管理有限公司', '', '4', '', '南通红*居餐饮管理有限公司是一家具有自己的厨师团队，具备丰富的经验，专业承包及管理企事业机关单位、学校、医院、大型工业园区、工厂，建筑工地、写字楼的食堂及营养配餐等后勤项目的大型餐饮承包企业，在上海、江苏、浙江、都有设立公司营业部。团队有500余人，并可为各企业提供专业厨师团队、厨工，勤杂工，免费厨房餐饮管理;餐饮服务，保洁服务，家庭服务；停车场管理服务；劳务派遣经营；绿化维护，食品经营;婚庆礼仪服务;会...', '餐饮管理,婚庆礼仪,劳务派遣', '100', '1', 'admin', '1', '0', '1552366803', '1553067319', '', '1', '3', '5', '3');
INSERT INTO `mny_product` VALUES ('2', '5', '海安华**仓储有限公司', '', '', '', '海安华**仓储有限公司主要以海安物流、仓储为主。 公司秉承“诚信经营、服务至上”的核心价值观；先进的物流理念和丰富的物流操作经验，为不同客户量身定做及提供专业物流方案和优质、高效的物流服务，从而帮客户降低成本，提升市场竞争力。　　公司已和众多知名企业携手合作，共创辉煌；承运范围涵盖了化工、机械、建材、纺织、电子电器、食品、制药、高科技产品等各行各业。', '物流服务', '100', '1', 'admin', '1', '0', '1552366267', '1553067377', '', '1', '5', '2', '3');
INSERT INTO `mny_product` VALUES ('3', '5', '苏州领*线教育科技有限公司', '', '4', '', '苏州领*线教育科技有限公司是一家专注于高品质少儿培训和智能课程开发、提供精品化与专业化相结合的少儿教育科技机构。我们多年来，始终致力于将我们的课堂打造成为孩子快乐成长的乐园与成功的起点，并且成为江苏校外教育的品牌。我们已在苏州市区、常熟、张家港、吴江、昆山、太仓、常州、无锡、杭州、江西九江、内蒙古通辽、山东淄博等地成功开办了教学基地。', '校外教育,智能课程', '100', '1', 'admin', '1', '0', '1552366358', '1553067339', '', '1', '3', '4', '4');
INSERT INTO `mny_product` VALUES ('5', '5', '苏州威*莱斯升降机械设备有限公司', '', '4', '', '苏州威*莱斯升降机械设备有限公司是专业提供各类升降平台出租租赁服务的厂家，自公司创立以来，经过长期对液压升降机、升降平台、高空作业车的研制和探索，积累了丰富的专业经验。凭借丰富的专业技术及不断开拓创新的精神，致力于产品的开发和创新，以自身专业特长，创造高品质的产品。', '机械设备,升降机,租赁服务', '100', '1', 'admin', '1', '0', '1552366872', '1553067296', '', '1', '3', '1', '2');
INSERT INTO `mny_product` VALUES ('6', '5', '苏州非*搬运包装有限公司', '', '4', '', '苏州非*搬运安装有限公司于2016年7月在苏州工业园区这块沸腾的热土上重组合并挂牌成立。随着经济的发展,，公司秉承创新、创优、与时共进的原则把原有四家搬运公司重组洗牌、强强联手。作为一家专业承接各类精密机器设备搬运、装卸、安装定位工程的大企业，公司装备齐全、技术力量雄厚。施工人员均受过国家安全生产监督部门正规的专业培训，持有相应的资格证书，对各种精密机器设备的搬运、安装工程有着丰富的工作经验。施工车辆都是...', '精密机器,专业培训,资格证书', '100', '1', 'admin', '1', '0', '1552366920', '1553067267', '', '1', '1', '5', '1');
INSERT INTO `mny_product` VALUES ('7', '5', '上海朗**业科技有限公司', '', '', '', '上海朗**业科技有限公司，成立于2016年，致力于进口国外先进的工业设备、仪器和耗材。团队成员均由长期从事科学研究、仪器销售与服务人士组成，有着丰富的售前和售后服务经验，可为国内科研、工业客户提供一站式解决方案。“朗助工业，喜翼科技！”一直以来都是团队的奋斗方向, 多年的经营与市场反馈赢得了市场客户的信赖。', '', '100', '1', 'admin', '1', '0', '1589007525', '1589007618', '', '1', '3', '4', '4');
INSERT INTO `mny_product` VALUES ('8', '5', '盐城万**力资源有限公司', '', '', '', '公司以严守合同，诚信服务与客户为本企业的基本操守，坚持“真诚  高效 共赢”的文化理念，先后在城市周边、射阳、大丰、阜宁、徐州、昆山等地设办事处，依托强大、广泛的社会资源和一支团结奋进、具有良好亲和力以及丰富人力资源服务实践和管理经验的团队', '', '100', '1', 'admin', '1', '0', '1589007678', '1589007750', '', '1', '3', '4', '2');
INSERT INTO `mny_product` VALUES ('9', '5', '江苏森**设集团有限公司', '', '', '', '江苏森**设集团有限公司是按照中华人民共和国公司法，于2006 年9 月5 日经过企业改制重组，在江苏省盐城市工商行政管理局亭湖分局注册成立，其性质为有限责任公司，注册资金10088万元。', '', '100', '1', 'admin', '1', '0', '1589007934', '1589008001', '', '1', '1', '1', '2');

-- -----------------------------
-- Table structure for `mny_product_data`
-- -----------------------------
DROP TABLE IF EXISTS `mny_product_data`;
CREATE TABLE `mny_product_data` (
  `did` mediumint unsigned NOT NULL DEFAULT '0',
  `content` mediumtext CHARACTER SET utf8 COLLATE utf8_unicode_ci COMMENT '内容',
  PRIMARY KEY (`did`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='产品模型模型表';

-- -----------------------------
-- Records of `mny_product_data`
-- -----------------------------
INSERT INTO `mny_product_data` VALUES ('1', '&lt;p&gt;苏州欧伯**机电进出口有限公司成立于2014年，是德国HUK/DOPAG/METER MIX定量注脂、打胶产品正式授权的代理商，另经销德国CAPTRON、NORELEM等众多国外知名品牌，可为客户提供从技术咨询、产品销售、技术支持到售后服务的全程服务。公司自成立以来，一直致力于为客户提供德国及欧美地区原产的各类工业备品、备件，并确保100%原厂全新正品。&lt;/p&gt;');
INSERT INTO `mny_product_data` VALUES ('4', '&lt;p&gt;南通红*居餐饮管理有限公司是一家具有自己的厨师团队，具备丰富的经验，专业承包及管理企事业机关单位、学校、医院、大型工业园区、工厂，建筑工地、写字楼的食堂及营养配餐等后勤项目的大型餐饮承包企业，在上海、江苏、浙江、都有设立公司营业部。团队有500余人，并可为各企业提供专业厨师团队、厨工，勤杂工，免费厨房餐饮管理;餐饮服务，保洁服务，家庭服务；停车场管理服务；劳务派遣经营；绿化维护，食品经营;婚庆礼仪服务;会务服务;展览展示服务;厨房设备及用品、餐具、办公用品的销售、餐厅规划设计，厨具设计、出售、安装等服务&lt;/p&gt;');
INSERT INTO `mny_product_data` VALUES ('2', '&lt;p&gt;海安华**仓储有限公司主要以海安物流、仓储为主。 公司秉承“诚信经营、服务至上”的核心价值观；先进的物流理念和丰富的物流操作经验，为不同客户量身定做及提供专业物流方案和优质、高效的物流服务，从而帮客户降低成本，提升市场竞争力。\r\n　　公司已和众多知名企业携手合作，共创辉煌；承运范围涵盖了化工、机械、建材、纺织、电子电器、食品、制药、高科技产品等各行各业。&lt;/p&gt;');
INSERT INTO `mny_product_data` VALUES ('3', '&lt;p&gt;苏州领*线教育科技有限公司是一家专注于高品质少儿培训和智能课程开发、提供精品化与专业化相结合的少儿教育科技机构。我们多年来，始终致力于将我们的课堂打造成为孩子快乐成长的乐园与成功的起点，并且成为江苏校外教育的品牌。我们已在苏州市区、常熟、张家港、吴江、昆山、太仓、常州、无锡、杭州、江西九江、内蒙古通辽、山东淄博等地成功开办了教学基地。&lt;/p&gt;');
INSERT INTO `mny_product_data` VALUES ('5', '&lt;p&gt;苏州威*莱斯升降机械设备有限公司是专业提供各类升降平台出租租赁服务的厂家，自公司创立以来，经过长期对液压升降机、升降平台、高空作业车的研制和探索，积累了丰富的专业经验。凭借丰富的专业技术及不断开拓创新的精神，致力于产品的开发和创新，以自身专业特长，创造高品质的产品。&lt;/p&gt;');
INSERT INTO `mny_product_data` VALUES ('6', '&lt;p&gt;苏州非*搬运安装有限公司于2016年7月在苏州工业园区这块沸腾的热土上重组合并挂牌成立。随着经济的发展,，公司秉承创新、创优、与时共进的原则把原有四家搬运公司重组洗牌、强强联手。作为一家专业承接各类精密机器设备搬运、装卸、安装定位工程的大企业，公司装备齐全、技术力量雄厚。施工人员均受过国家安全生产监督部门正规的专业培训，持有相应的资格证书，对各种精密机器设备的搬运、安装工程有着丰富的工作经验。施工车辆都是定期由特种设备监督局定期安检的，搬运工具都是领先的。长期与多家财险、寿险公司合作，保证客户利益的最大化，员工利益的最大保障。&lt;/p&gt;');
INSERT INTO `mny_product_data` VALUES ('7', '&lt;p&gt;上海朗**业科技有限公司，成立于2016年，致力于进口国外先进的工业设备、仪器和耗材。团队成员均由长期从事科学研究、仪器销售与服务人士组成，有着丰富的售前和售后服务经验，可为国内科研、工业客户提供一站式解决方案。\r\n\r\n“朗助工业，喜翼科技！”一直以来都是团队的奋斗方向, 多年的经营与市场反馈赢得了市场客户的信赖。\r\n&amp;nbsp;&lt;/p&gt;&lt;p&gt;旗下代理合作涵盖了Mettler Toledo, Brand, EIMINC, Leica, CBS, Astero, Thermofisher, UnionMicronClean, Technoflex, SPC, &amp;nbsp;Oxypharm, FRITSCH, Copley等众多一线品牌产品。&lt;/p&gt;');
INSERT INTO `mny_product_data` VALUES ('8', '&lt;p&gt;公司以严守合同，诚信服务与客户为本企业的基本操守，坚持“真诚&amp;nbsp; 高效 共赢”的文化理念，先后在城市周边、射阳、大丰、阜宁、徐州、昆山等地设办事处，依托强大、广泛的社会资源和一支团结奋进、具有良好亲和力以及丰富人力资源服务实践和管理经验的团队，在企业人力资源业务外包服务领域、劳务派遣服务以及劳务输出、劳动事务代理、劳动政策咨询等服务领域形成了独特资源和业务优势，积累了丰富的人力资源业务服务经验，专注于将“道万**力”打招成江苏人力资源及其管理领域的专业服务品牌。&lt;/p&gt;');
INSERT INTO `mny_product_data` VALUES ('9', '&lt;p&gt;&amp;nbsp; 江苏森**设集团有限公司是按照中华人民共和国公司法，于2006 年9 月5 日经过企业改制重组，在江苏省盐城市工商行政管理局亭湖分局注册成立，其性质为有限责任公司，注册资金10088万元。&lt;/p&gt;&lt;p&gt;&amp;nbsp; 公司是自主经营、独立核算、自负盈亏、具有独立法人资格的经济实体，主要从事高空维修、高空安装、高空建筑、高空防腐、高空清洗、高空加固、特种防腐、 地下堵漏以及铁塔防护等方面的高空作业。&lt;/p&gt;&lt;p&gt;&amp;nbsp; 公司设有工程部、施工部、设备部、财务部和法务部，是集工程方案设计、工程施工和质量安全管理等为一体的综合性高空作业工程公司。目前，公司下辖六个分公司，22个项目部。公司本部设有党总支、工会、办公室(兼投标办)、质量安全部、施工技术部、材料设备部。人事教育部和计划财务部，共有员工1086人，具有专业技术人员166人，其中高级工程师12人，项目经理22人。拥有大中型机械设备68台(件)，企业固定资产目前己达亿。年施工产值2亿。&lt;/p&gt;');

-- -----------------------------
-- Table structure for `mny_redbao`
-- -----------------------------
DROP TABLE IF EXISTS `mny_redbao`;
CREATE TABLE `mny_redbao` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '红包名称',
  `type` tinyint(1) DEFAULT '0' COMMENT '1：新人红包 2：其他红包',
  `min_deduct_money` decimal(10,2) NOT NULL COMMENT '最小抵扣金额',
  `deduct_money` decimal(10,2) DEFAULT NULL COMMENT '金额',
  `region_id` int unsigned NOT NULL DEFAULT '0' COMMENT '区域id值',
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '描述说明',
  `create_time` int DEFAULT NULL COMMENT '创建时间',
  `expire_day` int DEFAULT '0' COMMENT '过期天数  天为单位',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='会员Token表';

-- -----------------------------
-- Records of `mny_redbao`
-- -----------------------------
INSERT INTO `mny_redbao` VALUES ('3', '新人红包', '1', '50.00', '10.00', '1', '新人红包描述', '', '10');

-- -----------------------------
-- Table structure for `mny_region`
-- -----------------------------
DROP TABLE IF EXISTS `mny_region`;
CREATE TABLE `mny_region` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `user_num` int DEFAULT '0' COMMENT '用户数量',
  `city_id` int DEFAULT '0',
  `area_id` int DEFAULT '0',
  `province_id` int DEFAULT NULL,
  `area_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `province_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `listorder` int DEFAULT '0',
  `status` tinyint(1) DEFAULT '1' COMMENT '1:启用 0：禁用',
  `create_time` int unsigned DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='短信验证码表';

-- -----------------------------
-- Records of `mny_region`
-- -----------------------------
INSERT INTO `mny_region` VALUES ('1', '0', '189', '1891', '16', '中牟县', '郑州市', '河南省', '0', '1', '0');

-- -----------------------------
-- Table structure for `mny_sms`
-- -----------------------------
DROP TABLE IF EXISTS `mny_sms`;
CREATE TABLE `mny_sms` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `event` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '事件',
  `mobile` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '手机号',
  `code` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '验证码',
  `times` int unsigned NOT NULL DEFAULT '0' COMMENT '验证次数',
  `ip` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '操作IP',
  `create_time` int unsigned DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='短信验证码表';


-- -----------------------------
-- Table structure for `mny_tags`
-- -----------------------------
DROP TABLE IF EXISTS `mny_tags`;
CREATE TABLE `mny_tags` (
  `id` smallint unsigned NOT NULL AUTO_INCREMENT COMMENT 'tagID',
  `tag` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'tag名称',
  `seo_title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'seo标题',
  `seo_keyword` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'seo关键字',
  `seo_description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'seo简介',
  `usetimes` smallint unsigned NOT NULL DEFAULT '0' COMMENT '信息总数',
  `hits` mediumint unsigned NOT NULL DEFAULT '0' COMMENT '点击数',
  `create_time` int unsigned NOT NULL DEFAULT '0' COMMENT '添加时间',
  `update_time` int unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `listorder` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `tag` (`tag`) USING BTREE,
  KEY `usetimes` (`usetimes`,`listorder`) USING BTREE,
  KEY `hits` (`hits`,`listorder`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='tags主表';

-- -----------------------------
-- Records of `mny_tags`
-- -----------------------------
INSERT INTO `mny_tags` VALUES ('1', '精密机器', '', '', '', '1', '0', '1553067267', '1553067267', '0');
INSERT INTO `mny_tags` VALUES ('2', '专业培训', '', '', '', '1', '2', '1553067267', '1553067267', '0');
INSERT INTO `mny_tags` VALUES ('3', '资格证书', '', '', '', '1', '0', '1553067267', '1553067267', '0');
INSERT INTO `mny_tags` VALUES ('4', '机械设备', '', '', '', '1', '2', '1553067296', '1553067296', '0');
INSERT INTO `mny_tags` VALUES ('5', '升降机', '', '', '', '1', '2', '1553067296', '1553067296', '0');
INSERT INTO `mny_tags` VALUES ('6', '租赁服务', '', '', '', '1', '0', '1553067296', '1553067296', '0');
INSERT INTO `mny_tags` VALUES ('7', '餐饮管理', '', '', '', '1', '0', '1553067319', '1553067319', '0');
INSERT INTO `mny_tags` VALUES ('8', '婚庆礼仪', '', '', '', '1', '0', '1553067319', '1553067319', '0');
INSERT INTO `mny_tags` VALUES ('9', '劳务派遣', '', '', '', '1', '0', '1553067319', '1553067319', '0');
INSERT INTO `mny_tags` VALUES ('10', '校外教育', '', '', '', '1', '0', '1553067339', '1553067339', '0');
INSERT INTO `mny_tags` VALUES ('11', '智能课程', '', '', '', '1', '0', '1553067339', '1553067339', '0');
INSERT INTO `mny_tags` VALUES ('12', '物流服务', '', '', '', '1', '0', '1553067377', '1553067377', '0');
INSERT INTO `mny_tags` VALUES ('13', '注脂', '', '', '', '1', '0', '1553067408', '1553067408', '0');
INSERT INTO `mny_tags` VALUES ('14', '打胶', '', '', '', '1', '0', '1553067408', '1553067408', '0');

-- -----------------------------
-- Table structure for `mny_tags_content`
-- -----------------------------
DROP TABLE IF EXISTS `mny_tags_content`;
CREATE TABLE `mny_tags_content` (
  `tag` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'tag名称',
  `modelid` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '模型ID',
  `contentid` mediumint unsigned NOT NULL DEFAULT '0' COMMENT '信息ID',
  `catid` smallint unsigned NOT NULL DEFAULT '0' COMMENT '栏目ID',
  `updatetime` int unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  KEY `modelid` (`modelid`,`contentid`) USING BTREE,
  KEY `tag` (`tag`(10)) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='tags数据表';

-- -----------------------------
-- Records of `mny_tags_content`
-- -----------------------------
INSERT INTO `mny_tags_content` VALUES ('精密机器', '3', '6', '5', '1553067267');
INSERT INTO `mny_tags_content` VALUES ('专业培训', '3', '6', '5', '1553067267');
INSERT INTO `mny_tags_content` VALUES ('资格证书', '3', '6', '5', '1553067267');
INSERT INTO `mny_tags_content` VALUES ('机械设备', '3', '5', '5', '1553067296');
INSERT INTO `mny_tags_content` VALUES ('升降机', '3', '5', '5', '1553067296');
INSERT INTO `mny_tags_content` VALUES ('租赁服务', '3', '5', '5', '1553067296');
INSERT INTO `mny_tags_content` VALUES ('餐饮管理', '3', '4', '5', '1553067319');
INSERT INTO `mny_tags_content` VALUES ('婚庆礼仪', '3', '4', '5', '1553067319');
INSERT INTO `mny_tags_content` VALUES ('劳务派遣', '3', '4', '5', '1553067319');
INSERT INTO `mny_tags_content` VALUES ('校外教育', '3', '3', '5', '1553067339');
INSERT INTO `mny_tags_content` VALUES ('智能课程', '3', '3', '5', '1553067339');
INSERT INTO `mny_tags_content` VALUES ('物流服务', '3', '2', '5', '1553067377');
INSERT INTO `mny_tags_content` VALUES ('注脂', '3', '1', '5', '1553067408');
INSERT INTO `mny_tags_content` VALUES ('打胶', '3', '1', '5', '1553067408');

-- -----------------------------
-- Table structure for `mny_terms`
-- -----------------------------
DROP TABLE IF EXISTS `mny_terms`;
CREATE TABLE `mny_terms` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '分类ID',
  `parentid` smallint NOT NULL DEFAULT '0' COMMENT '父ID',
  `name` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '分类名称',
  `module` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '所属模块',
  `setting` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '相关配置信息',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `name` (`name`) USING BTREE,
  KEY `module` (`module`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='分类表';


-- -----------------------------
-- Table structure for `mny_user`
-- -----------------------------
DROP TABLE IF EXISTS `mny_user`;
CREATE TABLE `mny_user` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `nickname` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '昵称',
  `password` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '密码',
  `encrypt` varchar(6) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '加密因子',
  `sex` tinyint(1) DEFAULT '0' COMMENT '0：未选择 1：男 2：女',
  `point` mediumint NOT NULL DEFAULT '0' COMMENT '用户积分',
  `birthday` int DEFAULT NULL COMMENT '生日',
  `amount` decimal(8,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '钱金总额',
  `phone` varchar(11) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '手机号',
  `avatar` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '头像',
  `region_id` int DEFAULT NULL COMMENT '区域id值',
  `reg_city_name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `reg_area_name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `reg_province_name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `reg_time` int unsigned NOT NULL DEFAULT '0' COMMENT '注册时间',
  `status` tinyint NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `mobile` (`phone`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='会员表';

-- -----------------------------
-- Records of `mny_user`
-- -----------------------------
INSERT INTO `mny_user` VALUES ('9', 'WjeqST', '9dcbf73e4cd34e5326cbd55ec7676406', 'wvnnpL', '0', '0', '', '0.00', '13866104034', '/static/app/images/default_avatar.jpg', '222', '2131', '123123', '123', '1663579195', '1');
INSERT INTO `mny_user` VALUES ('10', 'QqOHR2', '5cccdfebb3260b44177486ad4298cebc', 'j0PFoa', '0', '0', '', '0.00', '13866104035', '/static/app/images/default_avatar.jpg', '222', '2131', '123123', '123', '1663579252', '1');
INSERT INTO `mny_user` VALUES ('16', 'M6b2CZ', 'bd8cd847e8b911604fe677a8e103ff96', 'LGPyDx', '0', '0', '', '0.00', '13866104037', '/static/app/images/default_avatar.jpg', '0', '2131', '123123', '123', '1663579355', '1');
INSERT INTO `mny_user` VALUES ('21', 'o9zU4n', '766c0fd18190d4ad48ee3660911984f2', 'yNIS4r', '0', '0', '', '0.00', '13866104038', '/static/app/images/default_avatar.jpg', '0', '2131', '123123', '123', '1663579813', '1');
INSERT INTO `mny_user` VALUES ('22', 'jCR2J8', '7cdddcb026a80c8cfd5adb1fa00e4e10', 'UzAT01', '0', '0', '', '0.00', '13866104039', '/static/app/images/default_avatar.jpg', '0', '2131', '123123', '123', '1663579833', '1');
INSERT INTO `mny_user` VALUES ('28', 'dgbBEG', '4573815a4cb39f2529e19d2ac2a6b35c', 'UYgw8y', '0', '0', '', '0.00', '13866104021', '/static/app/images/default_avatar.jpg', '0', '2131', '123123', '123', '1663580086', '1');
INSERT INTO `mny_user` VALUES ('34', 'KnGJ6Q', 'c43f3df3f18ff1e15d745bc7803a3d0e', 'g9O8MP', '0', '0', '', '0.00', '13866104022', '/static/app/images/default_avatar.jpg', '0', '2131', '123123', '123', '1663580326', '1');
INSERT INTO `mny_user` VALUES ('35', 'PuaBBI', 'fac922e53c7ec29f329bc090fd1eb757', 'AccX9o', '0', '0', '', '0.00', '13866104023', '/static/app/images/default_avatar.jpg', '0', '2131', '123123', '123', '1663580337', '1');
INSERT INTO `mny_user` VALUES ('36', 'oLjpQk', '77737d374c6f819eb58302b17ba47e72', 'oJoGsg', '0', '0', '', '0.00', '13866104024', '/static/app/images/default_avatar.jpg', '0', '2131', '123123', '123', '1663580356', '1');
INSERT INTO `mny_user` VALUES ('37', 'yHMzuZ', '9e6f82e7526f26edb2922b8ea3092bef', 'UseA6n', '0', '0', '', '0.00', '13866104025', '/static/app/images/default_avatar.jpg', '0', '2131', '123123', '123', '1663580566', '1');
INSERT INTO `mny_user` VALUES ('38', 'aeuq0O', '5beeb572c9a261dc8708936e690e675a', 'BhZM35', '0', '0', '', '0.00', '13866104026', '/static/app/images/default_avatar.jpg', '0', '2131', '123123', '123', '1663634950', '1');
INSERT INTO `mny_user` VALUES ('39', '昵称', '7ed6f9aabc51a200662d21d0f97eb393', 'APKyat', '1', '0', '', '0.00', '13866104028', '/static/app/images/default_avatar.jpg', '0', '2131', '123123', '123', '1663635883', '1');
INSERT INTO `mny_user` VALUES ('40', 'D3BERL', '0ffad8addf3989fb4eb9de062e98f993', 'twNmsv', '0', '0', '', '0.00', '13866104029', '/static/app/images/default_avatar.jpg', '0', '2131', '123123', '123', '1663658640', '1');
INSERT INTO `mny_user` VALUES ('41', 'DNqg6L', '027bb19814ee46535e2d86e10dc5271a', 'M12ekP', '0', '0', '', '0.00', '13866102025', '/static/app/images/default_avatar.jpg', '0', '', '', '', '1663732488', '1');
INSERT INTO `mny_user` VALUES ('45', 'fyuLkR', 'd287c456f3f197993e46488c4055f082', '7PckcL', '0', '23', '', '0.00', '17633578330', '/static/app/images/default_avatar.jpg', '', '', '', '', '1663742129', '1');

-- -----------------------------
-- Table structure for `mny_user_cart`
-- -----------------------------
DROP TABLE IF EXISTS `mny_user_cart`;
CREATE TABLE `mny_user_cart` (
  `id` int NOT NULL AUTO_INCREMENT,
  `goods_id` int DEFAULT '0' COMMENT '商品id',
  `user_id` int unsigned NOT NULL DEFAULT '0' COMMENT '会员ID',
  `type` int DEFAULT '0' COMMENT '0:普通 1质选 2：特卖',
  `specs` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '选择的规格  29,23等',
  `num` int DEFAULT '0' COMMENT '加入数量',
  `add_time` int DEFAULT NULL COMMENT '加入购物车时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='会员Token表';

-- -----------------------------
-- Records of `mny_user_cart`
-- -----------------------------
INSERT INTO `mny_user_cart` VALUES ('3', '10', '45', '1', '', '3', '');
INSERT INTO `mny_user_cart` VALUES ('4', '11', '45', '1', '', '1', '');
INSERT INTO `mny_user_cart` VALUES ('5', '13', '45', '1', '', '2', '');
INSERT INTO `mny_user_cart` VALUES ('6', '27', '45', '1', '', '3', '');
INSERT INTO `mny_user_cart` VALUES ('7', '27', '45', '0', '', '2', '');
INSERT INTO `mny_user_cart` VALUES ('9', '24', '45', '0', '', '2', '');
INSERT INTO `mny_user_cart` VALUES ('11', '22', '45', '0', '', '2', '');
INSERT INTO `mny_user_cart` VALUES ('12', '27', '45', '0', '1,3', '3', '');
INSERT INTO `mny_user_cart` VALUES ('13', '27', '45', '0', '1,3,4', '1', '1663904614');
INSERT INTO `mny_user_cart` VALUES ('14', '34', '45', '0', '', '1', '1663923315');
INSERT INTO `mny_user_cart` VALUES ('15', '36', '45', '2', '17,20', '4', '1663936753');
INSERT INTO `mny_user_cart` VALUES ('16', '36', '45', '1', '14', '4', '1663936796');
INSERT INTO `mny_user_cart` VALUES ('17', '36', '45', '2', '16,21', '1', '1663936835');
INSERT INTO `mny_user_cart` VALUES ('18', '36', '45', '1', '15', '1', '1663937118');

-- -----------------------------
-- Table structure for `mny_user_delivery`
-- -----------------------------
DROP TABLE IF EXISTS `mny_user_delivery`;
CREATE TABLE `mny_user_delivery` (
  `id` int NOT NULL AUTO_INCREMENT,
  `delivery_id` int DEFAULT '0' COMMENT '配送点id',
  `is_current` tinyint DEFAULT '0' COMMENT '1:当前配送点 0：其他：历史配送点',
  `user_id` int unsigned NOT NULL DEFAULT '0' COMMENT '会员ID',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='会员Token表';

-- -----------------------------
-- Records of `mny_user_delivery`
-- -----------------------------
INSERT INTO `mny_user_delivery` VALUES ('4', '5', '0', '45');
INSERT INTO `mny_user_delivery` VALUES ('5', '6', '0', '45');
INSERT INTO `mny_user_delivery` VALUES ('6', '9', '0', '45');
INSERT INTO `mny_user_delivery` VALUES ('7', '8', '1', '45');
INSERT INTO `mny_user_delivery` VALUES ('8', '7', '0', '45');
INSERT INTO `mny_user_delivery` VALUES ('9', '10', '0', '45');

-- -----------------------------
-- Table structure for `mny_user_dynamic`
-- -----------------------------
DROP TABLE IF EXISTS `mny_user_dynamic`;
CREATE TABLE `mny_user_dynamic` (
  `id` int NOT NULL AUTO_INCREMENT,
  `from_type` tinyint DEFAULT NULL COMMENT '1:购买商品 2：签到 3：等等',
  `type` tinyint DEFAULT '0' COMMENT '1：金额 2：积分',
  `user_id` int unsigned NOT NULL DEFAULT '0' COMMENT '会员ID',
  `before_num` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '0' COMMENT '变动前数量',
  `after_num` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '0' COMMENT '变动后数量',
  `bind_id` int DEFAULT '0',
  `add_reduce` tinyint DEFAULT NULL COMMENT '1:增加 2：减少',
  `remark` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '备注',
  `dynamic_num` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '0' COMMENT '变动数量',
  `create_time` int DEFAULT NULL COMMENT '生成时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='会员Token表';

-- -----------------------------
-- Records of `mny_user_dynamic`
-- -----------------------------
INSERT INTO `mny_user_dynamic` VALUES ('17', '1', '2', '45', '0', '0', '0', '', '', '0', '');
INSERT INTO `mny_user_dynamic` VALUES ('18', '2', '2', '45', '0', '0', '0', '', '', '0', '');

-- -----------------------------
-- Table structure for `mny_user_feedback`
-- -----------------------------
DROP TABLE IF EXISTS `mny_user_feedback`;
CREATE TABLE `mny_user_feedback` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int unsigned NOT NULL DEFAULT '0' COMMENT '会员ID',
  `content` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '反馈内容',
  `add_time` int DEFAULT NULL COMMENT '反馈时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='会员Token表';

-- -----------------------------
-- Records of `mny_user_feedback`
-- -----------------------------
INSERT INTO `mny_user_feedback` VALUES ('15', '45', '123123123', '1663931093');
INSERT INTO `mny_user_feedback` VALUES ('16', '45', '123123123', '1663931112');
INSERT INTO `mny_user_feedback` VALUES ('17', '45', '123123123', '1663931141');

-- -----------------------------
-- Table structure for `mny_user_order`
-- -----------------------------
DROP TABLE IF EXISTS `mny_user_order`;
CREATE TABLE `mny_user_order` (
  `id` int NOT NULL AUTO_INCREMENT,
  `goods_id` int DEFAULT '0' COMMENT '商品id值',
  `status` tinyint(1) DEFAULT '0' COMMENT ' -1：全部 -2：已失效 0：未支付 1：待发货  2：待收货 3：已收货 4：退款、售后',
  `user_id` int DEFAULT '0' COMMENT '用户id值',
  `create_time` int DEFAULT '0' COMMENT '订单创建时间',
  `pay_time` int DEFAULT NULL COMMENT '订单支付时间',
  `order_sn` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '订单id值',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='会员Token表';


-- -----------------------------
-- Table structure for `mny_user_order_item`
-- -----------------------------
DROP TABLE IF EXISTS `mny_user_order_item`;
CREATE TABLE `mny_user_order_item` (
  `id` int NOT NULL AUTO_INCREMENT,
  `order_id` int DEFAULT '0' COMMENT '订单id值',
  `user_id` int DEFAULT '0' COMMENT '用户id值',
  `create_time` int DEFAULT '0' COMMENT '订单创建时间',
  `pay_time` int DEFAULT NULL COMMENT '订单支付时间',
  `order_sn` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '订单id值',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='会员Token表';


-- -----------------------------
-- Table structure for `mny_user_picker`
-- -----------------------------
DROP TABLE IF EXISTS `mny_user_picker`;
CREATE TABLE `mny_user_picker` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int unsigned NOT NULL DEFAULT '0' COMMENT '会员ID',
  `name` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT '0' COMMENT '用户姓名',
  `phone` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '手机号',
  `is_default` tinyint DEFAULT '0' COMMENT '1:默认',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='会员Token表';

-- -----------------------------
-- Records of `mny_user_picker`
-- -----------------------------
INSERT INTO `mny_user_picker` VALUES ('14', '45', '劲松', '13866104034', '0');
INSERT INTO `mny_user_picker` VALUES ('15', '45', '劲松', '13866104034', '0');
INSERT INTO `mny_user_picker` VALUES ('16', '45', '劲松111', '13866104034', '1');

-- -----------------------------
-- Table structure for `mny_user_redbao`
-- -----------------------------
DROP TABLE IF EXISTS `mny_user_redbao`;
CREATE TABLE `mny_user_redbao` (
  `id` int NOT NULL AUTO_INCREMENT,
  `redbao_id` int DEFAULT '0' COMMENT '红包id值',
  `user_id` int unsigned NOT NULL DEFAULT '0' COMMENT '会员ID',
  `expire_day` int DEFAULT '0' COMMENT '有效天数',
  `get_time` int DEFAULT NULL COMMENT '获得时间',
  `region_id` int DEFAULT NULL COMMENT '区域id',
  `status` tinyint(1) DEFAULT '0' COMMENT '1:未使用 2：已使用 3：已过期',
  `expire_time` int DEFAULT NULL COMMENT '过期时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='会员Token表';

-- -----------------------------
-- Records of `mny_user_redbao`
-- -----------------------------
INSERT INTO `mny_user_redbao` VALUES ('3', '3', '45', '10', '1663720574', '1', '2', '1664411773');

-- -----------------------------
-- Table structure for `mny_user_search`
-- -----------------------------
DROP TABLE IF EXISTS `mny_user_search`;
CREATE TABLE `mny_user_search` (
  `id` int NOT NULL AUTO_INCREMENT,
  `keyword` varchar(266) COLLATE utf8mb4_unicode_ci DEFAULT '0' COMMENT '搜索关键字',
  `user_id` int unsigned NOT NULL DEFAULT '0' COMMENT '会员ID',
  `search_time` int DEFAULT NULL COMMENT '搜索时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='会员Token表';

-- -----------------------------
-- Records of `mny_user_search`
-- -----------------------------
INSERT INTO `mny_user_search` VALUES ('19', '爱仕达无', '45', '1663904775');
INSERT INTO `mny_user_search` VALUES ('20', '十多分', '45', '1663904815');
INSERT INTO `mny_user_search` VALUES ('21', '嗄问问', '45', '1663904827');

-- -----------------------------
-- Table structure for `mny_user_token`
-- -----------------------------
DROP TABLE IF EXISTS `mny_user_token`;
CREATE TABLE `mny_user_token` (
  `id` int NOT NULL AUTO_INCREMENT,
  `token` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Token',
  `user_id` int unsigned NOT NULL DEFAULT '0' COMMENT '会员ID',
  `create_time` int DEFAULT NULL COMMENT '创建时间',
  `expire_time` int DEFAULT NULL COMMENT '过期时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='会员Token表';

-- -----------------------------
-- Records of `mny_user_token`
-- -----------------------------
INSERT INTO `mny_user_token` VALUES ('3', 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyIjoiNDEiLCJpc3MiOiJodHRwOi8vd3d3LmhlbGxvd2ViYS5uZXQiLCJhdWQiOiJodHRwOi8vd3d3LmhlbGxvd2ViYS5uZXQiLCJpYXQiOjE2NjM3MzI0ODksIm5iZiI6MTY2MzczMjQ4OSwiZXhwIjoxNjY0MzM3Mjg5fQ.APf4xf1_fS_IWf60GXmh1o9hGwAMI4xl3J7UIvWYyYo', '41', '1663732489', '1664337289');
INSERT INTO `mny_user_token` VALUES ('2', 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyIjoiNDAiLCJpc3MiOiJodHRwOi8vd3d3LmhlbGxvd2ViYS5uZXQiLCJhdWQiOiJodHRwOi8vd3d3LmhlbGxvd2ViYS5uZXQiLCJpYXQiOjE2NjM2NTg2NDAsIm5iZiI6MTY2MzY1ODY0MCwiZXhwIjoxNjY0MjYzNDQwfQ.zk3TNBv5eN-4-RYsgrPjyDasofOAepvgy-dvkf1Lyy8', '40', '1663658640', '1664263440');
INSERT INTO `mny_user_token` VALUES ('4', 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyIjoiNDUiLCJpc3MiOiJodHRwOi8vd3d3LmhlbGxvd2ViYS5uZXQiLCJhdWQiOiJodHRwOi8vd3d3LmhlbGxvd2ViYS5uZXQiLCJpYXQiOjE2NjM3NDIxMjksIm5iZiI6MTY2Mzc0MjEyOSwiZXhwIjoxNjY0MzQ2OTI5fQ.YMUS-_H5HYP5l_u4qIM22Ww04j1VHSkwe_As_N6dNCw', '45', '1663742129', '1664346929');
INSERT INTO `mny_user_token` VALUES ('5', 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyIjo0NSwiaXNzIjoiaHR0cDovL3d3dy5oZWxsb3dlYmEubmV0IiwiYXVkIjoiaHR0cDovL3d3dy5oZWxsb3dlYmEubmV0IiwiaWF0IjoxNjYzNzQyNDg3LCJuYmYiOjE2NjM3NDI0ODcsImV4cCI6MTY2NDM0NzI4N30.xPv1yqYoBks8no0y64nPCu7AyG8ZG6q7eTQYY20DZ-I', '45', '1663742487', '1664347287');
INSERT INTO `mny_user_token` VALUES ('6', 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyIjo0NSwiaXNzIjoiaHR0cDovL3d3dy5oZWxsb3dlYmEubmV0IiwiYXVkIjoiaHR0cDovL3d3dy5oZWxsb3dlYmEubmV0IiwiaWF0IjoxNjYzNzQyNTA3LCJuYmYiOjE2NjM3NDI1MDcsImV4cCI6MTY2NDM0NzMwN30.7GnY-iT-K9jx8Ap_OSvLDfXy5xOPJUXqFeOJtnOG0cU', '45', '1663742507', '1664347307');
INSERT INTO `mny_user_token` VALUES ('7', 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyIjo0NSwiaXNzIjoiaHR0cDovL3d3dy5oZWxsb3dlYmEubmV0IiwiYXVkIjoiaHR0cDovL3d3dy5oZWxsb3dlYmEubmV0IiwiaWF0IjoxNjYzNzQyODI0LCJuYmYiOjE2NjM3NDI4MjQsImV4cCI6MTY2NDM0NzYyNH0.9g7nvlFUywgav6yYe1T_e90aBaSdBaAcp31eE8nk-ps', '45', '1663742824', '1664347624');
INSERT INTO `mny_user_token` VALUES ('8', 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyIjo0NSwiaXNzIjoiaHR0cDovL3d3dy5oZWxsb3dlYmEubmV0IiwiYXVkIjoiaHR0cDovL3d3dy5oZWxsb3dlYmEubmV0IiwiaWF0IjoxNjYzNzQyODc4LCJuYmYiOjE2NjM3NDI4NzgsImV4cCI6MTY2NDM0NzY3OH0.mH41E2pGgev-d-2qEHP_5qM71I29-GI0ntENJ9hQ1TU', '45', '1663742878', '1664347678');
INSERT INTO `mny_user_token` VALUES ('9', 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyIjo0NSwiaXNzIjoiaHR0cDovL3d3dy5oZWxsb3dlYmEubmV0IiwiYXVkIjoiaHR0cDovL3d3dy5oZWxsb3dlYmEubmV0IiwiaWF0IjoxNjYzNzQ0MDc3LCJuYmYiOjE2NjM3NDQwNzcsImV4cCI6MTY2NDM0ODg3N30.f50ik2WWeN8ImY69eA2Xs0AWnn3L5XVjwxIn7pDp7ZI', '45', '1663744077', '1664348877');
INSERT INTO `mny_user_token` VALUES ('10', 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyIjo0NSwiaXNzIjoiaHR0cDovL3d3dy5oZWxsb3dlYmEubmV0IiwiYXVkIjoiaHR0cDovL3d3dy5oZWxsb3dlYmEubmV0IiwiaWF0IjoxNjYzNzQ0MDg3LCJuYmYiOjE2NjM3NDQwODcsImV4cCI6MTY2NDM0ODg4N30.lBx0QlvOJ7cvyEfuM0FjYPu1XhxzoSvJvtONzKjZe_4', '45', '1663744087', '1664348887');
INSERT INTO `mny_user_token` VALUES ('11', 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyIjo0NSwiaXNzIjoiaHR0cDovL3d3dy5oZWxsb3dlYmEubmV0IiwiYXVkIjoiaHR0cDovL3d3dy5oZWxsb3dlYmEubmV0IiwiaWF0IjoxNjYzNzQ0ODA2LCJuYmYiOjE2NjM3NDQ4MDYsImV4cCI6MTY2NDM0OTYwNn0.CJkRcwK1fQU9T9s-f13DVBvZdaPqztmLuiDR_9fUifo', '45', '1663744806', '1664349606');
INSERT INTO `mny_user_token` VALUES ('12', 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyIjo0NSwiaXNzIjoiaHR0cDovL3d3dy5oZWxsb3dlYmEubmV0IiwiYXVkIjoiaHR0cDovL3d3dy5oZWxsb3dlYmEubmV0IiwiaWF0IjoxNjYzNzQ1MjYxLCJuYmYiOjE2NjM3NDUyNjEsImV4cCI6MTY2NDM1MDA2MX0.jF9mXvdOSdl4Xuvwaaw5yApfJeSf2iJXUWaHNej2CAc', '45', '1663745261', '1664350061');
INSERT INTO `mny_user_token` VALUES ('13', 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyIjo0NSwiaXNzIjoiaHR0cDovL3d3dy5oZWxsb3dlYmEubmV0IiwiYXVkIjoiaHR0cDovL3d3dy5oZWxsb3dlYmEubmV0IiwiaWF0IjoxNjYzNzQ4MDUzLCJuYmYiOjE2NjM3NDgwNTMsImV4cCI6MTY2NDM1Mjg1M30.oNDX7XXvJWNIrfyjO9_cOkE7uhFrPkuFSR7nx1ftLgU', '45', '1663748053', '1664352853');
INSERT INTO `mny_user_token` VALUES ('14', 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyIjo0NSwiaXNzIjoiaHR0cDovL3d3dy5oZWxsb3dlYmEubmV0IiwiYXVkIjoiaHR0cDovL3d3dy5oZWxsb3dlYmEubmV0IiwiaWF0IjoxNjYzNzQ4NjYwLCJuYmYiOjE2NjM3NDg2NjAsImV4cCI6MTY2NDM1MzQ2MH0.hieZ6X32xGXYTzpfKVlqTI2yRs23vepZGC_m7UB5cV0', '45', '1663748660', '1664353460');
INSERT INTO `mny_user_token` VALUES ('15', 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyIjo0NSwiaXNzIjoiaHR0cDovL3d3dy5oZWxsb3dlYmEubmV0IiwiYXVkIjoiaHR0cDovL3d3dy5oZWxsb3dlYmEubmV0IiwiaWF0IjoxNjYzNzQ4OTk5LCJuYmYiOjE2NjM3NDg5OTksImV4cCI6MTY2NDM1Mzc5OX0.Dj0gOTmCyQM3O0LS8v4EP-JHYn5IzBLKMw7hwwI2Su8', '45', '1663748999', '1664353799');
INSERT INTO `mny_user_token` VALUES ('16', 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyIjo0NSwiaXNzIjoiaHR0cDovL3d3dy5oZWxsb3dlYmEubmV0IiwiYXVkIjoiaHR0cDovL3d3dy5oZWxsb3dlYmEubmV0IiwiaWF0IjoxNjYzODA5MTg3LCJuYmYiOjE2NjM4MDkxODcsImV4cCI6MTY2NDQxMzk4N30.qKF_a7H_1DbGKeSdvPWryGwW747ugkGBqKJPRnKHUss', '45', '1663809187', '1664413987');
INSERT INTO `mny_user_token` VALUES ('17', 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyIjo0NSwiaXNzIjoiaHR0cDovL3d3dy5oZWxsb3dlYmEubmV0IiwiYXVkIjoiaHR0cDovL3d3dy5oZWxsb3dlYmEubmV0IiwiaWF0IjoxNjYzODA5MjE5LCJuYmYiOjE2NjM4MDkyMTksImV4cCI6MTY2NDQxNDAxOX0.JyXMZt3KWQ9WsgbHYT2IiEpoqxJc-k9x7MZ2ydO1sSM', '45', '1663809219', '1664414019');
INSERT INTO `mny_user_token` VALUES ('18', 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyIjo0NSwiaXNzIjoiaHR0cDovL3d3dy5oZWxsb3dlYmEubmV0IiwiYXVkIjoiaHR0cDovL3d3dy5oZWxsb3dlYmEubmV0IiwiaWF0IjoxNjYzODExNjA1LCJuYmYiOjE2NjM4MTE2MDUsImV4cCI6MTY2NDQxNjQwNX0.ybKtoDTiioxZE4fqudvCTq4ZDlMjImIdxj_0rI4rWjM', '45', '1663811605', '1664416405');
INSERT INTO `mny_user_token` VALUES ('19', 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyIjo0NSwiaXNzIjoiaHR0cDovL3d3dy5oZWxsb3dlYmEubmV0IiwiYXVkIjoiaHR0cDovL3d3dy5oZWxsb3dlYmEubmV0IiwiaWF0IjoxNjYzODExODcyLCJuYmYiOjE2NjM4MTE4NzIsImV4cCI6MTY2NDQxNjY3Mn0.hVvThmixqn8Hv2Th_3gfWAn48_HcxOvmR1rHrYZeBnw', '45', '1663811872', '1664416672');
INSERT INTO `mny_user_token` VALUES ('20', 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyIjo0NSwiaXNzIjoiaHR0cDovL3d3dy5oZWxsb3dlYmEubmV0IiwiYXVkIjoiaHR0cDovL3d3dy5oZWxsb3dlYmEubmV0IiwiaWF0IjoxNjYzODEzNTU5LCJuYmYiOjE2NjM4MTM1NTksImV4cCI6MTY2NDQxODM1OX0.1pYNZg_Kg6jxWTybe5658hcdeLHqnTZJHRRv2InHuEA', '45', '1663813559', '1664418359');
INSERT INTO `mny_user_token` VALUES ('21', 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyIjo0NSwiaXNzIjoiaHR0cDovL3d3dy5oZWxsb3dlYmEubmV0IiwiYXVkIjoiaHR0cDovL3d3dy5oZWxsb3dlYmEubmV0IiwiaWF0IjoxNjYzODE2NTQ0LCJuYmYiOjE2NjM4MTY1NDQsImV4cCI6MTY2NDQyMTM0NH0.R5n-slzFDOrIdCgb5FSIEVz-FexceACgeq33kaEEg38', '45', '1663816544', '1664421344');
INSERT INTO `mny_user_token` VALUES ('22', 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyIjo0NSwiaXNzIjoiaHR0cDovL3d3dy5oZWxsb3dlYmEubmV0IiwiYXVkIjoiaHR0cDovL3d3dy5oZWxsb3dlYmEubmV0IiwiaWF0IjoxNjYzODE3MTA4LCJuYmYiOjE2NjM4MTcxMDgsImV4cCI6MTY2NDQyMTkwOH0.UXcdt_HSUgJYwnjmK-kSfgh7GK7f8wa7PWMA8FQQJxA', '45', '1663817108', '1664421908');
INSERT INTO `mny_user_token` VALUES ('23', 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyIjo0NSwiaXNzIjoiaHR0cDovL3d3dy5oZWxsb3dlYmEubmV0IiwiYXVkIjoiaHR0cDovL3d3dy5oZWxsb3dlYmEubmV0IiwiaWF0IjoxNjYzODMwMzI0LCJuYmYiOjE2NjM4MzAzMjQsImV4cCI6MTY2NDQzNTEyNH0.E7vUS-PmPsJxOyu2HnG2qyzkUAArkGY8zwSfNcNkMu4', '45', '1663830324', '1664435124');
INSERT INTO `mny_user_token` VALUES ('24', 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyIjo0NSwiaXNzIjoiaHR0cDovL3d3dy5oZWxsb3dlYmEubmV0IiwiYXVkIjoiaHR0cDovL3d3dy5oZWxsb3dlYmEubmV0IiwiaWF0IjoxNjYzODMxNzcxLCJuYmYiOjE2NjM4MzE3NzEsImV4cCI6MTY2NDQzNjU3MX0.V_mFLLMYpqKlSDjD-MagU7JJZtcUd3csAbnNh1KM_lU', '45', '1663831771', '1664436571');
INSERT INTO `mny_user_token` VALUES ('25', 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyIjo0NSwiaXNzIjoiaHR0cDovL3d3dy5oZWxsb3dlYmEubmV0IiwiYXVkIjoiaHR0cDovL3d3dy5oZWxsb3dlYmEubmV0IiwiaWF0IjoxNjYzODMxOTk1LCJuYmYiOjE2NjM4MzE5OTUsImV4cCI6MTY2NDQzNjc5NX0.p75ngDAzs0t-0T9sIn7ubqpIrNTYt9L2FiJifDCLS_Y', '45', '1663831995', '1664436795');
INSERT INTO `mny_user_token` VALUES ('26', 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyIjo0NSwiaXNzIjoiaHR0cDovL3d3dy5oZWxsb3dlYmEubmV0IiwiYXVkIjoiaHR0cDovL3d3dy5oZWxsb3dlYmEubmV0IiwiaWF0IjoxNjYzODMyNDAzLCJuYmYiOjE2NjM4MzI0MDMsImV4cCI6MTY2NDQzNzIwM30.uzFUHVowbQIeMi3dUqqTKykmKzPegA5ougQYA9Va2uI', '45', '1663832403', '1664437203');
INSERT INTO `mny_user_token` VALUES ('27', 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyIjo0NSwiaXNzIjoiaHR0cDovL3d3dy5oZWxsb3dlYmEubmV0IiwiYXVkIjoiaHR0cDovL3d3dy5oZWxsb3dlYmEubmV0IiwiaWF0IjoxNjYzODM4MjE1LCJuYmYiOjE2NjM4MzgyMTUsImV4cCI6MTY2NDQ0MzAxNX0.7nA8hYBf4RUhOl3ywPEdc2fqhq1QHsVOetwPOSoTjHU', '45', '1663838215', '1664443015');
INSERT INTO `mny_user_token` VALUES ('28', 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyIjo0NSwiaXNzIjoiaHR0cDovL3d3dy5oZWxsb3dlYmEubmV0IiwiYXVkIjoiaHR0cDovL3d3dy5oZWxsb3dlYmEubmV0IiwiaWF0IjoxNjYzODQzMTY5LCJuYmYiOjE2NjM4NDMxNjksImV4cCI6MTY2NDQ0Nzk2OX0.rWBCCGJAfOv0f7W7PrbjNXxvrgCVS6IfLgve7gBAZRc', '45', '1663843169', '1664447969');
INSERT INTO `mny_user_token` VALUES ('29', 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyIjo0NSwiaXNzIjoiaHR0cDovL3d3dy5oZWxsb3dlYmEubmV0IiwiYXVkIjoiaHR0cDovL3d3dy5oZWxsb3dlYmEubmV0IiwiaWF0IjoxNjYzODk0ODgxLCJuYmYiOjE2NjM4OTQ4ODEsImV4cCI6MTY2NDQ5OTY4MX0.rYL9DapWuRN0ICVHuUOorC5blmU6QPFUkuSGa_6F3Ow', '45', '1663894881', '1664499681');
INSERT INTO `mny_user_token` VALUES ('30', 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyIjo0NSwiaXNzIjoiaHR0cDovL3d3dy5oZWxsb3dlYmEubmV0IiwiYXVkIjoiaHR0cDovL3d3dy5oZWxsb3dlYmEubmV0IiwiaWF0IjoxNjYzOTAxMDQzLCJuYmYiOjE2NjM5MDEwNDMsImV4cCI6MTY2NDUwNTg0M30.HYG-ho5pA3b-ZOeoQpNwco28sIolJIiDDyJzWRjjMt0', '45', '1663901043', '1664505843');
INSERT INTO `mny_user_token` VALUES ('31', 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyIjo0NSwiaXNzIjoiaHR0cDovL3d3dy5oZWxsb3dlYmEubmV0IiwiYXVkIjoiaHR0cDovL3d3dy5oZWxsb3dlYmEubmV0IiwiaWF0IjoxNjYzOTMxOTQ5LCJuYmYiOjE2NjM5MzE5NDksImV4cCI6MTY2NDE5MTE0OX0.yirTDR6nmaTsMGA4idElI8pvMMFv6Sd9fc5UG5v7fm8', '45', '1663931949', '1664536749');
INSERT INTO `mny_user_token` VALUES ('32', 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyIjo0NSwiaXNzIjoiaHR0cDovL3d3dy5oZWxsb3dlYmEubmV0IiwiYXVkIjoiaHR0cDovL3d3dy5oZWxsb3dlYmEubmV0IiwiaWF0IjoxNjYzOTMyMzI4LCJuYmYiOjE2NjM5MzIzMjgsImV4cCI6MTY2NDE5MTUyOH0.dIehiUuQy8yC2LMrwhV4cMR7sQJJ7vk_GeqnVEuyLpk', '45', '1663932328', '1664537128');
INSERT INTO `mny_user_token` VALUES ('33', 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyIjo0NSwiaXNzIjoiaHR0cDovL3d3dy5oZWxsb3dlYmEubmV0IiwiYXVkIjoiaHR0cDovL3d3dy5oZWxsb3dlYmEubmV0IiwiaWF0IjoxNjYzOTMyNjk4LCJuYmYiOjE2NjM5MzI2OTgsImV4cCI6MTY2NDE5MTg5OH0.M1SStMiKZnRY0hO3hgHrmO4DwJ0ogKqq4yHsqlwYjmw', '45', '1663932698', '1664537498');
INSERT INTO `mny_user_token` VALUES ('34', 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyIjo0NSwiaXNzIjoiaHR0cDovL3d3dy5oZWxsb3dlYmEubmV0IiwiYXVkIjoiaHR0cDovL3d3dy5oZWxsb3dlYmEubmV0IiwiaWF0IjoxNjYzOTMyNzcyLCJuYmYiOjE2NjM5MzI3NzIsImV4cCI6MTY2NDE5MTk3Mn0.M5yijUfxJViGqXg6tWklNnlTVaZO6ulp4eDZAfLpY5M', '45', '1663932772', '1664537572');
INSERT INTO `mny_user_token` VALUES ('35', 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyIjo0NSwiaXNzIjoiaHR0cDovL3d3dy5oZWxsb3dlYmEubmV0IiwiYXVkIjoiaHR0cDovL3d3dy5oZWxsb3dlYmEubmV0IiwiaWF0IjoxNjYzOTMyOTIzLCJuYmYiOjE2NjM5MzI5MjMsImV4cCI6MTY2NDE5MjEyM30.QzLEuT1747fofS1rq1bWI1QrVf4vjl3Yc_hem3LMgmg', '45', '1663932923', '1664537723');
INSERT INTO `mny_user_token` VALUES ('36', 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyIjo0NSwiaXNzIjoiaHR0cDovL3d3dy5oZWxsb3dlYmEubmV0IiwiYXVkIjoiaHR0cDovL3d3dy5oZWxsb3dlYmEubmV0IiwiaWF0IjoxNjYzOTMzMjQ2LCJuYmYiOjE2NjM5MzMyNDYsImV4cCI6MTY2NDE5MjQ0Nn0.MSEBFWtWKgZgIhCa4ZJ96sRlSHL1Owf6jEPvm-1-mXs', '45', '1663933246', '1664538046');
